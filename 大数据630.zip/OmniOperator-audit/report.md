# OmniOperator 安全审查报告

**审查目标**：openEuler OmniOperator（Kunpeng 大数据算子加速框架，omni_commercial_630 分支）
**审查日期**：2026-06-13
**审查范围**：约 1605 个源文件，涵盖 C/C++/Java 生产代码（排除测试文件）
**审查方法**：静态代码分析，追踪数据流，识别注入点和不安全操作

---

## 摘要

本次审查识别出 **22 个安全发现**，其中 **9 个高严重度**、**13 个中等严重度**。最关键的发现集中在以下领域：

- **反序列化边界缺失**：vector_marshaller 从原始字节流读取 size/length 时不做边界校验，可能导致越界内存读写
- **UDF 执行安全**：HiveUdfExecutor 加载并执行任意 Java 类，无沙箱、无签名校验、无权限限制，可导致远程代码执行
- **算子加速特有风险**：SIMD/NEON 字典索引越界访问、ORC 文件 VLA 栈溢出、SVE 可变宽度栈分配
- **整数截断/溢出**：多处 size_t→int32_t 截断、int32_t 乘法溢出导致缓冲区大小计算错误
- **JNI 边界安全**：OmniBufferUnsafeV8/DictionaryVec 使用 sun.misc.Unsafe 直接访问堆外内存无边界校验

---

# 发现 1：反序列化越界读取 — 字符串长度未校验：`core/src/operator/hashmap/vector_marshaller.cpp:29-50`

* 严重程度：高
* 类别：insecure_deserialization
* CWE：CWE-125 (Out-of-bounds Read)、CWE-20 (Improper Input Validation)
* CVSS 评分：8.6
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`VariableTypeDeserializer` 从原始字节流中读取 `stringLen`（最大可达 UINT32_MAX via BYTE_4 分支），直接用于构造 `std::string_view(pos, stringLen)` 和计算返回指针 `pos + stringLen`。没有任何边界校验确保 `stringLen` 不超过剩余缓冲区长度。恶意数据可导致越界读取和后续反序列化操作读取垃圾内存。
* 攻击场景：攻击者通过构造包含超大 stringLen 值的哈希表序列化数据（BYTE_4 分支下 stringLen 可达 2^32），触发越界内存读取。此函数在哈希聚合操作中处理每一行数据，是高频攻击面。
* 修复建议：在读取 stringLen 后，校验 `stringLen <= (bufferEnd - pos)`，其中 bufferEnd 是序列化数据的末尾指针。对所有 BYTE_N 分支增加上限检查。
* 置信度：9/10

---

# 发现 2：反序列化越界读取 — 数组大小未校验：`core/src/operator/hashmap/vector_marshaller.cpp:264-311`

* 严重程度：高
* 类别：insecure_deserialization
* CWE：CWE-125、CWE-20
* CVSS 评分：8.6
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`ArrayVectorDeserializer` 从字节流读取 `size` 字段（BYTE_4 分支可达 UINT32_MAX），直接用于 `elementVec->Expand(end)` 扩展向量大小和驱动循环迭代。没有校验 size 是否在合理范围内，也没有校验 `begin` 指针在每次迭代后是否仍在缓冲区范围内。
* 攻击场景：构造包含 size=2^32 的序列化数组数据，导致尝试分配数十亿元素的向量，消耗大量内存。同时循环中 `begin` 指针不断前进但不检查是否超出缓冲区边界，导致越界读取。
* 修复建议：添加 size 上限校验（如 `size <= maxVectorSize`），并在每次 DeserializeElementByType 调用后校验 `begin <= bufferEnd`。
* 置信度：9/10

---

# 发现 3：BloomFilter 反序列化 — size 未校验导致越界读写：`core/src/codegen/bloom_filter.cpp:56-83`

* 严重程度：高
* 类别：insecure_deserialization
* CWE：CWE-125、CWE-787 (Out-of-bounds Write)
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:L/A:L
* 描述：`BloomFilter` 反序列化构造函数从序列化数据中读取 `int32_t size`，然后分配 `new BitArray(size)` 并循环复制 `size` 个 uint64_t 元素。`size` 完全来自外部数据，没有校验其是否在合理范围内或不超过缓冲区实际内容长度。恶意 size 值可导致：(1) 从 buf 越界读取数据；(2) BitArray 内部操作越界写入。

同时 `BitArray` 的原始指针构造函数 (`bit_array.h:46-61`) 从 `dataInput` 读取 `wordsNum`，无校验地假设后续数据有 `wordsNum*8` 字节。`bloom_filter.cpp:32` 通过 `bits = new BitArray(in + 8)` 调用此构造函数，`in` 来自外部数据。

* 攻击场景：构造恶意序列化 BloomFilter 数据，设置 size 远大于实际缓冲区内容，导致越界读取并可能越界写入。
* 修复建议：在反序列化时校验 `size * sizeof(uint64_t) <= availableBufferSize`，并在 BitArray 构造函数中校验 `wordsNum > 0 && wordsNum <= maxWordsNum`。
* 置信度：8/10

---

# 发现 4：SpillMerger 部分读取返回 SUCCESS — 未初始化内存消费：`core/src/operator/spill/spill_merger.cpp:420-427`

* 严重程度：高
* 类别：uninitialized_memory
* CWE：CWE-457 (Use of Uninitialized Variable)
* CVSS 评分：7.8
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`ReadWithCompress` 函数中，当 `remainLength < bufSize` 时，仅复制 `remainLength` 字节到调用方缓冲区，但函数返回 `ErrorCode::SUCCESS`。调用方（如 `ReadVecBatch`）假设 `bufSize` 字节已全部填充，剩余的 `bufSize - bytes_to_copy` 字节保持未初始化。这些垃圾值可能被解释为 rowCount、null bitmap、offsets 或数据值，导致后续缓冲区溢出或错误计算。

* 攻击场景：构造或修改 spill 文件使得压缩块的数据量少于调用方期望的 bufSize。部分读取后，未初始化的 rowCount 值被用于分配向量，可能导致巨大的内存分配或后续越界访问。
* 修复建议：当 `bytes_to_copy < bufSize` 时返回错误码而非 SUCCESS，或者用零填充剩余字节。
* 置信度：8/10

---

# 发现 5：UDF 执行无沙箱 — 任意代码执行：`core/src/udf/java/src/main/java/omniruntime/udf/HiveUdfExecutor.java:55-81`

* 严重程度：高
* 类别：code_execution
* CWE：CWE-94 (Code Injection)、CWE-272 (Least Privilege Violation)
* CVSS 评分：9.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H
* 描述：`HiveUdfExecutor` 从配置的 `hiveUdfDir` 目录加载所有 JAR 文件，通过 `URLClassLoader` 和反射实例化 UDF 类，并以完整 JVM 权限执行。无 SecurityManager、无沙箱、无 JAR 签名校验、无类名白名单。UDF 可访问文件系统、网络、子进程和其他进程数据。`udfClassName` 从 C++ 侧通过 JNI 传入，仅有 `UDF.class.isAssignableFrom` 检查，恶意类可轻易满足此条件。

* 攻击场景：攻击者将恶意 JAR 放入 `OMNI_HOME/conf/omni.conf` 配置的 `hiveUdfDir` 目录（或修改配置指向攻击者目录），即可通过 UDF 执行任意 Java 代码，读取敏感数据、建立反向连接、执行系统命令。
* 修复建议：(1) 为 UDF 执行配置自定义 SecurityManager 或 AccessController，限制文件/网络/进程访问；(2) 校验 JAR 数字签名；(3) 维护允许的 UDF 类白名单；(4) 验证 hiveUdfDir 配置路径的安全来源。
* 置信度：9/10

---

# 发现 6：ORC 读取器 VLA 栈溢出：`core/src/reader/orc/OmniColReader.cc:706-708`

* 严重程度：高
* 类别：stack_overflow
* CWE：CWE-121 (Stack-based Buffer Overflow)
* CVSS 评分：7.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H
* 描述：多个 ORC 列读取器函数使用 VLA（Variable Length Array），大小由来自 ORC 文件元数据的 `numValues` 决定。VLA 在 C++ 中非标准（GCC/Clang 扩展），在栈上分配运行时确定的内存。恶意 ORC 文件可设置极大的 `numValues`，导致栈溢出和进程崩溃。最危险的是 `OmniStringDirectColumnReader::next()`（约第925-936行），其中 `totalLength` 从文件数据计算后作为 `char ptr[totalLength]` 分配在栈上。

涉及代码位置：
- `OmniTimestampColumnReader::nextByType` (line 706-708): `int64_t secsBuffer[numValues]; int64_t nanoBuffer[numValues];`
- `OmniStringDictionaryColumnReader::next` (line 839): `int64_t outputLengths[numValues];`
- `OmniStringDirectColumnReader::next` (line 925-936): `int64_t lengthPtr[numValues]; char ptr[totalLength];`
- `OmniDecimal64ColumnReader::next` (line 1001-1008): `int64_t scaleBuffer[nonNullNums]; int64_t values[nonNullNums];`
- `OmniDecimal128ColumnReader::next` (line 1036): `int64_t scaleBuffer[numValues];`

* 攻击场景：构造恶意 ORC 文件，在 stripe footer 中设置极大的行数，触发 VLA 栈分配溢出，导致 SEGFAULT 或潜在的内存腐败。
* 修复建议：将所有 VLA 替换为 `std::vector` 或 `std::unique_ptr<T[]>`（在堆上分配），并在分配前校验 `numValues` 在合理范围内。
* 置信度：9/10

---

# 发现 7：OmniBufferUnsafeV8 堆外内存访问无边界校验：`bindings/java/src/main/java/nova/hetu/omniruntime/vector/OmniBufferUnsafeV8.java:162-164`

* 严重程度：高
* 类别：memory_bounds_violation
* CWE：CWE-119 (Improper Restriction of Operations within Bounds of a Memory Buffer)
* CVSS 评分：8.2
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`OmniBufferUnsafeV8` 存储了 `address`（原生内存地址）和 `capacity`（容量），但所有内存访问方法（getByte/getInt/getLong/setByte/setInt/setLong/setBytes 等）通过 `addr(offsetInBytes) = address + offsetInBytes` 计算目标地址时，**从未校验 offsetInBytes < capacity**。任何超出分配缓冲区范围的 offset 都将直接通过 `sun.misc.Unsafe` 读/写相邻堆外内存区域。

```java
private long addr(long offsetInBytes) {
    return address + offsetInBytes;  // No check: offsetInBytes < capacity
}
```

* 攻击场景：JNI 层传入的地址或索引值被篡改或溢出，导致 `OmniBufferUnsafeV8` 读写进程堆外内存的任意位置，泄露敏感数据或破坏内存结构。
* 修复建议：在 `addr()` 方法中添加 `OMNI_CHECK(offsetInBytes >= 0 && offsetInBytes < capacity)` 校验，或在每个 set/get 方法中校验 index 范围。
* 置信度：9/10

---

# 发现 8：UDF 输出缓冲区容量倍增整数溢出：`core/src/udf/cplusplus/java_udf_functions.cpp:104-128`

* 严重程度：高
* 类别：integer_overflow
* CWE：CWE-190 (Integer Overflow or Wraparound)
* CVSS 评分：8.1
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:H/A:H
* 描述：`ExecHiveUdfOutputString` 中 `outputValueCapacity` 为 `int32_t`，初始值 1024，每次循环倍增 (`outputValueCapacity *= 2`)。约 21 次倍增后，`1024 * 2^21 = 2,147,483,648` 超过 `INT32_MAX`，导致有符号整数溢出（C++ 中为未定义行为）。实际效果是值变为负数或零，使 `ArenaAllocatorMalloc` 分配极小缓冲区，后续写入导致堆缓冲区溢出。

```cpp
int32_t outputValueCapacity = 1024;  // line 104
outputValueCapacity *= 2;             // line 128 — 每次迭代翻倍
```

* 攻击场景：构造 Hive UDF 查询返回超长字符串输出，迫使循环执行超过 21 次，触发整数溢出和堆缓冲区溢出。
* 修复建议：将 `outputValueCapacity` 类型改为 `int64_t` 或 `size_t`，并添加溢出检查（如 `if (outputValueCapacity > MAX_CAPACITY) break;`）。
* 置信度：8/10

---

# 发现 9：Snappy/ZSTD 解压 size_t→int32_t 截断：`core/src/io/Decompression.cc:92-121`

* 严重程度：高
* 类别：integer_truncation
* CWE：CWE-190、CWE-20
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:H/A:H
* 描述：`decompressSnappy` 和 `decompressZstd` 的返回类型为 `std::pair<char*, int32_t>`，但解压大小 `unCompressedSize`/`actualLength` 为 `size_t`。当解压数据大小超过 `INT32_MAX` (2,147,483,647) 时，返回的 int32_t 值被截断为错误的较小值。调用方使用截断后的值处理缓冲区，可能导致数据完整性问题或缓冲区访问越界。

同时，`snappy::GetUncompressedLength` 和 `ZSTD_getDecompressedSize` 从压缩数据头中读取声明的大小，代码直接使用此值分配内存 (`new char[unCompressedSize]`)，无上限校验。攻击者可构造声称解压大小为 4GB+ 的压缩数据头。

```cpp
// Snappy (line 92-105):
std::pair<char*, int32_t> decompressSnappy(...) {
    size_t unCompressedSize;
    snappy::GetUncompressedLength(input, inputLength, &unCompressedSize);  // 来自数据头
    char* output = new char[unCompressedSize];  // 无上限校验的分配
    // ...
    return std::make_pair(output, unCompressedSize);  // size_t→int32_t 截断!
}

// ZSTD (line 107-121):
std::pair<char*, int32_t> decompressZstd(...) {
    auto actualLength = ZSTD_getDecompressedSize(input, inputLength);  // 来自数据头
    char* output = new char[actualLength];  // 无上限校验的分配
    // ...
    return std::make_pair(output, actualLength);  // unsigned long long→int32_t 截断!
}
```

* 攻击场景：构造压缩数据头声称解压大小超过 INT32_MAX，实际解压成功后返回截断的 size 值，导致下游代码使用错误的缓冲区大小处理数据。
* 修复建议：(1) 将返回类型改为 `std::pair<char*, size_t>`；(2) 添加解压大小上限校验（如 `shuffleCompressBlockSize` 的合理倍数）。
* 置信度：9/10

---

# 发现 10：SIMD 字典索引越界读取：`core/src/simd/func/reduce.h:36-43`

* 严重程度：中
* 类别：out_of_bounds_read
* CWE：CWE-125
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:H/I:L/A:L
* 描述：`LoadFromDic` 函数使用 `indexMap[i]` 作为数组索引访问 `inPtr`，不做任何边界校验。`indexMap` 值来自 Parquet/ORC 字典编码索引数据（用户可控输入）。如果 `indexMap[i]` 超出 `inPtr` 数组的实际大小，将导致越界读取。此函数由 `ReduceWithDic` (line 189) 和 `ReduceWithDicAndNulls` (line 234) 调用，处理聚合运算中的字典数据。

```cpp
for (int i = 0; i < rowCount; i++) {
    outPtr[i] = static_cast<OUT>(inPtr[indexMap[i]]);  // indexMap[i] 无边界校验
}
```

* 攻击场景：构造 Parquet/ORC 文件中包含超出字典实际大小的索引值，触发 SIMD 路径的越界内存读取。
* 修复建议：在调用 `LoadFromDic` 前校验所有 `indexMap` 值在字典大小范围内，或在函数内添加 `assert(indexMap[i] < dictSize)`。
* 置信度：8/10

---

# 发现 11：BitArray wordsNum 未校验导致整数溢出：`core/src/util/bit_array.h:58-62`

* 严重程度：中
* 类别：integer_overflow
* CWE：CWE-190
* CVSS 评分：6.8
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:H
* 描述：`BitArray(int32_t wordsNum)` 构造函数未校验 `wordsNum > 0`。`data = new int8_t[wordsNum * sizeof(uint64_t)]` 中，若 `wordsNum` 为 0 或负数，`wordsNum * sizeof(uint64_t)` 计算产生零或通过有符号/无符号转换产生异常值。在 64 位平台上负值会产生极大分配请求（bad_alloc），但 `wordsNum = 0` 导致分配零大小缓冲区后 Set/Get 操作越界。

```cpp
BitArray(int32_t wordsNum) : wordsNum(wordsNum) {
    data = new int8_t[wordsNum * sizeof(uint64_t)];  // wordsNum 未校验
    memset(data, 0, wordsNum * sizeof(uint64_t));
}
```

* 攻击场景：与发现 3 关联 — BloomFilter 反序列化可能传入 `wordsNum = 0`，导致后续 BitArray 操作越界访问。
* 修复建议：添加 `OMNI_CHECK(wordsNum > 0 && wordsNum <= MAX_WORDS_NUM)` 校验。
* 置信度：7/10

---

# 发现 12：RowVector 反序列化字段数未校验：`core/src/operator/hashmap/vector_marshaller.cpp:366-420`

* 严重程度：中
* 类别：insecure_deserialization
* CWE：CWE-125、CWE-20
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`RowVectorDeserializer` 从字节流读取 `childCount`（BYTE_4 分支可达 INT32_MAX），虽然有 `OMNI_CHECK(childCount == rowVector->ChildSize())` 校验，但如果 OMNI_CHECK 在生产构建中被禁用（类似 assert），不匹配的 childCount 将导致 `rowVector->ChildAt(i)` 越界访问。即使校验通过，后续循环中 `begin` 指针不断前进但不检查是否超出缓冲区边界。

```cpp
int32_t childCount = 0;
switch (countLenSize) {
    case BYTE_4: childCount = *reinterpret_cast<const int32_t *>(begin); break;
}
OMNI_CHECK(childCount == rowVector->ChildSize(), ...);  // 可能生产构建中禁用
for (int32_t i = 0; i < childCount; i++) {
    begin = deser(childVec.get(), rowIdx, begin);  // begin 无边界校验
}
```

* 攻击场景：如果 OMNI_CHECK 在生产构建中被跳过，恶意 childCount 导致 ChildAt() 越界访问。
* 修复建议：(1) 确保 OMNI_CHECK 在生产构建中启用或用 if-return 替代；(2) 在每次迭代后校验 `begin <= bufferEnd`。
* 置信度：8/10

---

# 发现 13：路径遍历 — spill 配置路径未消毒：`core/src/operator/config/operator_config.cpp:74-92,158-186`

* 严重程度：中
* 类别：path_traversal
* CWE：CWE-22 (Improper Limitation of a Pathname to a Restricted Directory)
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`OperatorConfig::DeserializeOperatorConfig` 从 JSON 配置中提取 `spillPath`，直接用于 `mkdir()` 和后续文件创建（`SpillWriter::CreateTempFile` 使用 `snprintf("%s/%d-%u-%s", dirPathChars, ...)`），无任何 `../` 序列过滤或路径规范化。spillPath 通过 JNI 从 Java 传入，最终来自 Spark 配置属性，可被用户通过 SQL `SET` 命令或管理员配置修改。

```cpp
auto spillPath = result.at("spillConfig").at("spillPath").get<std::string>();
// ... 直接传入 mkdir 和文件操作，无路径消毒
mkdir(spillPathChars, 0750);
```

* 攻击场景：配置 `spillPath` 为 `/tmp/../etc/cron.d`，导致 spill 数据被写入敏感系统目录。
* 修复建议：对 spillPath 进行路径规范化（`realpath`）和遍历序列过滤，或限制 spill 目录必须在预定义的安全路径下。
* 置信度：8/10

---

# 发现 14：路径遍历 — Hive 连接器和 Iceberg 删除文件路径未校验：`core/src/connectors/hive/HiveConnectorUtil.cpp:142-147` + `core/src/reader/orc/SplitReader.cpp:464-488`

* 严重程度：中
* 类别：path_traversal
* CWE：CWE-22
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:N
* 描述：

**(a) HiveConnectorUtil.cpp:142-147**：`hiveSplit->getFilePath()` 直接传入 `stringToUriInfo()` 用于打开 HDFS 文件，无路径遍历校验、无 scheme 限制（允许 `file://` 读取本地文件）、无 host 校验。

**(b) SplitReader.cpp:464-488**：Iceberg 删除文件的 `path` 字段从 `customSplitInfo` JSON 中提取，直接用于打开和读取删除数据文件，无校验路径是否指向同一 HDFS 集群、无遍历序列过滤、`recordCount` 默认为 `uint64_t::max()`。

```cpp
// HiveConnectorUtil.cpp
auto uri = stringToUriInfo(hiveSplit->getFilePath());  // 未校验路径安全

// SplitReader.cpp
auto deleteFile.at("path").get<std::string>();  // 删除文件路径未校验
```

* 攻击场景：(a) 操纵 Hive split 元数据中的 filePath 为 `file:///etc/passwd`，读取本地敏感文件；(b) 构造 Iceberg customSplitInfo 指向任意 HDFS 路径。
* 修复建议：(1) 限制 scheme 为 `hdfs://`；(2) 校验 host 与当前集群一致；(3) 过滤路径遍历序列；(4) 对 Iceberg 删除文件路径添加白名单校验。
* 置信度：8/10

---

# 发现 15：表达式解析器 stoi 无边界校验：`core/src/expression/parser/parser.cpp:329-333`

* 严重程度：中
* 类别：out_of_bounds_access
* CWE：CWE-20、CWE-129 (Improper Validation of Array Index)
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:N/I:L/A:L
* 描述：`Parser::GenerateFieldExpr` 使用 `stoi(fieldStr.substr(1))` 获取列索引 `colIdx`，但不校验 `colIdx` 是否在 `inputTypes.GetSize()` 范围内。超出范围的 `colIdx` 导致 `inputTypes.GetType(colIdx)` 越界访问。同时 `stoi()` 对无效输入会抛出未捕获的异常，可能导致进程崩溃。

```cpp
int colIdx = stoi(fieldStr.substr(1));  // 无边界校验
const DataTypePtr &colType = inputTypes.GetType(colIdx);  // 可能越界
```

* 攻击场景：构造恶意表达式字符串（如 `#9999999`），使 colIdx 远超 inputTypes 大小，导致越界内存访问。
* 修复建议：添加 `if (colIdx < 0 || colIdx >= inputTypes.GetSize())` 校验，并捕获 stoi 异常。
* 置信度：8/10

---

# 发现 16：JniUtil::GetFieldId 数组越界访问：`core/src/udf/cplusplus/jni_util.cpp:250-258`

* 严重程度：中
* 类别：array_index_out_of_bounds
* CWE：CWE-129
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`GetFieldId(int32_t id)` 函数使用 `id` 索引静态数组 `omniDataTypeIds[19]`（有效范围 0-18），但不校验 `id` 是否在此范围内。`id` 来自 `inputTypes[i]`（通过 JNI 从 Java 传入），如果包含超出范围的值，将导致栈上数组越界读取，返回垃圾 `jfieldID`，后续用于 `GetStaticObjectField` 可能导致 JVM 崩溃或内存腐败。

```cpp
jfieldID JniUtil::GetFieldId(int32_t id) {
    static jfieldID omniDataTypeIds[] = { /* 19 elements */ };
    return omniDataTypeIds[id];  // id 无边界校验
}
```

* 攻击场景：通过 JNI 传入 id >= 19 或 id < 0，触发栈数组越界读取。
* 修复建议：添加 `if (id < 0 || id >= 19) { OMNI_FAIL(...); }` 校验。
* 置信度：8/10

---

# 发现 17：UdfUtil 整数溢出 — Unsafe 内存偏移计算：`core/src/udf/java/src/main/java/omniruntime/udf/UdfUtil.java:62-66`

* 严重程度：中
* 类别：integer_overflow
* CWE：CWE-190
* CVSS 评分：6.8
* CVSS 向量：CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:H
* 描述：`getLongs(long base, int offset, int length)` 中 `offset * LONG_BYTE_SIZE` 和 `length * LONG_BYTE_SIZE` 的乘法可能溢出。`offset` 和 `LONG_BYTE_SIZE` 均为 `int`（8），当 `offset` 接近 `Integer.MAX_VALUE/8` 时乘法溢出为负值，导致 `UNSAFE.copyMemory` 从错误地址读取。`getBytes` 中 `base + offset` 计算的地址可能超出预期缓冲区区域。

```java
public static long[] getLongs(long base, int offset, int length) {
    UNSAFE.copyMemory(null, base + offset * LONG_BYTE_SIZE, values, LONG_ARRAY_OFFSET, length * LONG_BYTE_SIZE);
    // offset * LONG_BYTE_SIZE 可溢出; length * LONG_BYTE_SIZE 可溢出
}
```

* 攻击场景：C++ 侧通过 JNI 传入大 offset 值（如 `Integer.MAX_VALUE/8 + 1`），乘法溢出导致 copyMemory 从错误地址读取。
* 修复建议：使用 `long` 类型进行偏移计算：`base + (long)offset * LONG_BYTE_SIZE`，并校验 offset 和 length 的合理范围。
* 置信度：8/10

---

# 发现 18：DictionaryVec 堆外内存访问无边界校验：`bindings/java/src/main/java/nova/hetu/omniruntime/vector/DictionaryVec.java:239-301`

* 严重程度：中
* 类别：memory_bounds_violation
* CWE：CWE-119
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:H/I:L/A:L
* 描述：`DictionaryVec` 的所有 get 方法（getShort/getInt/getLong/getDouble/getBytes）通过 `getId(index)` 从原生值缓冲区读取 `originIndex`，然后用 `originIndex * TYPE_SIZE` 计算偏移访问字典数据地址 (`dataAddress + originIndex * TYPE_SIZE`)。没有校验 `originIndex < dictionarySize`。如果原生缓冲区被破坏或切片索引超出原始范围，`originIndex` 可为任意值，导致任意堆外内存读取。

`getBytes` 方法中 `stringLen` 也从原生 offsets 计算（`getValueOffset(originIndex + 1) - getValueOffset(originIndex)`），可为负数或极大值。

```java
public int getInt(int index) {
    int originIndex = getId(index);  // 从原生内存读取，无校验
    return JvmUtils.UNSAFE.getInt(dataAddress + originIndex * Integer.BYTES);  // 无边界校验
}
```

* 攻击场景：原生内存中字典索引值被篡改，导致 originIndex 超出字典范围，读取进程任意堆外内存。
* 修复建议：校验 `originIndex >= 0 && originIndex < dictionarySize`，校验 `stringLen >= 0 && stringLen <= maxStringLen`。
* 置信度：8/10

---

# 发现 19：Zlib 解压静默数据截断：`core/src/io/Decompression.cc:55-89`

* 严重程度：中
* 类别：data_integrity
* CWE：CWE-20
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:N/I:L/A:L
* 描述：`decompressZlib` 仅调用一次 `inflate()` 并接受 `Z_OK`（部分解压）和 `Z_STREAM_END`（完整解压）均为成功。若解压数据超过 `shuffleCompressBlockSize`，`inflate` 返回 `Z_OK` 且 `avail_out = 0`，函数通过 `stream.total_out` 返回截断的数据。下游代码假设收到完整解压数据，处理截断的二进制结构可能导致越界读取或错误解析。

```cpp
err = inflate(&stream, Z_NO_FLUSH);
if (err != Z_STREAM_END && err != Z_OK) { ... }  // Z_OK 被接受 = 截断数据
return std::make_pair(output, stream.total_out);  // total_out 可能远小于期望
```

* 攻击场景：构造 zlib 压缩数据使其解压后超过 shuffleCompressBlockSize，导致下游处理截断数据。
* 修复建议：循环调用 inflate 直到 Z_STREAM_END，或在 inflate 后检查 `err == Z_STREAM_END` 时才视为成功。
* 置信度：7/10

---

# 发现 20：SpillReader 多处未校验的文件数据：`core/src/operator/spill/spill_merger.cpp:49-189`

* 严重程度：中
* 类别：insecure_deserialization
* CWE：CWE-20、CWE-190
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：SpillReader 从磁盘文件读取多个关键值未做充分校验：

**(a) rowCount 未校验 (line 49-65)**：`rowCount` 从 spill 文件读取为 raw `int32_t`，未校验 `rowCount > 0`。负值或零值可能导致异常行为。

**(b) 字符串长度从 offsets 计算 (line 104-124)**：`length = offsets[rowCount] - offsets[0]` 从文件读取的 offsets 计算，无上限校验。巨大的 length 值导致 `ExpandStringBuffer` 分配大量内存。

**(c) int64→int32 截断 (line 189, 229)**：Array/Map 向量的 `offsets[rowCount]` 为 `int64_t`，但被 `static_cast<int32_t>()` 截断为 `elementRowCount`。超过 INT32_MAX 的截断产生错误值，导致向量大小不足和后续缓冲区溢出。

**(d) 压缩块大小未校验 (line 147-158, 370-408)**：3字节压缩头解析为 `compressedSize`（最大约8.4MB），直接用于 `new char[compressed_block_size]` 分配和 fread，无校验其合理性。

* 攻击场景：修改本地 spill 文件中的 rowCount/offsets/compressedSize 值，触发未校验的数据处理路径。
* 修复建议：(a) 校验 rowCount > 0 且不超过 maxRowCount；(b) 校验 length <= maxStringLen；(c) 使用 int64_t 代替截断；(d) 校验 compressed_block_size 在合理范围内。
* 置信度：8/10

---

# 发现 21：DataType JSON 反序列化未校验：`core/src/type/data_type_serializer.cpp:23-37`

* 严重程度：中
* 类别：insecure_deserialization
* CWE：CWE-20
* CVSS 评分：6.0
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`Deserialize` 和 `DataTypeJsonParser` 从 JSON 字符串解析数据类型信息（来自 JNI/Spark 配置），但多个字段未校验：(1) `dataTypeId` 未识别时返回 nullptr，下游可能导致空指针解引用；(2) VARCHAR/CHAR 的 `WIDTH` 无上限校验，极大 width 导致过度内存分配；(3) DECIMAL 的 PRECISION/SCALE 无范围校验；(4) OMNI_CONTAINER/OMNI_ROW 类型递归解析可能导致栈溢出。此函数在 `jni_operator_factory.cpp` 中有超过 50 处调用。

```cpp
case OMNI_VARCHAR:
    return VarcharType(dataTypeJson[WIDTH].get<uint32_t>());  // WIDTH 无上限校验
case OMNI_DECIMAL64:
    return Decimal64Type(dataTypeJson[PRECISION].get<int32_t>(), dataTypeJson[SCALE].get<int32_t>());
    // PRECISION/SCALE 无范围校验
```

* 攻击场景：构造包含超大 WIDTH 或无效 dataTypeId 的 JSON 配置，触发过度分配或空指针崩溃。
* 修复建议：校验 dataTypeId 在有效范围内、WIDTH <= MAX_VARCHAR_WIDTH、PRECISION/SCALE 在有效范围内、限制递归深度。
* 置信度：7/10

---

# 发现 22：HDFS 连接缺少 Kerberos 认证配置：`core/src/reader/filesystem/hdfs_filesystem.cpp:102-117`

* 严重程度：中
* 类别：authentication_bypass
* CWE：CWE-306 (Missing Authentication for Critical Function)
* CVSS 评分：8.2
* CVSS 向量：CVSS:3.1/AV:A/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
* 描述：`HadoopFileSystem::Init()` 配置 HDFS 连接时仅设置 namenode host/port，未调用 `hdfsBuilderSetUserName`、`hdfsBuilderSetKerbTicketCachePath`、`hdfsBuilderSetToken` 等认证相关 API。在 Kerberos 保护的 Hadoop 集群中，此代码将回退到 "simple"（无认证）模式，允许未经身份验证的数据访问。

```cpp
struct hdfsBuilder *bld = hdfsNewBuilder();
hdfsBuilderSetNameNode(bld, nn.c_str());
hdfsBuilderSetNameNodePort(bld, options_.port_);
hdfsBuilderSetForceNewInstance(bld);
hdfsFS fileSystem = hdfsBuilderConnect(bld);  // 无认证配置
```

* 攻击场景：在同一网络上的攻击者可无需身份验证直接通过此连接访问 Kerberos 保护的 HDFS 集群数据。
* 修复建议：根据集群配置，调用 `hdfsBuilderSetKerbTicketCachePath` 或 `hdfsBuilderSetToken` 设置正确的认证信息。确保在 Kerberos 集群中不回退到 simple 认证模式。
* 置信度：9/10

---

## 排除的发现

以下发现按审查排除规则不列入报告：

| 排除原因 | 涉及内容 |
|---------|---------|
| DOS/资源耗尽（规则1） | Snappy/ZSTD 解压炸弹的内存耗尽影响、Regex 缓存刷洗性能退化、HDFS mutex 死锁 |
| 资源管理问题 | JNI GetIntArrayElements 未释放（jni_vector.cpp/jni_operator.cpp 内存钉住泄漏）、MemoryPool malloc 未初始化（加固缺失而非具体漏洞） |
| 加固措施缺失（规则4） | FileOutputStream 创建文件权限 0664（世界可读）、UUID v4 使用 mt19937（非安全场景）、SparkFile.cc 文件路径未消毒（配置来源可信） |
| 低置信度（规则8） | RadixSort memcpy len*rowWidth 溢出（64位平台上实际溢出难度极高，置信度5→排除） |
| 第三方库漏洞（规则6） | RE2/protobuf/snappy/zstd/zlib 库内部行为 |
| 测试文件（规则7） | 所有 core/test/ 和 bindings/java/src/test/ 下的发现 |

---

## 风险分布

```
严重程度分布：
高 ████████████████████ 9 个发现
中 ████████████████████████████ 13 个发现

类别分布：
反序列化/输入验证  ████████████ 7 个
整数溢出/截断      ████████ 5 个
内存边界违反       ████████ 4 个
路径遍历           ████ 2 个
代码执行/UDF安全   ██ 2 个
认证绕过           ██ 1 个
栈溢出/VLA         █ 1 个
```

---

## 最关键修复优先级

1. **发现 5（UDF 无沙箱 RCE）**：最严重的发现，可直接导致远程代码执行。优先添加 UDF 执行沙箱。
2. **发现 1-2（vector_marshaller 反序列化）**：高频攻击面，处理每行数据。添加缓冲区边界校验。
3. **发现 6（ORC VLA 栈溢出）**：影响所有读取 ORC 文件的场景。替换 VLA 为堆分配。
4. **发现 7（OmniBufferUnsafeV8）**：系统性的堆外内存无边界访问模式。添加 bounds check。
5. **发现 22（HDFS 认证缺失）**：在 Kerberos 集群中影响所有 HDFS 数据访问。添加认证配置。
