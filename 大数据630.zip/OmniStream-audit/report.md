# OmniStream 安全审查报告

## 项目概述

| 项目 | 详情 |
|------|------|
| 项目名称 | OmniStream — Kunpeng 大数据流处理加速框架 |
| 代码仓路径 | `C:\Users\汪恒生\Desktop\whsprogram\kunpeng-high\kunppengcode\OmniStream` |
| 主要编程语言 | C++ (核心运行时)、Java (JNI 桥接) |
| 代码规模 | 约 1991 文件 |
| 核心模块 | cpp/runtime (IO/Checkpoint/State)、cpp/jni (JNI桥接)、cpp/table (序列化/反序列化)、cpp/connector (Kafka)、cpp/core/udf (UDF加载)、cpp/streaming (流处理算子) |
| 审查日期 | 2026-06-13 |
| 审查范围 | 全仓源码（排除 third_party、test 目录） |

---

## 发现汇总

| # | 漏洞类型 | 严重程度 | CVSS | 文件路径 |
|---|----------|----------|------|----------|
| 1 | 任意代码执行（dlopen 未验证路径） | 高 | 9.8 | `cpp/core/udf/UDFLoader.h:131` |
| 2 | 堆缓冲区溢出（反序列化无边界验证） | 高 | 8.8 | `cpp/table/utils/VectorBatchDeserializationUtils.h:33-58` |
| 3 | 堆缓冲区溢出（offset/size 不匹配） | 高 | 8.8 | `cpp/table/utils/VectorBatchDeserializationUtils.h:152-176` |
| 4 | 堆缓冲区溢出（字典反序列化无边界验证） | 高 | 8.8 | `cpp/table/utils/VectorBatchDeserializationUtils.h:248-311` |
| 5 | 堆缓冲区溢出（length 超过固定缓冲区） | 高 | 8.8 | `cpp/table/typeutils/BinaryRowDataSerializer.cpp:38-45` |
| 6 | 反序列化列表大小未验证 | 高 | 8.1 | `cpp/table/typeutils/BinaryRowDataListSerializer.cpp:27` |
| 7 | JNI 任意内存访问（jlong 指针无验证） | 高 | 8.1 | `cpp/jni/io/jni_OmniStreamTaskNetworkInput.cpp:20-23` |
| 8 | TLS 证书验证绕过（配置白名单绕过） | 高 | 8.1 | `cpp/connector/kafka/source/KafkaSource.cpp:26-29` |
| 9 | JNI Use-After-Free（NativeBufferRecycler） | 高 | 6.5 | `cpp/jni/io/jni_NativeBufferRecycler.cpp:25-35` |
| 10 | 路径遍历（LookupJoinRunner connectorPath） | 高 | 7.5 | `cpp/table/runtime/operators/join/lookup/LookupJoinRunner.cpp:37` |
| 11 | Kafka 分片反序列化越界读取 | 高 | 7.5 | `cpp/connector/kafka/source/split/KafkaPartitionSplitSerializer.cpp:60` |
| 12 | 反序列化类型混淆（枚举未验证） | 高 | 7.5 | `cpp/table/utils/VectorBatchDeserializationUtils.h:65-90` |
| 13 | Checkpoint JSON 子串类名匹配 | 中 | 5.5 | `cpp/runtime/checkpoint/TaskStateSnapshotDeserializer.cpp:41-67` |
| 14 | 共享内存权限过宽（0666） | 中 | 5.5 | `cpp/core/utils/monitormmap/MetricManager.cpp:23` |
| 15 | 环境变量路径操纵（OMNI_HOME） | 中 | 5.5 | `cpp/connector/kafka/utils/ConfigLoader.cpp:21-30` |
| 16 | Sink 输出路径注入 | 中 | 5.5 | `cpp/streaming/api/operators/StreamOperatorFactory.cpp:113-114` |
| 17 | 环境变量信息泄露（System.getProperty） | 中 | 5.3 | `cpp/translate/thirdlibrary/java_lang_System.cpp:26` |
| 18 | INFO_RELEASE 常驻日志泄露内部信息 | 中 | 5.3 | `cpp/core/include/common.h:141-149` |

---

# 发现 1：任意代码执行：`cpp/core/udf/UDFLoader.h:131`

* 严重程度：高
* 类别：Code Injection
* CWE：CWE-94
* CVSS 评分：9.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H
* 描述：`UDFLoader::LoadUDFFunction` 使用 `dlopen()` 加载用户指定路径的共享库，路径来源于作业部署配置中的 `udf_so` 字段。代码未对路径执行任何验证（无白名单、无路径规范化、无签名校验、无沙箱隔离）。所有流处理算子（StreamMap、StreamFilter、StreamFlatMap、StreamGroupedReduce、ProcessOperator、KeyedCoProcess、StreamSource）均通过此机制加载 UDF 动态库。
* 攻击场景：攻击者提交一个 Flink 作业，在作业配置 JSON 中设置 `"udf_so": "/tmp/malicious.so"`。`dlopen()` 加载该库时，其 `__attribute__((constructor))` 函数立即执行，在 OmniStream 进程中以完整权限执行任意原生代码，实现远程代码执行。即使在无文件写入能力的场景下，攻击者也可引用系统中已有的库文件。
* 修复建议：(1) 对 UDF 动态库路径实施白名单机制，仅允许从受信任目录加载；(2) 在 `dlopen` 前对 `.so` 文件进行数字签名校验；(3) 使用 `seccomp` 或沙箱隔离 UDF 执行环境；(4) 至少对路径进行规范化并拒绝绝对路径和包含 `..` 的路径。
* 置信度：10/10

```cpp
// UDFLoader.h:128-131
template<typename FuncType>
FuncType* LoadUDFFunction(const std::string &filePath, const std::string &funcSignature)
{
    void* handle = dlopen(filePath.c_str(), RTLD_LAZY);  // filePath 未验证
```

---

# 发现 2：堆缓冲区溢出：`cpp/table/utils/VectorBatchDeserializationUtils.h:33-58`

* 严重程度：高
* 类别：Buffer Overflow
* CWE：CWE-787
* CVSS 评分：8.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`VectorBatchDeserializationUtils::deserializeVectorBatch` 从网络/检查点数据中直接读取 `batchSize`、`vectorCount`、`rowCnt` 三个 int32_t 字段，**未对任何字段进行边界验证**。`rowCnt` 用于分配 `VectorBatch(rowCnt)` 和控制 `memcpy_s` 的拷贝大小（`sizeof(int64_t) * rowCnt`）。恶意的 `rowCnt` 值可导致：(1) 堆缓冲区越界读取——`memcpy_s` 从源缓冲区读取超过实际数据量的字节；(2) 整数溢出——`sizeof(int64_t) * rowCnt` 在 `rowCnt > 268M` 时溢出 int32_t。
* 攻击场景：远程 TaskManager 或被篡改的检查点存储发送包含恶意 `rowCnt`（如 0x7FFFFFFF）的序列化 VectorBatch 数据。数据通过 JNI 网络输入路径（`jni_OmniStreamTaskNetworkInput.cpp:31`）进入 C++ 反序列化管线，最终到达此函数。`memcpy_s` 尝试从源缓冲区读取 `8 * 0x7FFFFFFF` 字节，远超实际可用数据，导致堆溢出或越界读取。
* 修复建议：(1) 在反序列化前验证所有 size 字段不超过剩余缓冲区长度；(2) 对 `rowCnt` 设置合理上限（如 1M）；(3) 传入缓冲区总长度参数并在每次 `memcpy_s` 前检查剩余空间；(4) 使用 `sizeof(size_t) * rowCnt` 替代 `sizeof(int64_t) * rowCnt` 防止整数溢出。
* 置信度：9/10

```cpp
// VectorBatchDeserializationUtils.h:37-54
int32_t batchSize;
memcpy_s(&batchSize, sizeof(batchSize), buffer, sizeof(batchSize));
buffer += sizeof(batchSize);

int32_t vectorCount;
memcpy_s(&vectorCount, sizeof(vectorCount), buffer, sizeof(vectorCount));
buffer += sizeof(vectorCount);

int32_t rowCnt = 0;
memcpy_s(&rowCnt, sizeof(rowCnt), buffer, sizeof(rowCnt));  // rowCnt 未验证
buffer += sizeof(rowCnt);

VectorBatch* batch = new VectorBatch(rowCnt);  // rowCnt 控制分配大小

memcpy_s(batch->getTimestamps(), sizeof(int64_t) * rowCnt, buffer,
         sizeof(int64_t) * rowCnt);  // 源缓冲区可能不够大
```

---

# 发现 3：堆缓冲区溢出：`cpp/table/utils/VectorBatchDeserializationUtils.h:152-176`

* 严重程度：高
* 类别：Buffer Overflow
* CWE：CWE-787
* CVSS 评分：8.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`deserializeCharVector` 从反序列化缓冲区读取 `stringBodySize` 和 `offsetArr[size]`，两者均为攻击者可控值，且代码**未验证 offsetArr[size] <= stringBodySize 的不变量关系**。`offsetArr[size]` 直接用于计算 `copySize = offsetArr[size] * sizeof(char)`，然后作为 `memcpy_s` 的拷贝大小。当 `offsetArr[size] > stringBodySize` 时，`memcpy_s` 将从源缓冲区读取超过实际数据量的字节到分配大小为 `stringBodySize` 的目标区域，造成堆溢出。
* 攻击场景：攻击者在序列化数据中设置 `stringBodySize=10` 但 `offsetArr[size]=100000`。`LargeStringContainer` 仅分配 10 字节的字符串体区域，但 `memcpy_s` 尝试写入 100000 字节，覆盖相邻堆对象，可能修改 vtable 指针等关键数据结构，进一步实现任意代码执行。
* 修复建议：(1) 验证 `offsetArr[size] <= stringBodySize`；(2) 验证 `sizeof(int32_t) * (size + 1)` 不超过剩余缓冲区长度；(3) 验证所有 offset 值单调递增且不超过 stringBodySize。
* 置信度：9/10

```cpp
// VectorBatchDeserializationUtils.h:155-173
int32_t stringBodySize;
memcpy_s(&stringBodySize, sizeof(int32_t), buffer, sizeof(int32_t));
buffer += sizeof(int32_t);

Vector<LargeStringContainer<std::string_view>> *charVector =
    new Vector<LargeStringContainer<std::string_view>>(size, stringBodySize);  // 按 stringBodySize 分配

int32_t *offsetArr = UnsafeStringVector::GetOffsets(charVector);
memcpy_s(offsetArr, sizeof(int32_t) * (size + 1), buffer,
         sizeof(int32_t) * (size + 1));  // offsetArr 来自网络数据

size_t copySize = offsetArr[size] * sizeof(char);  // offsetArr[size] 可能 > stringBodySize
memcpy_s(UnsafeStringVector::GetValues(charVector), copySize, buffer,
         copySize);  // 写入超过分配大小的数据 -> 堆溢出
```

---

# 发现 4：堆缓冲区溢出：`cpp/table/utils/VectorBatchDeserializationUtils.h:248-311`

* 严重程度：高
* 类别：Buffer Overflow
* CWE：CWE-787
* CVSS 评分：8.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`deserializeStringDictionaryContainerVector` 存在与发现 3 相同的漏洞模式。`dictSize`、`stringBodySize`、`offset[dictSize]` 均来自反序列化缓冲区且未验证。`new int32_t[rowCnt]` 的分配大小受 `rowCnt` 控制（同样未验证）。`LargeStringContainer(dictSize, stringBodySize)` 按 `stringBodySize` 分配，但 `memcpy_s` 使用 `offset[dictSize] * sizeof(char)` 作为拷贝大小，当 `offset[dictSize] > stringBodySize` 时产生堆溢出。
* 攻击场景：同发现 3。篡改的检查点数据或恶意网络数据通过相同的反序列化管线到达此函数。设置 `offset[dictSize]` 远大于 `stringBodySize` 实现堆写溢出。
* 修复建议：(1) 验证 `offset[dictSize] <= stringBodySize`；(2) 验证 `rowCnt`、`dictSize` 不超过剩余缓冲区长度；(3) 传入缓冲区总长度参数并在每次拷贝前验证。
* 置信度：9/10

```cpp
// VectorBatchDeserializationUtils.h:252-300
int32_t *values = new int32_t[rowCnt];  // rowCnt 未验证
memcpy_s(values, sizeof(int32_t) * rowCnt, buffer, sizeof(int32_t) * rowCnt);
// ...
int32_t dictSize = 0;
memcpy_s(&dictSize, sizeof(int32_t), buffer, sizeof(int32_t));  // dictSize 未验证
int32_t stringBodySize = 0;
memcpy_s(&stringBodySize, sizeof(int32_t), buffer, sizeof(int32_t));

auto stringContainer = std::make_shared<LargeStringContainer<std::string_view>>(
    dictSize, stringBodySize);  // 按 stringBodySize 分配

int32_t *offset = UnsafeStringContainer::GetOffsets(stringContainer.get());
memcpy_s(offset, sizeof(int32_t) * (dictSize + 1), buffer,
    sizeof(int32_t) * (dictSize + 1));  // offset 来自网络数据

ret = memcpy_s(UnsafeStringContainer::GetValues(stringContainer.get()),
               offset[dictSize] * sizeof(char), buffer,
               offset[dictSize] * sizeof(char));  // offset[dictSize] 可能 > stringBodySize -> 堆溢出
```

---

# 发现 5：堆缓冲区溢出：`cpp/table/typeutils/BinaryRowDataSerializer.cpp:38-45`

* 严重程度：高
* 类别：Buffer Overflow
* CWE：CWE-787
* CVSS 评分：8.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`BinaryRowDataSerializer::deserialize` 从反序列化流中读取 `length` 字段，目标缓冲区 `bytes` 仅为 `SEG_SIZE`（2048 字节，见第 19 行 `new uint8_t[SEG_SIZE]`）。代码在 `length > SEG_SIZE` 时仅输出警告日志，**但不拒绝操作**——`source.readFully(bytes, length, 0, length)` 仍然执行，将 `length` 字节写入 2048 字节的缓冲区，造成经典堆缓冲区溢出。
* 攻击场景：攻击者通过序列化数据设置 `length=100000`。`readFully` 将 100000 字节写入仅 2048 字节的 `bytes` 缓冲区，覆盖相邻堆对象的元数据（vtable 指针、大小字段），可能实现任意代码执行。此函数在网络数据处理和检查点恢复管线中被调用。
* 修复建议：(1) 当 `length > SEG_SIZE` 时抛出异常或返回错误，拒绝执行；(2) 使用动态大小的缓冲区替代固定 2048 字节缓冲区；(3) 在 `readFully` 前检查 `length <= getBufferCapacity()`。
* 置信度：10/10

```cpp
// BinaryRowDataSerializer.cpp:36-49
void *BinaryRowDataSerializer::deserialize(DataInputView &source)
{
    int length = source.readInt();  // length 来自反序列化数据

    auto bytes = reUse_->getSegment();  // 仅 2048 字节 (SEG_SIZE)
    if (length > SEG_SIZE) {
        LOG("Warning! Deserialize bytes length is " << length << ". Bigger than " << SEG_SIZE)
        // 仅警告，继续执行！
    }
    source.readFully(bytes, length, 0, length);  // length 字节写入 2048 字节缓冲区 -> 堆溢出
```

---

# 发现 6：反序列化列表大小未验证：`cpp/table/typeutils/BinaryRowDataListSerializer.cpp:27`

* 严重程度：高
* 类别：Input Validation
* CWE：CWE-20
* CVSS 评分：8.1
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`BinaryRowDataListSerializer::deserialize` 从反序列化流中读取 `size` 字段并立即用于循环控制 `for (int i = 0; i < size; ++i)`。`size` 无上限验证，每次迭代调用 `binaryRowDataSerializer->deserialize(source)`（发现 5 的堆溢出函数）和 `resPtr->copy()`（再分配一个 RowData）。此函数在 RocksDB MapState 反序列化（`RocksdbMapStateTable.h` 多处）和检查点恢复中被调用。
* 攻击场景：攻击者在检查点存储中注入 `size=0x7FFFFFFF` 的状态数据。每次迭代触发发现 5 的堆溢出，且持续分配 RowData 对象直至内存耗尽。与发现 5 组合形成多层级利用链：一个恶意 `size` 值即可反复触发堆溢出。
* 修复建议：(1) 对 `size` 设置合理上限（如 10000）；(2) 在循环中检查 `source` 的剩余可用数据量；(3) 组合修复发现 5（BinaryRowDataSerializer 的 length 检查）。
* 置信度：8/10

```cpp
// BinaryRowDataListSerializer.cpp:25-34
void* BinaryRowDataListSerializer::deserialize(DataInputView &source)
{
    int size = source.readInt();  // size 来自反序列化数据，无上限
    std::vector<RowData*>* result = new std::vector<RowData*>();
    for (int i = 0; i < size; ++i) {
        RowData* resPtr = reinterpret_cast<RowData*>(binaryRowDataSerializer->deserialize(source));
        result->push_back(resPtr->copy());  // 每次迭代再分配一个 RowData + 触发现 5 堆溢出
    }
    return result;
}
```

---

# 发现 7：JNI 任意内存访问：`cpp/jni/io/jni_OmniStreamTaskNetworkInput.cpp:20-23`

* 严重程度：高
* 类别：Untrusted Pointer
* CWE：CWE-822
* CVSS 评分：8.1
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：JNI 函数 `TNELProcessBuffer` 将 Java 侧传入的三个 `jlong` 参数直接通过 `reinterpret_cast` 转换为 C++ 对象指针：`omniStreamTaskRef -> StreamTask*`、`omniInputProcessorRef -> StreamOneInputProcessor*`、`address -> uint8_t*`。**无任何空值或有效性检查**。`address` 参数被用作内存缓冲区地址（`buffAddress + offset`），如果 Java 侧被入侵或存在 bug，恶意 jlong 值可导致 C++ 进程中的任意内存读写。
* 攻击场景：Java 侧被攻击者通过其他漏洞入侵后，向 JNI 函数传递精心构造的 `address` 值（如指向敏感数据的内存地址）。`reinterpret_cast<uint8_t *>(address)` 将该值转换为指针，`processor->processInput(buffAddress + offset, ...)` 读取或处理该地址处的数据，实现跨语言内存泄露或篡改。
* 修复建议：(1) 在所有 JNI 入口点对 jlong 参数进行范围验证（如检查是否为有效指针范围、是否为已知注册对象的地址）；(2) 使用句柄表（handle table）替代裸指针传递，Java 侧传递句柄 ID 而非内存地址；(3) 对 `address` 参数进行 null 检查。
* 置信度：9/10

```cpp
// jni_OmniStreamTaskNetworkInput.cpp:20-23
auto *streamTask = reinterpret_cast<omnistream::datastream::StreamTask *>(omniStreamTaskRef);
auto *processor = reinterpret_cast<omnistream::datastream::StreamOneInputProcessor *>(omniInputProcessorRef);
auto buffAddress = reinterpret_cast<uint8_t *>(address);
// 三个 jlong -> 指针，无任何验证
```

---

# 发现 8：TLS 证书验证绕过：`cpp/connector/kafka/source/KafkaSource.cpp:26-29`

* 严重程度：高
* 类别：Certificate Verification Bypass
* CWE：CWE-295
* CVSS 评分：8.1
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
* 描述：Kafka 消费者配置存在双路径不一致。JSON 配置路径通过 `ConsumerConfigUtil::GetConfig()` 白名单过滤（仅允许安全属性），但文件配置路径（`ConfigLoader::GetKafkaConsumerConfig()`）加载 `${OMNI_HOME}/conf/kafka_consumer.conf` 中的所有 `key=value` 配置项，**完全绕过白名单过滤**，直接传入 `rd_kafka_conf_set()`。这意味着通过配置文件可注入任意 rdkafka 属性，包括禁用 TLS 证书验证的属性。Kafka 生产者侧（`StreamOperatorFactory.cpp:706-712`）存在相同问题。
* 攻击场景：具有本地文件写入权限的攻击者在 `/opt/conf/kafka_consumer.conf` 中注入 `enable.ssl.certificate.verification=false` 或 `ssl.endpoint.identification.algorithm=`（空值）。OmniStream 进程启动时加载此配置，Kafka 连接不再验证 TLS 证书，攻击者可在网络中实施中间人攻击，截获或篡改 Kafka 数据流。由于配置在进程启动时全局加载（`g_consumer_config` 静态初始化），所有 Kafka 连接均受影响。
* 修复建议：(1) 对文件配置路径同样应用白名单过滤，仅允许安全属性通过；(2) 明确禁止 `enable.ssl.certificate.verification`、`ssl.endpoint.identification.algorithm`、`sasl.password` 等敏感属性的注入；(3) 对配置文件实施完整性校验（如文件权限检查、签名校验）。
* 置信度：9/10

```cpp
// KafkaSource.cpp:19-29 — JSON 配置经过白名单过滤
for (auto &[key, value] : properties.items()) {
    auto iter = ConsumerConfigUtil::GetConfig().find(key);
    if (iter != ConsumerConfigUtil::GetConfig().end() && iter->second != "") {  // 白名单过滤
        props.emplace(iter->second, value);
    }
}
// 文件配置路径：完全绕过白名单，全部传入
std::unordered_map<std::string, std::string> optConsumerConfig = ConfigLoader::GetKafkaConsumerConfig();
for (const auto &pair : optConsumerConfig) {
    props.emplace(pair.first, pair.second);  // 无过滤！
}
```

---

# 发现 9：JNI Use-After-Free：`cpp/jni/io/jni_NativeBufferRecycler.cpp:25-35`

* 严重程度：高
* 类别：Use-After-Free
* CWE：CWE-416
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:H
* 描述：`NativeBufferRecycler::freeNativeByteBuffer` 将 Java 侧传入的 `nativeViewReaderRef`（jlong）通过 `reinterpret_cast` 转换为 C++ 对象指针，然后对该指针执行 `dynamic_cast` 和方法调用。然而，`OmniCreditBasedSequenceNumberingViewReader` 可通过 `releaseNativeViewReader`（`jni_CreditBasedSequenceNumberingViewReader.cpp:52`）被释放删除。如果 Java GC 在 reader 被释放后调用 `freeNativeByteBuffer`，`reinterpret_cast` 产生指向已释放内存的指针，`dynamic_cast` 和方法调用构成 Use-After-Free。代码注释（`jni_CreditBasedSequenceNumberingViewReader.cpp:78`）明确承认了此可能性。
* 攻击场景：在高并发网络数据处理中，Java GC 回收 NativeBufferRecycler 对象并调用 `freeNativeByteBuffer` 时，对应的 ViewReader 可能已被另一线程释放。`dynamic_cast` 读取已释放内存中的类型信息，可能导致：(1) 类型混淆——dynamic_cast 返回意外类型；(2) 方法调用使用已释放对象的 vtable，可能调用任意函数；(3) 崩溃导致进程终止。
* 修复建议：(1) 使用引用计数或生命周期管理机制确保 ViewReader 在 BufferRecycler 回收前不被释放；(2) 在 `freeNativeByteBuffer` 中对指针进行有效性检查（如检查是否在已知对象注册表中）；(3) 使用句柄表替代裸指针传递。
* 置信度：9/10

```cpp
// jni_NativeBufferRecycler.cpp:25-35
auto nativeViewReader =
    reinterpret_cast<omnistream::BufferAvailabilityListener*>(nativeViewReaderRef);
    // nativeViewReaderRef 可能指向已释放的对象
if (auto creditReader = dynamic_cast<omnistream::OmniCreditBasedSequenceNumberingViewReader*>(nativeViewReader))
{
    creditReader->RecycleNettyBuffer(nativeByteBufferAddressRef);  // UAF: 调用已释放对象的方法
}
```

---

# 发现 10：路径遍历：`cpp/table/runtime/operators/join/lookup/LookupJoinRunner.cpp:37`

* 严重程度：高
* 类别：Path Traversal
* CWE：CWE-22
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N
* 描述：`LookupJoinRunner::open` 从 JSON 作业描述中直接读取 `description["connectorPath"]` 作为文件路径，**无任何验证或路径规范化**。该路径被传入 `CsvTableSource` 构造函数，后者使用 `std::ifstream file(filepath)` 打开文件。攻击者控制的 JSON 作业配置可设置任意文件路径。
* 攻击场景：攻击者提交 Flink 作业，在 JSON 配置中设置 `"connectorPath": "/etc/passwd"` 或 `"connectorPath": "/../../../etc/shadow"`。`CsvTableSource` 打开并读取该文件，将其内容作为 CSV 数据传入流处理管线，导致任意文件读取。敏感文件内容（密码、密钥、配置）通过流处理结果暴露给攻击者。
* 修复建议：(1) 对 `connectorPath` 进行路径规范化（使用 `realpath` 或 `canonicalize`）；(2) 检查并拒绝包含 `..` 的路径；(3) 限制文件路径必须在受信任目录下；(4) 对作业配置中的文件路径参数执行白名单校验。
* 置信度：9/10

```cpp
// LookupJoinRunner.cpp:34-41
std::string filepath;
if (connectorType == "filesystem") {
    filepath = description["connectorPath"];  // 直接从 JSON 读取，无验证
}
auto *src = new CsvTableSource(filepath, ...);  // filepath 传入 ifstream::open
```

---

# 发现 11：Kafka 分片反序列化越界读取：`cpp/connector/kafka/source/split/KafkaPartitionSplitSerializer.cpp:60`

* 严重程度：高
* 类别：Out-of-Bounds Read
* CWE：CWE-125
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N
* 描述：`KafkaPartitionSplitSerializer::deserialize` 从 `serialized` 向量中读取 `topicSize`（uint16_t），然后使用 `serialized.begin() + start + topicSize` 构造 `std::string`。**未检查 `start + topicSize <= serialized.size()`**。如果 `topicSize` 超过向量实际大小，迭代器越界访问（undefined behavior）。后续对 `partition`、`startingOffset`、`stoppingOffset` 的读取同样未验证偏移量是否在向量范围内。数据来源于检查点存储中的 Kafka 分片状态。
* 攻击场景：攻击者篡改检查点存储中的 Kafka 分片序列化数据，设置 `topicSize` 为极大值。反序列化时越界读取向量外的内存，可能泄露进程内存中的敏感数据。在 ARM 架构上，越界访问可能直接导致 SIGBUS/SIGSEGV。
* 修复建议：(1) 在读取 `topicSize` 后验证 `start + sizeof(int16_t) + topicSize <= serialized.size()`；(2) 对所有后续字段读取同样进行边界检查；(3) 在函数开始时验证 `serialized.size() >= MIN_EXPECTED_SIZE`。
* 置信度：7/10

```cpp
// KafkaPartitionSplitSerializer.cpp:60-70
uint16_t topicSize = (serialized[start] << ONE_BYTE_LENGTH) | serialized[start + 1];
start += sizeof(int16_t);
std::string topic(serialized.begin() + start,
                  serialized.begin() + start + topicSize);  // topicSize 未验证！可能越界
start += topicSize;
int32_t partition = (serialized[start] << ...) | ...;  // start 未验证
```

---

# 发现 12：反序列化类型混淆：`cpp/table/utils/VectorBatchDeserializationUtils.h:65-90`

* 严重程度：高
* 类别：Type Confusion
* CWE：CWE-843
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:H/A:H
* 描述：`deserializeVectorBatch` 从反序列化缓冲区读取 `encodingNum`（int8_t）和 `dataTypeNum`（int8_t），通过 `static_cast` 转换为 `Encoding` 和 `DataTypeId` 枚举，**无枚举值有效性验证**。两个关键问题：(1) 无效的 `encoding` 值（既非 `OMNI_FLAT` 也非 `OMNI_DICTIONARY`）导致迭代静默跳过——`vectorCount` 个向量应被添加但实际少于预期，后续操作访问错误索引；(2) 无效的 `dataType` 值进入 `deserializePrimitiveVector` 的 `switch`，有 `default` 分支抛异常但 `OMNI_FLAT` 和 `OMNI_DICTIONARY` 的条件分支外无 `else` 处理未知编码，造成数据不一致。
* 攻击场景：攻击者在序列化数据中设置 `encodingNum=99`（不在枚举定义内）。`static_cast<Encoding>(99)` 产生无效枚举值，`if (encoding == OMNI_FLAT)` 和 `else if (encoding == OMNI_DICTIONARY)` 均不匹配，向量未被添加到 batch。后续算子按 `vectorCount` 索引访问向量时越界或类型混淆，导致数据处理错误或崩溃。
* 修复建议：(1) 验证 `encodingNum` 和 `dataTypeNum` 是否在合法枚举范围内；(2) 为未知 `encoding` 值添加 `else` 分支抛出异常；(3) 在反序列化完成后验证 batch 中的向量数量与 `vectorCount` 一致。
* 置信度：8/10

```cpp
// VectorBatchDeserializationUtils.h:65-90
int8_t encodingNum;
memcpy_s(&encodingNum, sizeof(int8_t), buffer, sizeof(int8_t));
int8_t dataTypeNum;
memcpy_s(&dataTypeNum, sizeof(int8_t), buffer, sizeof(int8_t));
DataTypeId dataType = static_cast<DataTypeId>(dataTypeNum);  // 未验证枚举值
Encoding encoding = static_cast<Encoding>(encodingNum);       // 未验证枚举值

if (encoding == OMNI_FLAT) { ... }
else if (encoding == OMNI_DICTIONARY) { ... }
// 无 else 分支：未知 encoding 静默跳过，导致 vectorCount 不匹配
```

---

# 发现 13：Checkpoint JSON 子串类名匹配：`cpp/runtime/checkpoint/TaskStateSnapshotDeserializer.cpp:41-67`

* 严重程度：中
* 类别：Deserialization Type Confusion
* CWE：CWE-470
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`TaskStateSnapshotDeserializer::ParseKeyedStateHandle` 使用 `className.find("IncrementalRemoteKeyedStateHandle") != std::string::npos` 进行类型匹配，**使用子串匹配而非精确匹配**。任意包含目标子串的类名均可匹配对应分支，如 `"MaliciousIncrementalRemoteKeyedStateHandle"` 会匹配 `IncrementalRemoteKeyedStateHandle` 分支。数据来源于检查点存储中的 JSON（可能被篡改）。
* 攻击场景：攻击者篡改检查点存储中的状态快照 JSON，将 `@class` 字段设置为 `"EvilIncrementalRemoteKeyedStateHandle"`。子串匹配成功，进入 `ParseRemoteStateHandle` 分支。该分支解析 JSON 中的 `"data"` 字段（Base64 编码的二进制数据），攻击者可注入任意二进制数据作为序列化状态，触发下游 RocksDB/BinaryRowData 反序列化漏洞（与发现 5 组合）。
* 修复建议：(1) 使用 `className == "..."` 精确匹配替代 `find()` 子串匹配；(2) 或使用 `className.starts_with("完整包名前缀")` 进行更严格的匹配；(3) 对解析后的状态对象进行类型一致性校验。
* 置信度：7/10

```cpp
// TaskStateSnapshotDeserializer.cpp:41-67
const std::string className = j.at("@class").get<std::string>();
if (className.find("IncrementalRemoteKeyedStateHandle") != std::string::npos) {  // 子串匹配
    return ParseRemoteStateHandle(j);
}
if (className.find("DirectoryKeyedStateHandle") != std::string::npos) { ... }
// 任意包含子串的类名均可匹配
```

---

# 发现 14：共享内存权限过宽：`cpp/core/utils/monitormmap/MetricManager.cpp:23`

* 严重程度：中
* 类别：Incorrect Permission Assignment
* CWE：CWE-732
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`MetricManager` 创建 POSIX 共享内存时使用 `0666` 模式（`shm_open` 在第 59、110 行），授予系统中所有用户（owner/group/others）读写权限。共享内存键名为 `"OMNI_SHM_METRIC"`（硬编码前缀），任何本地用户均可通过 `shm_open("OMNI_SHM_METRIC_XXX", O_RDWR)` 打开并读写此共享内存。
* 攻击场景：本地低权限用户通过 `shm_open` 打开 OmniStream 指标共享内存，读取运行时指标数据（线程 ID、探测 ID、时间信息）获取系统内部状态信息；或写入虚假指标数据干扰监控功能、注入误导性的性能数据。
* 修复建议：(1) 将 `sharedMemoryFDMode` 从 `0666` 改为 `0600`（仅 owner 可读写）或 `0660`（owner+group）；(2) 使用 `fchown` 设置共享内存的 group 为 OmniStream 专用组。
* 置信度：9/10

```cpp
// MetricManager.cpp:23
const int MetricManager::sharedMemoryFDMode = 0666;  // 所有用户可读写

// 第 59 行
sharedMemoryFd = shm_open(sharedMemoryKey.c_str(), O_RDWR, sharedMemoryFDMode);
// 第 110 行
sharedMemoryFd = shm_open(sharedMemoryKey.c_str(), O_CREAT | O_RDWR, sharedMemoryFDMode);
```

---

# 发现 15：环境变量路径操纵：`cpp/connector/kafka/utils/ConfigLoader.cpp:21-30`

* 严重程度：中
* 类别：Insecure Environmental Variable
* CWE：CWE-426
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`ConfigLoader::GetOmniHome` 从 `OMNI_HOME` 环境变量读取路径，仅去除空白字符（Trim），**未进行路径安全验证**。`OMNI_HOME` 直接与硬编码的 `/conf/kafka_consumer.conf` 拼接后加载 Kafka 配置。虽然 `realpath()` 在 `LoadKafkaConfig` 中被调用，但它解析了包含 `../` 的路径后仍会读取攻击者放置的配置文件。默认路径 `/opt` 是可预测的系统位置。
* 攻击场景：(1) 攻击者设置 `OMNI_HOME=/opt/../../etc`，配置路径解析为 `/etc/conf/kafka_consumer.conf`；(2) 攻击者在解析路径下放置包含 `enable.ssl.certificate.verification=false` 的配置文件；(3) OmniStream 启动时加载此配置，与发现 8 组合实现 TLS 验证绕过。在容器环境中，环境变量通常由部署系统设置，攻击者可通过容器配置错误获得控制权。
* 修复建议：(1) 对 `OMNI_HOME` 进行路径安全验证：拒绝包含 `..` 的路径、验证路径必须是绝对路径、验证路径存在且为受信任目录；(2) 使用 `realpath` 解析后验证路径仍在受信任目录树下；(3) 为配置文件实施完整性校验。
* 置信度：7/10

```cpp
// ConfigLoader.cpp:21-30
static std::string GetOmniHome()
{
    auto omniHome = std::getenv("OMNI_HOME");  // 环境变量，未验证
    if (omniHome != nullptr && omniHome[0] != '\0') {
        std::string confDir { omniHome };
        Trim(confDir);  // 仅去除空白，不验证路径安全
        return confDir;
    } else {
        return "/opt";  // 可预测的默认路径
    }
}
```

---

# 发现 16：Sink 输出路径注入：`cpp/streaming/api/operators/StreamOperatorFactory.cpp:113-114`

* 严重程度：中
* 类别：Path Traversal
* CWE：CWE-22
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:N/I:L/A:L
* 描述：`StreamOperatorFactory::CreateSinkOp` 使用 `opConfig.getName()`（来自作业配置 JSON）构造输出文件路径：`"/tmp/" + opConfig.getName() + ".txt"`。`getName()` 的值未经过验证，包含 `../../` 的名称导致路径遍历。`SinkOperator` 以追加模式（`std::ios::out | std::ios::app`）打开此路径写入数据。
* 攻击场景：攻击者在作业配置中设置算子名称为 `"../../etc/crontab"`。构造的路径为 `/tmp/../../etc/crontab.txt` -> `/etc/crontab.txt`。SinkOperator 向 `/etc/crontab.txt` 追加流处理输出数据，可能向 cron 系统注入恶意定时任务。
* 修复建议：(1) 对 `opConfig.getName()` 进行路径安全验证：拒绝包含 `/`、`\`、`..` 的名称；(2) 使用 `realpath` 规范化路径后验证仍在 `/tmp` 目录下；(3) 仅允许字母数字和下划线的算子名称。
* 罝信度：7/10

```cpp
// StreamOperatorFactory.cpp:113-114
if (opConfig.getName() != "") {
    object["outputfile"] = "/tmp/" + opConfig.getName() + ".txt";  // getName 未验证
} else {
    object["outputfile"] = "/tmp/sink.txt";
}
```

---

# 发现 17：环境变量信息泄露：`cpp/translate/thirdlibrary/java_lang_System.cpp:26`

* 严重程度：中
* 类别：Information Exposure
* CWE：CWE-200
* CVSS 评分：5.3
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:L/I:N/A:N
* 描述：`java_lang_System::getProperty` 接受任意 `String*` key 参数，调用 `getenv(key->toString().c_str())` 返回对应环境变量的值。**无任何键名验证或过滤**，Java 侧可通过此函数读取进程的任意环境变量。
* 攻击场景：恶意或被入侵的 Java 组件调用 `System.getProperty("LD_LIBRARY_PATH")`、`System.getProperty("OMNI_HOME")`、`System.getProperty("PATH")` 等获取关键环境变量值。泄露的路径信息可用于规划路径遍历攻击（发现 10、15、16），泄露的库路径可用于规划动态库注入（发现 1）。
* 修复建议：(1) 对允许查询的环境变量键名实施白名单（仅允许 `user.dir`、`user.home` 等安全键名）；(2) 拒绝查询 `PATH`、`LD_LIBRARY_PATH`、`OMNI_HOME`、`JAVA_HOME` 等敏感键名；(3) 返回脱敏值而非完整值。
* 罝信度：7/10

```cpp
// java_lang_System.cpp:20-31
String* java_lang_System::getProperty(String* key)
{
    if (key == nullptr) { return nullptr; }
    const char* value = getenv(key->toString().c_str());  // 任意键名，无过滤
    if (value == nullptr) { return nullptr; }
    return new String(std::string(value));  // 返回完整值
}
```

---

# 发现 18：INFO_RELEASE 常驻日志泄露内部信息：`cpp/core/include/common.h:141-149`

* 严重程度：中
* 类别：Information Exposure Through Logging
* CWE：CWE-200
* CVSS 评分：5.3
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:N/A:N
* 描述：`INFO_RELEASE` 宏（`common.h:141-149`）在所有构建模式下均输出到 `std::cout`（不受 `#ifdef DEBUG` 控制，与 `LOG` 宏不同）。多处代码使用 `INFO_RELEASE` 输出异常详情（`e.what()`），泄露内部路径、配置详情和错误描述。关键泄漏点包括：`OmniAbstractStreamTaskNetworkInput.h:291`（网络处理异常）、`OmniTask.cpp:240`（任务恢复异常）、`StreamTaskStateInitializerImpl.h:413`（状态创建失败异常）、`RecoveredChannelStateHandler.cpp:66,202`（检查点恢复异常）。
* 攻击场景：攻击者通过触发特定异常条件（如发送畸形网络数据），观察 `stdout` 输出获取：内部文件路径、RocksDB 配置、序列化器名称、状态后端类型等。这些信息可用于规划针对性攻击（如路径遍历目标选择、反序列化攻击的精确构造）。
* 修复建议：(1) 将 `INFO_RELEASE` 宏改为受 `#ifdef DEBUG` 控制，在发布构建中禁用；(2) 在生产构建中使用结构化日志框架替代 `std::cout`；(3) 对异常信息进行脱敏处理，不输出内部路径和配置细节。
* 罝信度：8/10

```cpp
// common.h:141-149 — 所有构建模式均激活
#define INFO_RELEASE(msg) do { \
    ... \
    std::cout << "[" << "INFO" << "] ... " << msg << std::endl; \
    std::cout.flush(); \
    } while (false);

// 使用示例（多处）:
INFO_RELEASE("processForDataStream exception:" << e.what());  // 泄露异常详情
INFO_RELEASE("Error:create keyedStatedBackend failed: " << ex.what());  // 泄露内部配置
```

---

## 攻击链分析

### 链路 1：远程 TaskManager -> 反序列化堆溢出 -> RCE

```
恶意远程 TaskManager
  → 发送 crafted 网络缓冲区
  → jni_OmniStreamTaskNetworkInput.cpp:31 (JNI 入口, 发现 7)
  → SpillingAdaptiveSpanningRecordDeserializer
  → StreamElementSerializer::deserialize
  → VectorBatchDeserializationUtils::deserializeVectorBatch (发现 2)
  → rowCnt 未验证 -> memcpy_s 堆越界读取
  → deserializeCharVector (发现 3) -> offsetArr/stringBodySize 不匹配 -> 堆写溢出
  → BinaryRowDataSerializer::deserialize (发现 5) -> length > SEG_SIZE -> 堆溢出
```

**风险评估**：远程攻击者可通过网络数据流直接触发堆溢出，最严重的路径是发现 3（偏移量/大小不匹配的堆写溢出），可覆盖相邻堆对象的 vtable 指针，潜在实现任意代码执行。

### 链路 2：UDF 动态库加载 -> 任意代码执行

```
恶意作业提交者
  → Flink 作业配置 JSON: "udf_so": "/tmp/malicious.so"
  → JNI 桥接 -> StreamOperatorFactory -> 算子 loadUdf()
  → UDFLoader::LoadUDFFunction (发现 1)
  → dlopen("/tmp/malicious.so", RTLD_LAZY)
  → 共享库 constructor 执行 -> 完整进程权限的任意代码
```

**风险评估**：最直接、最高风险的攻击路径。仅需作业提交权限即可实现 RCE，无需任何复杂漏洞利用技术。

### 链路 3：检查点篡改 -> 反序列化漏洞 -> 堆溢出

```
攻击者篡改检查点存储 (HDFS/S3)
  → TaskStateSnapshotDeserializer (发现 13, 子串匹配)
  → 注入恶意 JSON @class 字段
  → Base64 解码注入二进制状态数据
  → RocksDB State 反序列化
  → BinaryRowDataSerializer::deserialize (发现 5) -> 堆溢出
  → BinaryRowDataListSerializer::deserialize (发现 6) -> 反复触发堆溢出
```

**风险评估**：需要检查点存储的写入权限，但在云部署中检查点存储（如 HDFS）的访问控制可能较宽松。一旦获得写入权限，可实现完整的反序列化攻击链。

### 链路 4：Kafka 配置注入 -> TLS 绕过 -> 中间人攻击

```
本地攻击者
  → 写入 /opt/conf/kafka_consumer.conf (发现 15, OMNI_HOME 默认路径)
  → 注入 enable.ssl.certificate.verification=false (发现 8, 白名单绕过)
  → OmniStream 进程启动 -> 加载配置 -> Kafka 连接无 TLS 验证
  → 网络中间人截获/篡改 Kafka 数据流
```

**风险评估**：本地攻击向远程攻击升级的桥梁。TLS 绕过后，攻击者可在网络层面截获和篡改流处理数据，进一步注入触发反序列化漏洞的恶意数据（链路 1）。

---

## 修复优先级建议

| 优先级 | 发现编号 | 修复要点 |
|--------|----------|----------|
| P0（立即修复） | 1 | UDF dlopen 路径白名单/签名校验 |
| P0（立即修复） | 2,3,4,5 | 反序列化边界验证 + 动态缓冲区 |
| P1（尽快修复） | 8 | Kafka 文件配置白名单过滤 |
| P1（尽快修复） | 7 | JNI jlong 指针验证/句柄表 |
| P1（尽快修复） | 10 | 文件路径规范化 + `..` 检查 |
| P2（计划修复） | 6,9,11,12,13 | 反序列化大小验证/UAF 修复/枚举校验 |
| P3（持续改进） | 14,15,16,17,18 | 权限收紧/路径验证/日志脱敏 |

---

## 审查方法说明

本次审查采用以下方法：
1. **结构分析**：扫描代码仓目录结构，识别核心模块和高风险目录
2. **模式搜索**：使用正则表达式在全部源码中搜索高风险模式（memcpy/malloc/dlopen/system/ifstream/reinterpret_cast/getenv 等）
3. **数据流追踪**：从 JNI 入口和网络入口追踪数据流至反序列化终点，验证攻击可达性
4. **代码审读**：对每个高风险文件进行详细代码审读，验证漏洞的具体存在性和可利用性
5. **排除过滤**：按规则排除 DOS、磁盘密钥、速率限制、加固缺失、理论性竞态、第三方库、测试文件、低置信度发现
