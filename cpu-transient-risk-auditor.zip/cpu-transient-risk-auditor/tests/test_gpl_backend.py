import unittest

from ctra.gpl.backend import REFERENCE_SCRIPT, parse_json
from ctra.gpl.affectedness import apply_gpl_refactored_affectedness
from ctra.gpl.catalog import load_catalog
from ctra.gpl.constants import load_cpu_constants
from ctra.gpl.inteldb import load_intel_affected_db, lookup_intel_affected
from ctra.gpl.microcode import apply_gpl_microcode_knowledge, load_bpi_fix_table, load_blacklisted_microcodes, load_reptar_fix_table
from ctra.gpl.normalizer import aggregate_status, normalize_vulnerabilities
from ctra.model import HostFacts


class GplBackendTests(unittest.TestCase):
    def test_catalog_parses_vendored_registry(self):
        catalog = load_catalog(REFERENCE_SCRIPT)
        cves = {entry.cve for entry in catalog}
        self.assertGreaterEqual(len(catalog), 32)
        self.assertIn("CVE-2017-5715", cves)
        self.assertIn("CVE-2025-54505", cves)

    def test_parse_json_tolerates_prefix_noise(self):
        payload = parse_json("warning\n{\"vulnerabilities\": []}\n")
        self.assertEqual(payload, {"vulnerabilities": []})

    def test_normalize_vulnerabilities(self):
        items = normalize_vulnerabilities(
            {
                "vulnerabilities": [
                    {"cve": "CVE-1", "status": "VULNERABLE"},
                    {"cve": "CVE-2", "vulnerable": False},
                    {"id": "CVE-3", "status": "UNKNOWN"},
                ]
            }
        )
        self.assertEqual([item.status for item in items], ["VULNERABLE", "OK", "UNKNOWN"])
        self.assertEqual(aggregate_status(items), "VULNERABLE")

    def test_constants_parse_cpu_model_database(self):
        constants = load_cpu_constants(REFERENCE_SCRIPT)
        self.assertEqual(constants["INTEL_FAM6_SKYLAKE_X"], 0x55)
        self.assertEqual(constants["INTEL_FAM6_ATOM_GOLDMONT"], 0x5C)
        self.assertEqual(constants["INTEL_FAM6_XEON_PHI_KNM"], 0x85)

    def test_gpl_refactored_goldmont_mds_and_mmio_immunity(self):
        facts = HostFacts(cpu_vendor="GenuineIntel", cpu_family=6, cpu_model=0x5C)
        apply_gpl_refactored_affectedness(facts)
        self.assertIn("CVE-2018-12126", facts.cpu_not_affected)
        self.assertIn("CVE-2018-12130", facts.cpu_not_affected)
        self.assertIn("CVE-2022-21123", facts.cpu_not_affected)

    def test_gpl_refactored_msbds_only_keeps_msbds_possible(self):
        facts = HostFacts(cpu_vendor="GenuineIntel", cpu_family=6, cpu_model=0x37)
        apply_gpl_refactored_affectedness(facts)
        self.assertNotIn("CVE-2018-12126", facts.cpu_not_affected)
        self.assertIn("CVE-2018-12130", facts.cpu_not_affected)
        self.assertIn("CVE-2019-11091", facts.cpu_not_affected)

    def test_gpl_refactored_rdcl_no_also_marks_l1tf(self):
        facts = HostFacts(
            cpu_vendor="GenuineIntel",
            cpu_family=6,
            cpu_model=0x55,
            cpu_capabilities={"rdcl_no": True},
        )
        apply_gpl_refactored_affectedness(facts)
        self.assertIn("CVE-2017-5754", facts.cpu_not_affected)
        self.assertIn("CVE-2018-3646", facts.cpu_not_affected)

    def test_gpl_refactored_amd_mds_mmio_l1tf_immunity(self):
        facts = HostFacts(cpu_vendor="AuthenticAMD", cpu_family=0x17)
        apply_gpl_refactored_affectedness(facts)
        self.assertIn("CVE-2018-12126", facts.cpu_not_affected)
        self.assertIn("CVE-2022-21166", facts.cpu_not_affected)
        self.assertIn("CVE-2018-3620", facts.cpu_not_affected)

    def test_gpl_refactored_intel_db_affects_and_exempts(self):
        facts = HostFacts(cpu_vendor="GenuineIntel", cpu_signature="0x0005065A", cpu_flags=set())
        apply_gpl_refactored_affectedness(facts)
        self.assertIn("CVE-2017-5715", facts.cpu_affectedness)
        self.assertIn("CVE-2017-5754", facts.cpu_not_affected)
        self.assertIn("CVE-2018-3615", facts.cpu_not_affected)

    def test_intel_affected_db_parses_and_looks_up_signature(self):
        entries = load_intel_affected_db(REFERENCE_SCRIPT)
        self.assertGreaterEqual(len(entries), 80)
        entry = lookup_intel_affected("0x00050654", script_path=REFERENCE_SCRIPT)
        self.assertIsNotNone(entry)
        self.assertIn("CVE-2017-5754", entry.cves)

    def test_gpl_microcode_tables_parse(self):
        reptar = load_reptar_fix_table(REFERENCE_SCRIPT)
        bpi = load_bpi_fix_table(REFERENCE_SCRIPT)
        blacklist = load_blacklisted_microcodes(REFERENCE_SCRIPT)
        self.assertGreaterEqual(len(reptar), 20)
        self.assertGreaterEqual(len(bpi), 30)
        self.assertGreaterEqual(len(blacklist), 20)

    def test_gpl_microcode_reptar_marks_current_or_outdated(self):
        facts = HostFacts(
            cpu_vendor="GenuineIntel",
            cpu_family=6,
            cpu_model=0x97,
            cpu_stepping=2,
            cpu_signature="0x00090672",
            cpu_platform_id_mask=0x01,
            microcode="0x31",
        )
        apply_gpl_microcode_knowledge(facts)
        self.assertEqual(facts.cpu_affectedness["CVE-2023-23583"]["microcode_status"], "outdated")
        facts.microcode = "0x32"
        facts.cpu_affectedness.clear()
        apply_gpl_microcode_knowledge(facts)
        self.assertIn("CVE-2023-23583", facts.cpu_not_affected)

    def test_gpl_microcode_blacklist(self):
        facts = HostFacts(cpu_vendor="GenuineIntel", cpu_family=6, cpu_model=0x9E, cpu_stepping=0x0B, microcode="0x80")
        apply_gpl_microcode_knowledge(facts)
        self.assertEqual(facts.microcode_status, "blacklisted")


if __name__ == "__main__":
    unittest.main()
