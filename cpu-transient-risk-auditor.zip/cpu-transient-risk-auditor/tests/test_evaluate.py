import unittest

from ctra.collect import collect
from ctra.capabilities import decode_capabilities
from ctra.affected import apply_builtin_affectedness
from ctra.evaluate import evaluate, normalize_sysfs_status, summarize
from ctra.model import HostFacts, Policy, Report, ScanMetadata, Summary
from ctra.reference_backend import attach_reference
from ctra.rules import RULES
from ctra.vendor import load_vendor_data, match_vendor_advisories


class EvaluateTests(unittest.TestCase):
    def test_normalize_sysfs_status(self):
        self.assertEqual(normalize_sysfs_status("Not affected"), "OK")
        self.assertEqual(normalize_sysfs_status("Mitigation: PTI"), "OK")
        self.assertEqual(normalize_sysfs_status("KVM: Mitigation: VMX disabled"), "OK")
        self.assertEqual(normalize_sysfs_status("Vulnerable: SMT vulnerable"), "VULNERABLE")
        self.assertEqual(normalize_sysfs_status("Unknown: no data"), "UNKNOWN")

    def test_collects_deeper_host_facts(self):
        facts = collect("tests/fixtures/linux-host")
        self.assertEqual(facts.cpu_family, 6)
        self.assertEqual(facts.cpu_model, 85)
        self.assertEqual(facts.cpu_stepping, 7)
        self.assertEqual(facts.microcode, "0x5003604")
        self.assertEqual(facts.os_release["ID"], "fixture")
        self.assertEqual(facts.kernel_config["CONFIG_RETPOLINE"], "y")
        self.assertEqual(facts.kernel_cmdline_findings["spectre_v2_user_off"], "present")

    def test_fixture_prioritizes_hypervisor_l1tf(self):
        facts = collect("tests/fixtures/linux-host")
        findings = {finding.key: finding for finding in evaluate(facts)}

        self.assertIs(facts.smt_enabled, True)
        self.assertIs(facts.hypervisor_host, True)
        self.assertEqual(findings["l1tf_vmm"].verdict, "vulnerable")
        self.assertEqual(findings["l1tf_vmm"].priority, "P1")
        self.assertTrue(findings["l1tf_vmm"].remediation)
        self.assertEqual(findings["spectre_v2"].priority, "P2")
        self.assertEqual(findings["taa"].priority, "P2")
        l1tf_evidence_keys = {evidence.key for evidence in findings["l1tf_vmm"].evidence}
        self.assertIn("microcode", l1tf_evidence_keys)
        spectre_v2_evidence_keys = {evidence.key for evidence in findings["spectre_v2"].evidence}
        self.assertIn("spectre_v2_user_off", spectre_v2_evidence_keys)
        self.assertIn("CONFIG_RETPOLINE", spectre_v2_evidence_keys)
        self.assertIn("ibrs_ibpb", spectre_v2_evidence_keys)

    def test_summary_exit_code(self):
        facts = collect("tests/fixtures/linux-host")
        policy = Policy(fail_on_priority="P2")
        summary = summarize(evaluate(facts, policy), policy)
        self.assertEqual(summary.highest_priority, "P1")
        self.assertEqual(summary.exit_code, 11)

    def test_vendor_data_matching(self):
        facts = collect("tests/fixtures/linux-host")
        vendor_data = load_vendor_data("vendor-data.example.json")
        facts.vendor_advisories = match_vendor_advisories(facts, vendor_data)
        findings = {finding.key: finding for finding in evaluate(facts)}
        l1tf_sources = {evidence.source for evidence in findings["l1tf_vmm"].evidence}
        self.assertIn("vendor_advisory", l1tf_sources)

    def test_cpuid_msr_capability_decode(self):
        facts = HostFacts(
            cpuid={
                "leaf_7_0_ebx": "0x00010820",
                "leaf_7_0_edx": "0xb4000400",
                "leaf_80000008_ebx": "0x150c0000",
            },
            msr={
                "ia32_spec_ctrl": "0x0000000000000407",
                "ia32_arch_capabilities": "0x0000000008b62b3f",
                "ia32_tsx_ctrl": "0x0000000000000003",
                "ia32_mcu_opt_ctrl": "0x0000000000000001",
            },
        )
        decode_capabilities(facts)
        self.assertTrue(facts.cpu_capabilities["md_clear"])
        self.assertTrue(facts.cpu_capabilities["rtm"])
        self.assertTrue(facts.cpu_capabilities["avx512f"])
        self.assertTrue(facts.cpu_capabilities["ibrs_ibpb"])
        self.assertTrue(facts.cpu_capabilities["stibp_enabled"])
        self.assertTrue(facts.cpu_capabilities["ssbd_enabled"])
        self.assertTrue(facts.cpu_capabilities["bhi_dis_s_enabled"])
        self.assertTrue(facts.cpu_capabilities["rfds_no"])
        self.assertTrue(facts.cpu_capabilities["sbdr_ssdp_no"])
        self.assertFalse(facts.cpu_capabilities["fbsdp_no"])
        self.assertTrue(facts.cpu_capabilities["rtm_disabled"])
        self.assertTrue(facts.cpu_capabilities["gds_mitigation_disabled"])

    def test_builtin_not_affected_overrides_missing_sysfs(self):
        facts = HostFacts(
            cpu_vendor="GenuineIntel",
            machine="x86_64",
            cpuid={"leaf_7_0_edx": "0x20000000"},
            msr={"ia32_arch_capabilities": "0x0000000000000001"},
        )
        decode_capabilities(facts)
        apply_builtin_affectedness(facts)
        findings = {finding.key: finding for finding in evaluate(facts)}
        self.assertEqual(findings["meltdown"].verdict, "not_vulnerable")
        self.assertEqual(findings["meltdown"].priority, "OK")
        sources = {evidence.source for evidence in findings["meltdown"].evidence}
        self.assertIn("cpu_affectedness", sources)

    def test_reference_backend_augments_unknown_finding(self):
        facts = HostFacts()
        finding = evaluate(facts, rules=tuple(rule for rule in RULES if rule.key == "spectre_v2"))[0]
        report = Report(
            tool={"name": "test", "version": "0"},
            policy=Policy(),
            scan=ScanMetadata(),
            asset={},
            host=facts,
            summary=Summary(total=1),
            findings=[finding],
        )
        attach_reference(
            report,
            {
                "report": {
                    "vulnerabilities": [
                        {
                            "cve": "CVE-2017-5715",
                            "status": "VULNERABLE",
                            "description": "reference says vulnerable",
                        }
                    ]
                }
            },
            "augment",
        )
        self.assertEqual(report.findings[0].verdict, "vulnerable")
        self.assertTrue(any(evidence.source == "gpl_reference_backend" for evidence in report.findings[0].evidence))


if __name__ == "__main__":
    unittest.main()
