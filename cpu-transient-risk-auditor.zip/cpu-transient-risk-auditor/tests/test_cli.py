import json
import gzip
from pathlib import Path
import subprocess
import sys
import unittest
import xml.etree.ElementTree as ET


class CliTests(unittest.TestCase):
    def test_cli_default_command(self):
        result = subprocess.run(
            [sys.executable, "-m", "ctra"],
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("CPU Transient-Execution Risk Report", result.stdout)

    def test_cli_default_command_accepts_scan_args(self):
        result = subprocess.run(
            [sys.executable, "-m", "ctra", "--root", "tests/fixtures/linux-host", "--format", "json", "--cve", "CVE-2017-5754"],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["summary"]["total"], 1)
        self.assertEqual(payload["findings"][0]["key"], "meltdown")

    def test_cli_json_fixture(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["tool"]["name"], "cpu-transient-risk-auditor")
        self.assertTrue(any(item["key"] == "l1tf_vmm" and item["priority"] == "P1" for item in payload["findings"]))

    def test_cli_schema(self):
        result = subprocess.run(
            [sys.executable, "-m", "ctra", "schema"],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["title"], "CPU Transient Risk Auditor Report")
        self.assertIn("scan", payload["required"])

    def test_cli_coverage(self):
        result = subprocess.run(
            [sys.executable, "-m", "ctra", "coverage", "--format", "json"],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertGreaterEqual(payload["rule_count"], 32)
        self.assertEqual(payload["missing_reference_families"], [])
        self.assertGreaterEqual(payload["gpl_reference"]["catalog_entries"], 32)
        self.assertIn("CVE-0000-0001", payload["gpl_reference"]["native_missing_cves"])

    def test_cli_cve_selection(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--cve",
                "CVE-2017-5715",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["summary"]["total"], 1)
        self.assertEqual(payload["findings"][0]["key"], "spectre_v2")
        self.assertEqual(payload["scan"]["selected_cves"], ["CVE-2017-5715"])
        self.assertEqual(payload["scan"]["selected_rule_count"], 1)

    def test_cli_variant_and_errata_selection(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--variant",
                "zenbleed",
                "--errata",
                "3194386",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual({item["key"] for item in payload["findings"]}, {"zenbleed", "arm_ssbs_nosync"})

    def test_cli_family_variant_selection(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--variant",
                "mds",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual({item["key"] for item in payload["findings"]}, {"msbds", "mfbds", "mlpds", "mdsum"})

    def test_cli_sysfs_only_mode(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--sysfs-only",
                "--variant",
                "l1tf_vmm",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["summary"]["total"], 1)
        self.assertEqual(payload["findings"][0]["verdict"], "vulnerable")
        self.assertEqual(payload["host"]["cpu_vendor"], None)
        self.assertEqual(payload["scan"]["mode"], "sysfs-only")
        self.assertTrue(payload["scan"]["reduced_accuracy"])

    def test_cli_no_runtime_mode_metadata(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--no-runtime",
                "--kernel-image",
                "tests/fixtures/vmlinux.sample",
                "--variant",
                "spectre_v2",
                "--cpu",
                "all",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["scan"]["mode"], "no-runtime")
        self.assertEqual(payload["scan"]["cpu_selector"], "all")
        self.assertTrue(payload["scan"]["reduced_accuracy"])
        self.assertEqual(payload["host"]["kernel_release"], None)
        self.assertEqual(payload["findings"][0]["verdict"], "not_vulnerable")
        self.assertEqual(payload["findings"][0]["confidence"], "medium")

    def test_cli_html_fixture(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "html",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("<!doctype html>", result.stdout)
        self.assertIn("L1 Terminal Fault", result.stdout)
        self.assertIn("OK=0", result.stdout)

    def test_cli_sarif_fixture(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "sarif",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["version"], "2.1.0")
        self.assertTrue(payload["runs"][0]["results"])
        l1tf = next(item for item in payload["runs"][0]["results"] if item["ruleId"] == "l1tf_vmm")
        uri = l1tf["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]
        self.assertTrue(uri.endswith("/l1tf"))

    def test_cli_junit_fixture(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "junit",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        root = ET.fromstring(result.stdout)
        self.assertEqual(root.tag, "testsuite")
        self.assertGreater(int(root.attrib["failures"]), 0)

    def test_cli_prometheus_fixture(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "prometheus",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("ctra_finding_status", result.stdout)

    def test_cli_nrpe_fixture(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "nrpe",
            ],
            capture_output=True,
            text=True,
        )
        self.assertIn("CTRA CRITICAL", result.stdout)
        self.assertEqual(result.returncode, 2)

    def test_cli_markdown_include_ok(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "markdown",
                "--include-ok",
                "--cve",
                "CVE-2017-5754",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("| OK | Meltdown", result.stdout)

    def test_cli_asset_tags(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--asset-id",
                "host-123",
                "--asset-owner",
                "platform",
                "--asset-env",
                "prod",
                "--tag",
                "region=cn-north",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["asset"]["id"], "host-123")
        self.assertEqual(payload["asset"]["region"], "cn-north")

    def test_cli_vendor_data(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--vendor-data",
                "vendor-data.example.json",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        l1tf = next(item for item in payload["findings"] if item["key"] == "l1tf_vmm")
        self.assertTrue(any(evidence["source"] == "vendor_advisory" for evidence in l1tf["evidence"]))

    def test_cli_microcode_db(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--microcode-db",
                "microcode-db.example.json",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["host"]["microcode_status"], "outdated")

    def test_cli_affected_db(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--affected-db",
                "affected-db.example.json",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        spectre_v2 = next(item for item in payload["findings"] if item["key"] == "spectre_v2")
        self.assertTrue(any(evidence["source"] == "cpu_affectedness" for evidence in spectre_v2["evidence"]))

    def test_cli_kernel_image(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
                "--kernel-image",
                "tests/fixtures/vmlinux.sample",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["host"]["kernel_image_findings"]["retpoline"], "present")

    def test_cli_gzip_kernel_image(self):
        gz_path = Path("tests/fixtures/vmlinux.sample.gz")
        gz_path.write_bytes(gzip.compress(Path("tests/fixtures/vmlinux.sample").read_bytes()))
        try:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "ctra",
                    "scan",
                    "--root",
                    "tests/fixtures/linux-host",
                    "--format",
                    "json",
                    "--kernel-image",
                    str(gz_path),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        finally:
            gz_path.unlink(missing_ok=True)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["host"]["kernel_image_findings"]["retpoline"], "present")

    def test_cli_system_map(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertEqual(payload["host"]["system_map_findings"]["retpoline"], "present")

    def test_finding_count_matches_or_exceeds_reference(self):
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "ctra",
                "scan",
                "--root",
                "tests/fixtures/linux-host",
                "--format",
                "json",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        payload = json.loads(result.stdout)
        self.assertGreaterEqual(len(payload["findings"]), 32)


if __name__ == "__main__":
    unittest.main()
