# GPL Reference Backend

This directory vendors `spectre-meltdown-checker.sh`.

- Upstream project: `speed47/spectre-meltdown-checker`
- Vendored file: `spectre-meltdown-checker.sh`
- SPDX license in source: `GPL-3.0-only`

When this vendored backend is distributed together with this repository, treat
the combined distribution as GPL-3.0-only compatible. Keep the upstream notice,
source code, and modification history available to recipients.

