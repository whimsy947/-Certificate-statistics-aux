from __future__ import annotations

from dataclasses import dataclass

from .rules import RULES
from .gpl.backend import REFERENCE_SCRIPT
from .gpl.catalog import load_catalog


@dataclass(frozen=True)
class CoverageEntry:
    key: str
    name: str
    rule_keys: tuple[str, ...]


REFERENCE_FAMILIES: tuple[CoverageEntry, ...] = (
    CoverageEntry("spectre_v1", "Spectre Variant 1", ("spectre_v1",)),
    CoverageEntry("spectre_v2", "Spectre Variant 2", ("spectre_v2", "bhi")),
    CoverageEntry("meltdown", "Meltdown / Rogue Data Cache Load", ("meltdown",)),
    CoverageEntry("variant3a", "Rogue System Register Read", ("variant3a",)),
    CoverageEntry("ssb", "Speculative Store Bypass", ("spec_store_bypass",)),
    CoverageEntry("l1tf", "L1 Terminal Fault", ("l1tf_sgx", "l1tf_os", "l1tf_vmm")),
    CoverageEntry("mds", "Microarchitectural Data Sampling", ("msbds", "mfbds", "mlpds", "mdsum")),
    CoverageEntry("taa", "TSX Asynchronous Abort", ("taa",)),
    CoverageEntry("itlb_multihit", "iTLB Multihit", ("itlb_multihit",)),
    CoverageEntry("srbds", "Special Register Buffer Data Sampling", ("srbds",)),
    CoverageEntry("mmio_stale_data", "MMIO Stale Data", ("sbdr", "sbds", "drpw")),
    CoverageEntry("div0", "AMD Zen1 Division by Zero Data Leak", ("div0",)),
    CoverageEntry("zenbleed", "Zenbleed", ("zenbleed",)),
    CoverageEntry("gds", "Gather Data Sampling / Downfall", ("gather_data_sampling",)),
    CoverageEntry("retbleed", "Retbleed", ("retbleed",)),
    CoverageEntry("inception", "Speculative Return Stack Overflow / Inception", ("spec_rstack_overflow",)),
    CoverageEntry("reptar", "Redundant Prefix Issue / Reptar", ("reptar",)),
    CoverageEntry("tsa", "Transient Scheduler Attacks", ("tsa_sq", "tsa_l1")),
    CoverageEntry("its", "Indirect Target Selection", ("indirect_target_selection",)),
    CoverageEntry("vmscape", "VM-Exit Stale Branch Prediction", ("vmscape",)),
    CoverageEntry("rfds", "Register File Data Sampling", ("reg_file_data_sampling",)),
    CoverageEntry("bpi", "Branch Privilege Injection", ("bpi",)),
    CoverageEntry("sls", "Straight-Line Speculation", ("sls",)),
    CoverageEntry("fpdss", "Floating-Point Divide Stale Significand", ("fpdss",)),
    CoverageEntry("arm_spec_at", "ARM64 Speculative AT errata", ("arm_spec_at",)),
    CoverageEntry("arm_spec_unpriv_load", "ARM64 Speculative unprivileged load errata", ("arm_spec_unpriv_load",)),
    CoverageEntry("arm_ssbs_nosync", "ARM64 SSBS not self-synchronizing erratum", ("arm_ssbs_nosync",)),
)


def coverage_payload() -> dict[str, object]:
    rules_by_key = {rule.key: rule for rule in RULES}
    covered = []
    missing = []
    for entry in REFERENCE_FAMILIES:
        matching_rules = [key for key in entry.rule_keys if key in rules_by_key]
        if matching_rules:
            covered.append({"key": entry.key, "name": entry.name, "rules": matching_rules})
        else:
            missing.append({"key": entry.key, "name": entry.name})

    all_cves = sorted({cve for rule in RULES for cve in rule.cves if cve})
    gpl_catalog = load_catalog(REFERENCE_SCRIPT)
    gpl_cves = sorted({entry.cve for entry in gpl_catalog})
    native_cves = set(all_cves)
    return {
        "rule_count": len(RULES),
        "reference_family_count": len(REFERENCE_FAMILIES),
        "covered_reference_family_count": len(covered),
        "missing_reference_families": missing,
        "cve_count": len(all_cves),
        "cves": all_cves,
        "gpl_reference": {
            "catalog_entries": len(gpl_catalog),
            "cve_count": len(gpl_cves),
            "cves": gpl_cves,
            "native_missing_cves": sorted(set(gpl_cves) - native_cves),
            "native_extra_cves": sorted(native_cves - set(gpl_cves)),
        },
        "rules": [
            {
                "key": rule.key,
                "title": rule.title,
                "cves": list(rule.cves),
                "sysfs_keys": list(rule.sysfs_keys),
            }
            for rule in RULES
        ],
        "reference_families": covered,
    }
