from __future__ import annotations

import bz2
import gzip
import lzma
import shutil
import subprocess
from pathlib import Path

from .model import HostFacts


PATTERNS = {
    "retpoline": b"retpoline",
    "array_index_mask_nospec": b"array_index_mask_nospec",
    "md_clear": b"md_clear",
    "verw": b"verw",
    "l1tf": b"l1tf",
    "spectre_v2": b"spectre_v2",
    "spec_store_bypass": b"spec_store_bypass",
    "sls": b"straight-line speculation",
    "gds": b"gather_data_sampling",
    "rfds": b"reg_file_data_sampling",
}


def scan_kernel_image(facts: HostFacts, path: str | None) -> None:
    image = _find_kernel_image(facts, path)
    if image is None:
        return
    facts.kernel_image_path = str(image)
    data = _read_image(image)
    if data is None:
        facts.kernel_image_findings["error"] = "unreadable"
        return
    lower = data.lower()
    for key, pattern in PATTERNS.items():
        facts.kernel_image_findings[key] = "present" if pattern in lower else "absent"


def _read_image(path: Path) -> bytes | None:
    try:
        data = path.read_bytes()
    except OSError:
        return None
    for decoder in (_decode_gzip, _decode_xz, _decode_bz2):
        decoded = decoder(data)
        if decoded is not None:
            return decoded
    decoded = _external_decompress(path)
    if decoded is not None:
        return decoded
    return data


def _find_kernel_image(facts: HostFacts, explicit_path: str | None) -> Path | None:
    if explicit_path:
        path = Path(explicit_path)
        return path if path.exists() else None
    if not facts.kernel_release:
        return None
    root = Path(facts.root_path)
    candidates = [
        root / f"boot/vmlinuz-{facts.kernel_release}",
        root / f"boot/vmlinux-{facts.kernel_release}",
        root / f"boot/kernel-{facts.kernel_release}",
        root / "boot/vmlinuz",
        root / "boot/vmlinux",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _decode_gzip(data: bytes) -> bytes | None:
    if not data.startswith(b"\x1f\x8b"):
        return None
    try:
        return gzip.decompress(data)
    except OSError:
        return None


def _decode_xz(data: bytes) -> bytes | None:
    if not data.startswith(b"\xfd7zXZ\x00"):
        return None
    try:
        return lzma.decompress(data)
    except lzma.LZMAError:
        return None


def _decode_bz2(data: bytes) -> bytes | None:
    if not data.startswith(b"BZh"):
        return None
    try:
        return bz2.decompress(data)
    except OSError:
        return None


def _external_decompress(path: Path) -> bytes | None:
    tools = (("zstd", "-dc"), ("lz4", "-dc"))
    for tool, flag in tools:
        if shutil.which(tool) is None:
            continue
        try:
            completed = subprocess.run([tool, flag, str(path)], check=False, capture_output=True, timeout=10)
        except (OSError, subprocess.SubprocessError):
            continue
        if completed.returncode == 0 and completed.stdout:
            return completed.stdout
    return None
