from __future__ import annotations

from pathlib import Path

from .model import HostFacts


SYMBOL_PATTERNS = {
    "retpoline": ("__x86_indirect_thunk_", "retpoline"),
    "array_index_mask_nospec": ("array_index_mask_nospec",),
    "spec_ctrl": ("x86_spec_ctrl", "spec_ctrl"),
    "bhi": ("bhi", "clear_bhb", "spectre_bhi"),
    "sls": ("sls", "straight_line"),
    "md_clear": ("md_clear", "mds_clear"),
    "gds": ("gds", "gather_data"),
    "rfds": ("rfds", "reg_file_data"),
}


def scan_system_map(facts: HostFacts, explicit_path: str | None = None) -> None:
    path = _find_system_map(facts, explicit_path)
    if path is None:
        return
    facts.system_map_path = str(path)
    try:
        text = path.read_text(encoding="utf-8", errors="replace").lower()
    except OSError:
        facts.system_map_findings["error"] = "unreadable"
        return
    for key, needles in SYMBOL_PATTERNS.items():
        facts.system_map_findings[key] = "present" if any(needle in text for needle in needles) else "absent"


def _find_system_map(facts: HostFacts, explicit_path: str | None) -> Path | None:
    if explicit_path:
        path = Path(explicit_path)
        return path if path.exists() else None
    if not facts.kernel_release:
        return None
    root = Path(facts.root_path)
    candidates = [
        root / f"boot/System.map-{facts.kernel_release}",
        root / f"lib/modules/{facts.kernel_release}/System.map",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None
