from __future__ import annotations

import argparse
import datetime as dt
import json
import sys

from . import __version__
from .affected import apply_affectedness_database, apply_builtin_affectedness
from .collect import CollectionOptions, collect
from .coverage import coverage_payload
from .diff import diff_reports
from .evaluate import evaluate, summarize
from .integrations import emit_junit, emit_nrpe, emit_prometheus, emit_sarif
from .kernel_image import scan_kernel_image
from .model import Policy, Report, ScanMetadata
from .microcode import apply_microcode_database
from .output import emit_csv, emit_html, emit_json, emit_markdown
from .reference_backend import attach_reference, run_reference_backend
from .schema import REPORT_SCHEMA
from .selection import filter_rules, selected_rule_keys
from .system_map import scan_system_map
from .vendor import load_vendor_data, match_vendor_advisories
from .rules import RULES


def build_report(
    root: str,
    policy: Policy,
    asset: dict[str, str] | None = None,
    kernel_config: str | None = None,
    microcode_db: str | None = None,
    affected_db: str | None = None,
    kernel_image: str | None = None,
    system_map: str | None = None,
    collection_options: CollectionOptions | None = None,
    selected_rules: set[str] | None = None,
    scan_metadata: ScanMetadata | None = None,
    reference_backend: str = "off",
    reference_args: list[str] | None = None,
) -> Report:
    facts = collect(root, kernel_config=kernel_config, options=collection_options)
    scan_kernel_image(facts, kernel_image)
    scan_system_map(facts, system_map)
    apply_builtin_affectedness(facts)
    apply_affectedness_database(facts, affected_db)
    apply_microcode_database(facts, microcode_db)
    vendor_data = load_vendor_data(policy.vendor_data_path)
    facts.vendor_advisories = match_vendor_advisories(facts, vendor_data)
    findings = evaluate(facts, policy, rules=filter_rules(RULES, selected_rules))
    summary = summarize(findings, policy)
    report = Report(
        tool={
            "name": "cpu-transient-risk-auditor",
            "version": __version__,
            "generated_at": dt.datetime.now(dt.UTC).isoformat(timespec="seconds"),
            "method": "linux-sysfs-procfs-evidence",
        },
        policy=policy,
        scan=scan_metadata or ScanMetadata(),
        asset=asset or {},
        host=facts,
        summary=summary,
        findings=findings,
    )
    if reference_backend != "off":
        reference = run_reference_backend(reference_args)
        attach_reference(report, reference, reference_backend)
        report.summary = summarize(report.findings, policy)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="ctra",
        description="Independent auditor for CPU transient-execution vulnerability posture.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    scan_parser = subparsers.add_parser("scan", help="scan a live or mounted Linux root")
    _add_scan_args(scan_parser)

    doctor_parser = subparsers.add_parser("doctor", help="show collection environment diagnostics")
    doctor_parser.add_argument("--root", default="/")
    doctor_parser.add_argument("--kernel-config", default=None)
    doctor_parser.add_argument("--kernel-image", default=None)
    doctor_parser.add_argument("--system-map", default=None)
    doctor_parser.add_argument("--affected-db", default=None)
    doctor_parser.add_argument("--microcode-db", default=None)
    doctor_parser.add_argument("--vendor-data", default=None)

    diff_parser = subparsers.add_parser("diff", help="compare two JSON reports")
    diff_parser.add_argument("before")
    diff_parser.add_argument("after")
    diff_parser.add_argument("--format", choices=("markdown", "json"), default="markdown")

    subparsers.add_parser("schema", help="print JSON schema")

    coverage_parser = subparsers.add_parser("coverage", help="show built-in vulnerability coverage")
    coverage_parser.add_argument("--format", choices=("markdown", "json"), default="markdown")

    raw_argv = list(sys.argv[1:] if argv is None else argv)
    args = parser.parse_args(_default_to_scan(raw_argv))

    if args.command == "scan":
        return _cmd_scan(args)
    if args.command == "doctor":
        return _cmd_doctor(args)
    if args.command == "diff":
        return _cmd_diff(args)
    if args.command == "schema":
        json.dump(REPORT_SCHEMA, sys.stdout, indent=2, sort_keys=True)
        sys.stdout.write("\n")
        return 0
    if args.command == "coverage":
        return _cmd_coverage(args)
    parser.error("unknown command")
    return 2


def _default_to_scan(argv: list[str]) -> list[str]:
    commands = {"scan", "doctor", "diff", "schema", "coverage"}
    if not argv or argv[0] not in commands and argv[0] not in {"-h", "--help", "--version"}:
        return ["scan", *argv]
    return argv


def _add_scan_args(scan_parser: argparse.ArgumentParser) -> None:
    scan_parser.add_argument("--root", default="/", help="Root path to inspect, useful for fixtures or mounted systems")
    scan_parser.add_argument("--kernel-config", default=None, help="Kernel .config path to inspect")
    scan_parser.add_argument("--kernel-image", default=None, help="Kernel image/vmlinux path for static string scan")
    scan_parser.add_argument("--system-map", default=None, help="System.map path for static symbol scan")
    scan_parser.add_argument(
        "--format",
        choices=("json", "markdown", "csv", "html", "sarif", "junit", "prometheus", "nrpe"),
        default="markdown",
    )
    scan_parser.add_argument("--include-ok", action="store_true", help="Keep OK findings in markdown/html output")
    scan_parser.add_argument("--profile", choices=("standard", "paranoid"), default="standard")
    scan_parser.add_argument("--fail-on-priority", choices=("P1", "P2", "P3", "OK"), default="P2")
    scan_parser.add_argument("--no-unknown-risk", action="store_true", help="Do not elevate UNKNOWN findings to P2")
    scan_parser.add_argument("--vendor-data", default=None, help="Company-maintained vendor advisory JSON")
    scan_parser.add_argument("--microcode-db", default=None, help="Company-maintained microcode JSON database")
    scan_parser.add_argument("--affected-db", default=None, help="Company-maintained CPU affectedness JSON database")
    scan_parser.add_argument("--exit-status", action="store_true", help="Return non-zero based on highest priority")
    scan_parser.add_argument("--asset-id", default="", help="Asset identifier to embed in the report")
    scan_parser.add_argument("--asset-owner", default="", help="Asset owner/team to embed in the report")
    scan_parser.add_argument("--asset-env", default="", help="Environment label, for example prod/stage/dev")
    scan_parser.add_argument("--tag", action="append", default=[], help="Additional key=value asset tag; can be repeated")
    scan_parser.add_argument("--cve", action="append", default=[], help="Only evaluate a CVE; can be repeated")
    scan_parser.add_argument("--variant", action="append", default=[], help="Only evaluate a variant/rule key/alias; can be repeated")
    scan_parser.add_argument("--errata", action="append", default=[], help="Only evaluate an ARM erratum number; can be repeated")
    scan_parser.add_argument("--no-runtime", action="store_true", help="Skip runtime /proc, /sys, command line and OS evidence")
    scan_parser.add_argument("--no-hw", action="store_true", help="Skip CPU hardware evidence")
    scan_parser.add_argument("--hw-only", action="store_true", help="Only inspect CPU hardware evidence")
    scan_parser.add_argument("--no-sysfs", action="store_true", help="Do not use Linux vulnerability sysfs entries")
    scan_parser.add_argument("--sysfs-only", action="store_true", help="Use sysfs vulnerability entries and minimal host context only")
    scan_parser.add_argument("--cpu", default="0", help="CPU core selector for native probing: 0, N, or all")
    scan_parser.add_argument(
        "--reference-backend",
        choices=("off", "augment", "attach"),
        default="off",
        help="Use vendored GPL spectre-meltdown-checker as a reference backend",
    )
    scan_parser.add_argument(
        "--reference-arg",
        action="append",
        default=[],
        help="Extra argument passed to the GPL reference backend; can be repeated",
    )


def _policy_from_args(args: argparse.Namespace) -> Policy:
    return Policy(
        profile=args.profile,
        fail_on_priority=args.fail_on_priority,
        treat_unknown_as_risk=not args.no_unknown_risk,
        vendor_data_path=args.vendor_data,
    )


def _cmd_scan(args: argparse.Namespace) -> int:
    policy = _policy_from_args(args)
    collection_options = _collection_options_from_args(args)
    selected_rules = selected_rule_keys(args.cve, args.variant, args.errata)
    report = build_report(
        args.root,
        policy,
        _asset_from_args(args),
        kernel_config=args.kernel_config,
        microcode_db=args.microcode_db,
        affected_db=args.affected_db,
        kernel_image=args.kernel_image,
        system_map=args.system_map,
        collection_options=collection_options,
        selected_rules=selected_rules,
        scan_metadata=_scan_metadata_from_args(args, collection_options, selected_rules),
        reference_backend=args.reference_backend,
        reference_args=args.reference_arg,
    )
    if args.format == "json":
        emit_json(report)
    elif args.format == "csv":
        emit_csv(report)
    elif args.format == "html":
        if not args.include_ok:
            _filter_visible_findings(report)
        emit_html(report)
    elif args.format == "sarif":
        emit_sarif(report)
    elif args.format == "junit":
        emit_junit(report)
    elif args.format == "prometheus":
        emit_prometheus(report)
    elif args.format == "nrpe":
        emit_nrpe(report)
        return int(report.tool.get("nrpe_exit_code", report.summary.exit_code if args.exit_status else 0))
    else:
        if not args.include_ok:
            _filter_visible_findings(report)
        emit_markdown(report)
    return report.summary.exit_code if args.exit_status else 0


def _filter_visible_findings(report: Report) -> None:
    report.findings = [finding for finding in report.findings if finding.priority != "OK"]
    report.summary = summarize(report.findings, report.policy)


def _collection_options_from_args(args: argparse.Namespace) -> CollectionOptions:
    if args.hw_only:
        return CollectionOptions(use_runtime=False, use_sysfs=False, use_hardware=True, use_kernel_config=False, cpu_selector=args.cpu)
    if args.sysfs_only:
        return CollectionOptions(
            use_runtime=True,
            use_sysfs=True,
            use_hardware=False,
            use_kernel_config=False,
            use_optional_probe=False,
            cpu_selector=args.cpu,
        )
    return CollectionOptions(
        use_runtime=not args.no_runtime,
        use_sysfs=not args.no_sysfs and not args.no_runtime,
        use_hardware=not args.no_hw,
        use_kernel_config=not args.no_runtime,
        use_optional_probe=not args.no_hw,
        cpu_selector=args.cpu,
    )


def _scan_metadata_from_args(
    args: argparse.Namespace,
    options: CollectionOptions,
    selected_rules: set[str] | None,
) -> ScanMetadata:
    mode = "live"
    if args.hw_only:
        mode = "hw-only"
    elif args.no_runtime:
        mode = "no-runtime"
    elif args.no_hw:
        mode = "no-hw"
    elif args.sysfs_only:
        mode = "sysfs-only"

    reasons: list[str] = []
    if not options.use_runtime:
        reasons.append("runtime evidence disabled")
    if not options.use_sysfs:
        reasons.append("sysfs vulnerability evidence disabled")
    if not options.use_hardware:
        reasons.append("hardware evidence disabled")
    if not options.use_kernel_config:
        reasons.append("kernel config evidence disabled")
    return ScanMetadata(
        mode=mode,
        use_runtime=options.use_runtime,
        use_sysfs=options.use_sysfs,
        use_hardware=options.use_hardware,
        use_kernel_config=options.use_kernel_config,
        selected_cves=args.cve,
        selected_variants=args.variant,
        selected_errata=args.errata,
        selected_rule_count=len(selected_rules) if selected_rules is not None else None,
        reduced_accuracy=bool(reasons),
        reduced_accuracy_reasons=reasons,
        cpu_selector=args.cpu,
    )


def _asset_from_args(args: argparse.Namespace) -> dict[str, str]:
    asset: dict[str, str] = {}
    if args.asset_id:
        asset["id"] = args.asset_id
    if args.asset_owner:
        asset["owner"] = args.asset_owner
    if args.asset_env:
        asset["environment"] = args.asset_env
    for raw in args.tag:
        if "=" in raw:
            key, value = raw.split("=", 1)
            asset[key] = value
    return asset


def _cmd_doctor(args: argparse.Namespace) -> int:
    facts = collect(args.root, kernel_config=args.kernel_config)
    scan_kernel_image(facts, args.kernel_image)
    scan_system_map(facts, args.system_map)
    apply_builtin_affectedness(facts)
    apply_affectedness_database(facts, args.affected_db)
    apply_microcode_database(facts, args.microcode_db)
    facts.vendor_advisories = match_vendor_advisories(facts, load_vendor_data(args.vendor_data))
    print("Collection diagnostics")
    print(f"  root: {facts.root_path}")
    print(f"  os: {facts.os_name or 'unknown'}")
    print(f"  kernel: {facts.kernel_release or 'unknown'}")
    print(f"  cpu: {facts.cpu_model_name or facts.cpu_vendor or 'unknown'}")
    print(f"  run_as_root: {facts.run_as_root}")
    print(f"  smt_enabled: {facts.smt_enabled}")
    print(f"  hypervisor_host: {facts.hypervisor_host} ({facts.hypervisor_reason or 'no marker'})")
    print(f"  container_runtime: {facts.container_runtime} ({facts.container_reason or 'no marker'})")
    print(f"  sysfs vulnerability entries: {len(facts.vulnerabilities)}")
    print(f"  microcode: {facts.microcode or 'unknown'}")
    print(f"  kernel config: {facts.kernel_config_path or 'not found'} ({len(facts.kernel_config)} entries)")
    print(f"  kernel image: {facts.kernel_image_path or 'not scanned'} ({len(facts.kernel_image_findings)} findings)")
    print(f"  System.map: {facts.system_map_path or 'not scanned'} ({len(facts.system_map_findings)} findings)")
    print(f"  kernel cmdline findings: {len(facts.kernel_cmdline_findings)}")
    print(f"  affectedness entries: {len(facts.cpu_affectedness)}")
    print(f"  vendor advisories: {len(facts.vendor_advisories)}")
    print(f"  cpuid probe entries: {len(facts.cpuid)}")
    print(f"  msr probe entries: {len(facts.msr)}")
    return 0


def _cmd_coverage(args: argparse.Namespace) -> int:
    payload = coverage_payload()
    if args.format == "json":
        json.dump(payload, sys.stdout, indent=2, sort_keys=True)
        sys.stdout.write("\n")
        return 0

    print("# Built-in Coverage")
    print()
    print(f"- rules: {payload['rule_count']}")
    print(
        f"- reference families covered: {payload['covered_reference_family_count']}"
        f"/{payload['reference_family_count']}"
    )
    print(f"- explicit CVE identifiers: {payload['cve_count']}")
    print()
    print("| Family | Rules |")
    print("|---|---|")
    for item in payload["reference_families"]:
        print(f"| {item['name']} | {', '.join(item['rules'])} |")
    missing = payload["missing_reference_families"]
    if missing:
        print()
        print("Missing reference families:")
        for item in missing:
            print(f"- {item['name']}")
        return 1
    return 0


def _cmd_diff(args: argparse.Namespace) -> int:
    with open(args.before, encoding="utf-8") as handle:
        before = json.load(handle)
    with open(args.after, encoding="utf-8") as handle:
        after = json.load(handle)
    items = diff_reports(before, after)
    if args.format == "json":
        json.dump([item.__dict__ for item in items], sys.stdout, indent=2, sort_keys=True)
        sys.stdout.write("\n")
    else:
        print("| Direction | Finding | Before | After |")
        print("|---|---|---|---|")
        for item in items:
            print(f"| {item.direction} | {item.title} | {item.before} | {item.after} |")
    return 1 if any(item.direction == "worse" for item in items) else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
