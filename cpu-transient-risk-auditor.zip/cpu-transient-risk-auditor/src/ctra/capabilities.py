from __future__ import annotations

from .model import HostFacts


def decode_capabilities(facts: HostFacts) -> None:
    caps: dict[str, bool] = {}
    leaf7_edx = _int_hex(facts.cpuid.get("leaf_7_0_edx"))
    leaf7_ebx = _int_hex(facts.cpuid.get("leaf_7_0_ebx"))
    amd_ext_ebx = _int_hex(facts.cpuid.get("leaf_80000008_ebx"))
    spec_ctrl = _int_hex(facts.msr.get("ia32_spec_ctrl"))
    arch_caps = _int_hex(facts.msr.get("ia32_arch_capabilities"))
    tsx_ctrl = _int_hex(facts.msr.get("ia32_tsx_ctrl"))
    mcu_opt_ctrl = _int_hex(facts.msr.get("ia32_mcu_opt_ctrl"))

    if leaf7_edx is not None:
        caps["md_clear"] = bool(leaf7_edx & (1 << 10))
        caps["hybrid"] = bool(leaf7_edx & (1 << 15))
        caps["ibrs_ibpb"] = bool(leaf7_edx & (1 << 26))
        caps["stibp"] = bool(leaf7_edx & (1 << 27))
        caps["l1d_flush"] = bool(leaf7_edx & (1 << 28))
        caps["arch_capabilities"] = bool(leaf7_edx & (1 << 29))
        caps["ssbd"] = bool(leaf7_edx & (1 << 31))
    if leaf7_ebx is not None:
        caps["avx2"] = bool(leaf7_ebx & (1 << 5))
        caps["rtm"] = bool(leaf7_ebx & (1 << 11))
        caps["avx512f"] = bool(leaf7_ebx & (1 << 16))
    if amd_ext_ebx is not None:
        caps["amd_ibrs"] = bool(amd_ext_ebx & (1 << 14))
        caps["amd_stibp"] = bool(amd_ext_ebx & (1 << 15))
        caps["amd_ssbd"] = bool(amd_ext_ebx & (1 << 24))
        caps["amd_virt_ssbd"] = bool(amd_ext_ebx & (1 << 25))
        caps["amd_ssb_no"] = bool(amd_ext_ebx & (1 << 26))
        caps["amd_psfd"] = bool(amd_ext_ebx & (1 << 28))
    if spec_ctrl is not None:
        caps["ibrs_enabled"] = bool(spec_ctrl & (1 << 0))
        caps["stibp_enabled"] = bool(spec_ctrl & (1 << 1))
        caps["ssbd_enabled"] = bool(spec_ctrl & (1 << 2))
        caps["ipred_dis_u_enabled"] = bool(spec_ctrl & (1 << 3))
        caps["ipred_dis_s_enabled"] = bool(spec_ctrl & (1 << 4))
        caps["rrsba_dis_u_enabled"] = bool(spec_ctrl & (1 << 5))
        caps["rrsba_dis_s_enabled"] = bool(spec_ctrl & (1 << 6))
        caps["bhi_dis_s_enabled"] = bool(spec_ctrl & (1 << 10))
    if arch_caps is not None:
        caps["rdcl_no"] = bool(arch_caps & (1 << 0))
        caps["ibrs_all"] = bool(arch_caps & (1 << 1))
        caps["rsba"] = bool(arch_caps & (1 << 2))
        caps["skip_l1dfl_vmentry"] = bool(arch_caps & (1 << 3))
        caps["ssb_no"] = bool(arch_caps & (1 << 4))
        caps["mds_no"] = bool(arch_caps & (1 << 5))
        caps["if_pschange_mc_no"] = bool(arch_caps & (1 << 6))
        caps["taa_no"] = bool(arch_caps & (1 << 8))
        caps["tsx_ctrl_supported"] = bool(arch_caps & (1 << 7))
        caps["sbdr_ssdp_no"] = bool(arch_caps & (1 << 13))
        caps["fbsdp_no"] = bool(arch_caps & (1 << 14))
        caps["psdp_no"] = bool(arch_caps & (1 << 15))
        caps["fb_clear"] = bool(arch_caps & (1 << 17))
        caps["fb_clear_ctrl"] = bool(arch_caps & (1 << 18))
        caps["rrsba"] = bool(arch_caps & (1 << 19))
        caps["bhi_no"] = bool(arch_caps & (1 << 20))
        caps["xapic_disable_status"] = bool(arch_caps & (1 << 21))
        caps["gds_no"] = bool(arch_caps & (1 << 13))
        caps["rfds_no"] = bool(arch_caps & (1 << 27))
    if tsx_ctrl is not None:
        caps["rtm_disabled"] = bool(tsx_ctrl & (1 << 0))
        caps["tsx_cpuid_clear"] = bool(tsx_ctrl & (1 << 1))
    if mcu_opt_ctrl is not None:
        caps["gds_mitigation_disabled"] = bool(mcu_opt_ctrl & (1 << 0))

    facts.cpu_capabilities = caps


def _int_hex(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(str(value), 16)
    except ValueError:
        return None
