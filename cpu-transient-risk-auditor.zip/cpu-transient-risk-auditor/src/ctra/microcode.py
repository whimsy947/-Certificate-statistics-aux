from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .model import HostFacts
from .gpl.microcode import apply_gpl_microcode_knowledge


def apply_microcode_database(facts: HostFacts, path: str | None) -> None:
    apply_gpl_microcode_knowledge(facts)
    if not path:
        return
    db = _load(path)
    if not db:
        return
    key = _cpu_key(facts)
    entry = db.get("cpus", {}).get(key)
    if not entry:
        return
    latest = entry.get("latest")
    if not latest:
        return
    facts.microcode_latest = latest
    facts.microcode_source = db.get("source")
    facts.microcode_status = _compare_versions(facts.microcode, latest)


def _load(path: str) -> dict[str, Any] | None:
    try:
        with Path(path).open(encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _cpu_key(facts: HostFacts) -> str:
    return f"{facts.cpu_vendor or 'unknown'}:{facts.cpu_family}:{facts.cpu_model}:{facts.cpu_stepping}"


def _compare_versions(installed: str | None, latest: str) -> str:
    if not installed:
        return "unknown"
    try:
        installed_int = int(installed, 16)
        latest_int = int(latest, 16)
    except ValueError:
        return "unknown"
    if installed_int >= latest_int:
        return "current"
    return "outdated"
