from __future__ import annotations

import os
import platform
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .capabilities import decode_capabilities
from .model import HostFacts


VULN_DIR = Path("sys/devices/system/cpu/vulnerabilities")


@dataclass(frozen=True)
class CollectionOptions:
    use_runtime: bool = True
    use_sysfs: bool = True
    use_hardware: bool = True
    use_kernel_config: bool = True
    use_optional_probe: bool = True
    cpu_selector: str = "0"


def _read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None


def _rooted(root: Path, relative: str | Path) -> Path:
    return root / relative


def collect(root_path: str = "/", kernel_config: str | None = None, options: CollectionOptions | None = None) -> HostFacts:
    options = options or CollectionOptions()
    root = Path(root_path)
    facts = HostFacts(root_path=str(root))
    if options.use_runtime:
        _collect_kernel_identity(root, facts)
    facts.run_as_root = hasattr(os, "geteuid") and os.geteuid() == 0

    if options.use_hardware:
        _collect_cpuinfo(root, facts)
    if options.use_runtime:
        _collect_os_release(root, facts)
        _collect_smt(root, facts)
        _collect_hypervisor(root, facts)
        _collect_runtime_context(root, facts)
        if options.use_sysfs:
            _collect_sysfs_vulnerabilities(root, facts)
        _collect_kernel_cmdline_findings(facts)
    if options.use_kernel_config:
        _collect_kernel_config(root, facts, kernel_config)
    if options.use_hardware and options.use_optional_probe:
        _collect_optional_probe(root, facts, options.cpu_selector)
    decode_capabilities(facts)
    return facts


def _collect_kernel_identity(root: Path, facts: HostFacts) -> None:
    facts.os_name = _read_text(_rooted(root, "proc/sys/kernel/ostype"))
    facts.kernel_release = _read_text(_rooted(root, "proc/sys/kernel/osrelease"))
    facts.kernel_version = _read_text(_rooted(root, "proc/sys/kernel/version"))

    if root == Path("/"):
        facts.os_name = facts.os_name or platform.system() or None
        facts.kernel_release = facts.kernel_release or platform.release() or None
        facts.kernel_version = facts.kernel_version or platform.version() or None
        facts.machine = platform.machine() or None
    facts.kernel_cmdline = _read_text(_rooted(root, "proc/cmdline"))


def _collect_cpuinfo(root: Path, facts: HostFacts) -> None:
    text = _read_text(_rooted(root, "proc/cpuinfo"))
    if not text:
        return

    processors = re.findall(r"^processor\s*:", text, flags=re.MULTILINE)
    facts.logical_cpu_count = len(processors) if processors else None

    vendor = re.search(r"^(vendor_id|Hardware|CPU implementer)\s*:\s*(.+)$", text, re.MULTILINE)
    model = re.search(r"^(model name|Processor|cpu model)\s*:\s*(.+)$", text, re.MULTILINE)
    flags = re.search(r"^(flags|Features)\s*:\s*(.+)$", text, re.MULTILINE)
    family = re.search(r"^cpu family\s*:\s*(\d+)$", text, re.MULTILINE)
    model_id = re.search(r"^model\s*:\s*(\d+)$", text, re.MULTILINE)
    stepping = re.search(r"^stepping\s*:\s*(\d+)$", text, re.MULTILINE)
    microcode = re.search(r"^microcode\s*:\s*(.+)$", text, re.MULTILINE)
    if vendor:
        facts.cpu_vendor = vendor.group(2).strip()
    if model:
        facts.cpu_model_name = model.group(2).strip()
    if flags:
        facts.cpu_flags = set(flags.group(2).strip().split())
        facts.hypervisor_present = "hypervisor" in facts.cpu_flags
    if family:
        facts.cpu_family = int(family.group(1))
    if model_id:
        facts.cpu_model = int(model_id.group(1))
    if stepping:
        facts.cpu_stepping = int(stepping.group(1))
    if microcode:
        facts.microcode = microcode.group(1).strip()
    _derive_cpu_signature(facts)
    if not facts.machine:
        vendor_text = (facts.cpu_vendor or "").lower()
        if "intel" in vendor_text or "amd" in vendor_text:
            facts.machine = "x86_64"
        elif "arm" in vendor_text or "aarch" in vendor_text:
            facts.machine = "aarch64"
        elif "risc" in vendor_text:
            facts.machine = "riscv64"


def _collect_os_release(root: Path, facts: HostFacts) -> None:
    for relative in ("etc/os-release", "usr/lib/os-release"):
        text = _read_text(_rooted(root, relative))
        if not text:
            continue
        for line in text.splitlines():
            if "=" not in line or line.startswith("#"):
                continue
            key, value = line.split("=", 1)
            facts.os_release[key] = value.strip().strip('"')
        return


def _collect_smt(root: Path, facts: HostFacts) -> None:
    active = _read_text(_rooted(root, "sys/devices/system/cpu/smt/active"))
    control = _read_text(_rooted(root, "sys/devices/system/cpu/smt/control"))
    if active in {"0", "1"}:
        facts.smt_enabled = active == "1"
        return
    if control:
        facts.smt_enabled = control.lower() in {"on", "forceon"}


def _collect_hypervisor(root: Path, facts: HostFacts) -> None:
    proc_modules = _read_text(_rooted(root, "proc/modules")) or ""
    proc_cpuinfo = _read_text(_rooted(root, "proc/cpuinfo")) or ""
    host_markers = ("kvm_intel", "kvm_amd", "kvm ", "vboxdrv", "xen_pciback")
    for marker in host_markers:
        if marker in proc_modules:
            facts.hypervisor_host = True
            facts.hypervisor_reason = f"kernel module marker: {marker.strip()}"
            return
    if "hypervisor" in proc_cpuinfo:
        facts.hypervisor_present = True
    facts.hypervisor_host = False


def _collect_runtime_context(root: Path, facts: HostFacts) -> None:
    cgroup = _read_text(_rooted(root, "proc/1/cgroup")) or ""
    mountinfo = _read_text(_rooted(root, "proc/1/mountinfo")) or ""
    container_markers = ("docker", "kubepods", "containerd", "libpod", "podman")
    for marker in container_markers:
        if marker in cgroup or marker in mountinfo:
            facts.container_runtime = True
            facts.container_reason = f"container marker: {marker}"
            break
    if facts.container_runtime is None:
        facts.container_runtime = False

    lockdown = _read_text(_rooted(root, "sys/kernel/security/lockdown"))
    if lockdown:
        facts.lockdown = lockdown


def _collect_sysfs_vulnerabilities(root: Path, facts: HostFacts) -> None:
    vuln_dir = _rooted(root, VULN_DIR)
    try:
        entries = list(vuln_dir.iterdir())
    except OSError:
        return
    for entry in entries:
        if not entry.is_file():
            continue
        value = _read_text(entry)
        if value is not None:
            facts.vulnerabilities[entry.name] = value


def _collect_kernel_cmdline_findings(facts: HostFacts) -> None:
    cmdline = facts.kernel_cmdline or ""
    if not cmdline:
        return
    checks = {
        "mitigations_off": r"(^|\s)mitigations=off(\s|$)",
        "nosmt": r"(^|\s)(nosmt|nosmt=force|mitigations=[^ ]*nosmt)(\s|$)",
        "spectre_v2_off": r"(^|\s)spectre_v2=off(\s|$)",
        "spectre_v2_user_off": r"(^|\s)spectre_v2_user=off(\s|$)",
        "spec_store_bypass_disable_off": r"(^|\s)spec_store_bypass_disable=off(\s|$)",
        "l1tf_off": r"(^|\s)l1tf=off(\s|$)",
        "mds_off": r"(^|\s)mds=off(\s|$)",
        "tsx_async_abort_off": r"(^|\s)tsx_async_abort=off(\s|$)",
        "retbleed_off": r"(^|\s)retbleed=off(\s|$)",
    }
    for key, pattern in checks.items():
        if re.search(pattern, cmdline):
            facts.kernel_cmdline_findings[key] = "present"


def _collect_optional_probe(root: Path, facts: HostFacts, cpu_selector: str) -> None:
    if root != Path("/"):
        return
    helper = Path(__file__).resolve().parents[3] / "native" / "ctra_probe.py"
    if not helper.exists():
        return
    try:
        completed = subprocess.run(
            [os.environ.get("PYTHON", "python"), str(helper), "--cpu", cpu_selector],
            check=False,
            capture_output=True,
            text=True,
            timeout=3,
        )
    except (OSError, subprocess.SubprocessError):
        return
    if completed.returncode != 0:
        return
    for line in completed.stdout.splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key.startswith("cpuid."):
            facts.cpuid[key.removeprefix("cpuid.")] = value
        elif key.startswith("msr."):
            facts.msr[key.removeprefix("msr.")] = value
    _derive_cpu_signature(facts)
    _derive_platform_id(facts)


def _derive_cpu_signature(facts: HostFacts) -> None:
    leaf_1_eax = _int_hex(facts.cpuid.get("leaf_1_eax"))
    if leaf_1_eax is not None:
        facts.cpu_signature = f"0x{leaf_1_eax:08X}"
        return
    if facts.cpu_family is None or facts.cpu_model is None or facts.cpu_stepping is None:
        return
    family = facts.cpu_family
    model = facts.cpu_model
    stepping = facts.cpu_stepping
    base_family = family & 0xF
    ext_family = family - 0xF if family >= 0xF else 0
    base_model = model & 0xF
    ext_model = (model >> 4) & 0xF if family in {6, 0xF} else 0
    signature = stepping | (base_model << 4) | (base_family << 8) | (ext_model << 16) | (ext_family << 20)
    facts.cpu_signature = f"0x{signature:08X}"


def _derive_platform_id(facts: HostFacts) -> None:
    value = _int_hex(facts.msr.get("ia32_platform_id"))
    if value is None:
        return
    platform_id = (value >> 50) & 0x7
    facts.cpu_platform_id_mask = 1 << platform_id


def _int_hex(value: object) -> int | None:
    if value is None:
        return None
    try:
        return int(str(value), 16)
    except ValueError:
        return None


def _collect_kernel_config(root: Path, facts: HostFacts, explicit_config: str | None) -> None:
    candidates: list[Path] = []
    if explicit_config:
        candidates.append(Path(explicit_config))
    if facts.kernel_release:
        candidates.extend(
            [
                _rooted(root, f"boot/config-{facts.kernel_release}"),
                _rooted(root, f"lib/modules/{facts.kernel_release}/build/.config"),
            ]
        )
    candidates.append(_rooted(root, "proc/config.gz"))

    for candidate in candidates:
        data = _read_kernel_config(candidate)
        if data is None:
            continue
        facts.kernel_config_path = str(candidate)
        facts.kernel_config = data
        return


def _read_kernel_config(path: Path) -> dict[str, str] | None:
    if not path.exists():
        return None
    try:
        if path.suffix == ".gz":
            import gzip

            with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
                text = handle.read()
        else:
            text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    config: dict[str, str] = {}
    for line in text.splitlines():
        if line.startswith("# CONFIG_") and line.endswith(" is not set"):
            key = line.split()[1]
            config[key] = "n"
        elif line.startswith("CONFIG_") and "=" in line:
            key, value = line.split("=", 1)
            config[key] = value
    return config
