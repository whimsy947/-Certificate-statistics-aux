from __future__ import annotations

from .model import HostFacts, VulnerabilityRule


def recommendations(verdict: str, exposure: str, confidence: str, facts: HostFacts, rule: VulnerabilityRule) -> list[str]:
    items: list[str] = []

    if verdict == "not_vulnerable" and confidence == "high":
        return ["No immediate action required; keep kernel and microcode update processes healthy."]

    if confidence == "low":
        items.append("Improve scan confidence: run on Linux with access to /sys, /proc, and root privileges where permitted.")

    if verdict == "unknown":
        items.append("Treat as unresolved until the kernel reports a clear mitigation or affectedness state.")

    if verdict == "vulnerable":
        items.append("Patch the operating system kernel and CPU microcode/firmware through the vendor-supported channel.")

    if facts.microcode_status == "outdated":
        items.append("Update CPU microcode/firmware; installed revision is older than the configured latest known revision.")

    if rule.smt_sensitive and facts.smt_enabled is True:
        items.append("Evaluate disabling SMT/Hyper-Threading for this class if untrusted code or multi-tenant workloads run here.")

    if rule.hypervisor_sensitive and facts.hypervisor_host is True:
        items.append("Prioritize this host because it appears to run virtualization workloads or hypervisor modules.")

    if exposure == "high":
        items.append("Reduce exposure by isolating untrusted workloads until mitigation evidence is confirmed.")

    if any(key.endswith("_off") or key == "mitigations_off" for key in facts.kernel_cmdline_findings):
        items.append("Review kernel command-line mitigation overrides; remove options that disable CPU mitigations unless formally risk-accepted.")

    if facts.container_runtime is True:
        items.append("Container isolation is not a hardware boundary; patch the host kernel and firmware, not only container images.")

    if not items:
        items.append("Review vendor advisories and kernel vulnerability sysfs output for this finding.")
    return _dedupe(items)


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result
