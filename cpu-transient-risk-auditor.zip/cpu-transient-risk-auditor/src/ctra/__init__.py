"""CPU transient-execution risk auditor."""

__version__ = "0.1.0"
