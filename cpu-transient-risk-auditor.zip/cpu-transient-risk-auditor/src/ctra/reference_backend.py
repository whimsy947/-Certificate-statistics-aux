from __future__ import annotations

from typing import Any

from .model import Evidence, Finding, Report
from .gpl.backend import REFERENCE_SCRIPT, run_reference_backend
from .gpl.catalog import catalog_summary
from .gpl.normalizer import aggregate_status, by_cve, is_vulnerable, normalize_vulnerabilities


def attach_reference(report: Report, reference: dict[str, Any], mode: str) -> None:
    report.tool["reference_backend"] = _compact_reference(reference)
    if mode != "augment":
        return
    normalized = normalize_vulnerabilities(reference.get("report"))
    reference_by_cve = by_cve(normalized)
    for finding in report.findings:
        matches = [reference_by_cve[cve] for cve in finding.cves if cve in reference_by_cve]
        if not matches:
            continue
        finding.evidence.append(
            Evidence(
                source="gpl_reference_backend",
                key="spectre-meltdown-checker",
                value=[match.raw for match in matches],
                status=aggregate_status(matches),
                message="GPL reference backend result",
            )
        )
        if any(is_vulnerable(item) for item in matches) and finding.verdict == "unknown":
            finding.verdict = "vulnerable"
            finding.priority = "P2" if finding.priority in {"P3", "OK"} else finding.priority
            finding.confidence = "medium"
            finding.summary = f"{finding.summary}; gpl_reference_backend_vulnerable=true"


def _command(extra_args: list[str]) -> list[str]:
    script = str(REFERENCE_SCRIPT)
    base_args = [script, "--batch", "json", *extra_args]
    if os.name == "nt":
        shell = shutil.which("bash") or shutil.which("sh")
        if shell:
            return [shell, *base_args]
        return ["sh", *base_args]
    return [script, "--batch", "json", *extra_args]


def _parse_json(output: str) -> dict[str, Any] | None:
    output = output.strip()
    if not output:
        return None
    try:
        return json.loads(output)
    except json.JSONDecodeError:
        start = output.find("{")
        end = output.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(output[start : end + 1])
            except json.JSONDecodeError:
                return None
    return None


def _compact_reference(reference: dict[str, Any]) -> dict[str, Any]:
    report = reference.get("report") or {}
    vulnerabilities = normalize_vulnerabilities(report)
    return {
        "available": reference.get("available"),
        "returncode": reference.get("returncode"),
        "error": reference.get("error"),
        "meta": report.get("meta"),
        "vulnerability_count": len(vulnerabilities),
        "catalog": catalog_summary(REFERENCE_SCRIPT),
    }
