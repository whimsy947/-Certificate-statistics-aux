from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class DiffItem:
    key: str
    title: str
    before: str
    after: str
    direction: str


PRIORITY_SCORE = {"P1": 3, "P2": 2, "P3": 1, "OK": 0}


def diff_reports(before: dict[str, Any], after: dict[str, Any]) -> list[DiffItem]:
    old = {item["key"]: item for item in before.get("findings", [])}
    new = {item["key"]: item for item in after.get("findings", [])}
    items: list[DiffItem] = []
    for key in sorted(set(old) | set(new)):
        old_item = old.get(key)
        new_item = new.get(key)
        before_pri = old_item.get("priority", "MISSING") if old_item else "MISSING"
        after_pri = new_item.get("priority", "MISSING") if new_item else "MISSING"
        if before_pri == after_pri:
            continue
        direction = _direction(before_pri, after_pri)
        title = (new_item or old_item or {}).get("title", key)
        items.append(DiffItem(key=key, title=title, before=before_pri, after=after_pri, direction=direction))
    return items


def _direction(before: str, after: str) -> str:
    if before == "MISSING":
        return "added"
    if after == "MISSING":
        return "removed"
    if PRIORITY_SCORE.get(after, -1) > PRIORITY_SCORE.get(before, -1):
        return "worse"
    return "better"
