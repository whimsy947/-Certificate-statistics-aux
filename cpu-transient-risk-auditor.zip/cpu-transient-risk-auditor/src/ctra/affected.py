from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .model import HostFacts
from .gpl.affectedness import apply_gpl_refactored_affectedness


def apply_builtin_affectedness(facts: HostFacts) -> None:
    source = "built-in-cpuid-and-vendor-rules"
    caps = facts.cpu_capabilities
    _not_affected_if(facts, "CVE-2017-5754", caps.get("rdcl_no"), source, "ARCH_CAPABILITIES.RDCL_NO")
    _not_affected_if(facts, "CVE-2018-3639", caps.get("ssb_no") or caps.get("amd_ssb_no"), source, "SSB_NO")
    _not_affected_if(facts, "CVE-2018-12126", caps.get("mds_no"), source, "ARCH_CAPABILITIES.MDS_NO")
    _not_affected_if(facts, "CVE-2018-12127", caps.get("mds_no"), source, "ARCH_CAPABILITIES.MDS_NO")
    _not_affected_if(facts, "CVE-2018-12130", caps.get("mds_no"), source, "ARCH_CAPABILITIES.MDS_NO")
    _not_affected_if(facts, "CVE-2019-11091", caps.get("mds_no"), source, "ARCH_CAPABILITIES.MDS_NO")
    _not_affected_if(facts, "CVE-2019-11135", caps.get("taa_no"), source, "ARCH_CAPABILITIES.TAA_NO")
    _not_affected_if(facts, "CVE-2022-40982", caps.get("gds_no"), source, "ARCH_CAPABILITIES.GDS_NO")
    _not_affected_if(facts, "CVE-2023-28746", caps.get("rfds_no"), source, "ARCH_CAPABILITIES.RFDS_NO")
    _not_affected_if(facts, "CVE-2022-0001", caps.get("bhi_no"), source, "ARCH_CAPABILITIES.BHI_NO")
    _not_affected_if(facts, "CVE-2022-0002", caps.get("bhi_no"), source, "ARCH_CAPABILITIES.BHI_NO")

    vendor = _normalized_vendor(facts.cpu_vendor or facts.cpu_model_name)
    if vendor == "intel":
        _affected_vendor_scope(facts, ("CVE-2017-5715", "CVE-2017-5754"), source, "Intel-family transient-execution class")
    elif vendor == "amd":
        _affected_vendor_scope(facts, ("CVE-2022-29900", "CVE-2023-20569"), source, "AMD-family transient-execution class")

    apply_gpl_refactored_affectedness(facts)


def apply_affectedness_database(facts: HostFacts, path: str | None) -> None:
    if not path:
        return
    payload = _load_json(path)
    if not payload:
        return
    facts.affectedness_source = payload.get("source")
    for cve, entry in payload.get("cves", {}).items():
        if _entry_matches(facts, entry):
            facts.cpu_affectedness[cve] = {
                "affected": True,
                "source": payload.get("source"),
                "notes": entry.get("notes"),
            }


def _not_affected_if(facts: HostFacts, cve: str, condition: object, source: str, reason: str) -> None:
    if condition is True:
        facts.cpu_not_affected[cve] = {
            "affected": False,
            "source": source,
            "reason": reason,
        }


def _affected_vendor_scope(facts: HostFacts, cves: tuple[str, ...], source: str, reason: str) -> None:
    for cve in cves:
        if cve in facts.cpu_not_affected:
            continue
        facts.cpu_affectedness.setdefault(
            cve,
            {
                "affected": "possible",
                "source": source,
                "notes": reason,
            },
        )


def _load_json(path: str) -> dict[str, Any] | None:
    try:
        with Path(path).open(encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _entry_matches(facts: HostFacts, entry: dict[str, Any]) -> bool:
    return any(_rule_matches(facts, rule) for rule in entry.get("affected", []))


def _rule_matches(facts: HostFacts, rule: dict[str, Any]) -> bool:
    vendor = rule.get("vendor")
    if vendor and facts.cpu_vendor and vendor.lower() not in facts.cpu_vendor.lower():
        return False
    for attr, value in (("family", facts.cpu_family), ("model", facts.cpu_model), ("stepping", facts.cpu_stepping)):
        expected = rule.get(attr)
        if expected is None:
            continue
        values = expected if isinstance(expected, list) else [expected]
        if value not in values:
            return False
    return True


def _normalized_vendor(raw: str | None) -> str | None:
    if not raw:
        return None
    text = raw.lower()
    if "intel" in text or "genuineintel" in text:
        return "intel"
    if "amd" in text or "authenticamd" in text:
        return "amd"
    if "hygon" in text:
        return "hygon"
    if "arm" in text or "aarch" in text:
        return "arm"
    return None
