from __future__ import annotations

import json
import sys
import xml.etree.ElementTree as ET
from typing import TextIO

from .model import Report


def emit_sarif(report: Report, stream: TextIO = sys.stdout) -> None:
    rules = []
    results = []
    for finding in report.findings:
        if finding.priority == "OK":
            continue
        rule_id = finding.key
        rules.append(
            {
                "id": rule_id,
                "name": finding.title,
                "shortDescription": {"text": finding.title},
                "fullDescription": {"text": finding.summary},
                "help": {"text": "\n".join(finding.remediation)},
                "properties": {
                    "tags": finding.cves + [finding.priority, finding.exposure, finding.confidence],
                    "precision": "medium" if finding.confidence == "high" else "low",
                    "security-severity": _sarif_severity(finding.priority),
                },
            }
        )
        results.append(
            {
                "ruleId": rule_id,
                "level": _sarif_level(finding.priority),
                "message": {"text": finding.summary},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": _sarif_location(finding)}
                        }
                    }
                ],
                "properties": {
                    "priority": finding.priority,
                    "verdict": finding.verdict,
                    "exposure": finding.exposure,
                    "confidence": finding.confidence,
                    "cves": finding.cves,
                    "remediation": finding.remediation,
                },
            }
        )

    payload = {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": report.tool["name"],
                        "version": report.tool["version"],
                        "informationUri": "https://example.invalid/internal/cpu-transient-risk-auditor",
                        "rules": rules,
                    }
                },
                "results": results,
            }
        ],
    }
    json.dump(payload, stream, indent=2, sort_keys=True)
    stream.write("\n")


def emit_junit(report: Report, stream: TextIO = sys.stdout) -> None:
    suite = ET.Element(
        "testsuite",
        {
            "name": "cpu-transient-risk-auditor",
            "tests": str(len(report.findings)),
            "failures": str(sum(1 for item in report.findings if item.priority in {"P1", "P2"})),
            "skipped": str(sum(1 for item in report.findings if item.priority == "P3")),
        },
    )
    for finding in report.findings:
        case = ET.SubElement(suite, "testcase", {"name": finding.key, "classname": "ctra"})
        if finding.priority in {"P1", "P2"}:
            failure = ET.SubElement(case, "failure", {"message": finding.summary, "type": finding.priority})
            failure.text = "\n".join(finding.remediation)
        elif finding.priority == "P3":
            skipped = ET.SubElement(case, "skipped", {"message": finding.summary})
            skipped.text = "Unknown risk; evidence incomplete."

    ET.indent(suite)
    stream.write(ET.tostring(suite, encoding="unicode"))
    stream.write("\n")


def emit_prometheus(report: Report, stream: TextIO = sys.stdout) -> None:
    stream.write("# HELP ctra_finding_status Finding status: 0=OK, 1=P3, 2=P2, 3=P1\n")
    stream.write("# TYPE ctra_finding_status gauge\n")
    for finding in report.findings:
        labels = {
            "key": finding.key,
            "title": finding.title,
            "priority": finding.priority,
            "verdict": finding.verdict,
            "confidence": finding.confidence,
            "exposure": finding.exposure,
            "cves": ",".join(finding.cves),
        }
        stream.write(f"ctra_finding_status{{{_prom_labels(labels)}}} {_priority_number(finding.priority)}\n")
    stream.write("# HELP ctra_summary_total Summary counts by priority\n")
    stream.write("# TYPE ctra_summary_total gauge\n")
    for priority, value in (("P1", report.summary.p1), ("P2", report.summary.p2), ("P3", report.summary.p3), ("OK", report.summary.ok)):
        stream.write(f'ctra_summary_total{{priority="{priority}"}} {value}\n')


def emit_nrpe(report: Report, stream: TextIO = sys.stdout) -> int:
    if report.summary.p1:
        state = "CRITICAL"
        code = 2
    elif report.summary.p2:
        state = "WARNING"
        code = 1
    elif report.summary.p3:
        state = "UNKNOWN"
        code = 3
    else:
        state = "OK"
        code = 0
    top = [f"{item.key}:{item.priority}" for item in report.findings if item.priority != "OK"][:8]
    stream.write(
        f"CTRA {state} - P1={report.summary.p1} P2={report.summary.p2} P3={report.summary.p3} "
        f"OK={report.summary.ok}; {' '.join(top)}\n"
    )
    # Store intended NRPE code for CLI callers that want to use it later.
    report.tool["nrpe_exit_code"] = code
    return code


def _sarif_location(finding) -> str:
    for evidence in finding.evidence:
        if evidence.source == "sysfs" and isinstance(evidence.key, str):
            return evidence.key.removeprefix("/")
    return f"sys/devices/system/cpu/vulnerabilities/{finding.key}"


def _sarif_level(priority: str) -> str:
    return {"P1": "error", "P2": "warning", "P3": "note"}.get(priority, "none")


def _sarif_severity(priority: str) -> str:
    return {"P1": "9.0", "P2": "7.0", "P3": "4.0"}.get(priority, "0.0")


def _priority_number(priority: str) -> int:
    return {"P1": 3, "P2": 2, "P3": 1, "OK": 0}.get(priority, 1)


def _prom_labels(labels: dict[str, str]) -> str:
    return ",".join(f'{key}="{_prom_escape(value)}"' for key, value in labels.items())


def _prom_escape(value: str) -> str:
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
