from __future__ import annotations

from .model import Evidence, Finding, HostFacts, Policy, Summary, SysfsInterpretation, VulnerabilityRule
from .remediate import recommendations
from .rules import RULES


def interpret_sysfs(message: str | None) -> SysfsInterpretation:
    if not message:
        return SysfsInterpretation(status="UNKNOWN", raw=message)
    text = message.strip().lower()
    if text.startswith("not affected"):
        return SysfsInterpretation(status="OK", raw=message)
    if text.startswith("mitigation") or text.startswith("kvm: mitigation"):
        residual = any(
            token in text
            for token in (
                "smt vulnerable",
                "vulnerable: clear cpu buffers attempted",
                "ibpb: disabled",
                "stibp: disabled",
                "bhi: vulnerable",
            )
        )
        reason = "mitigation has residual-risk qualifier" if residual else None
        return SysfsInterpretation(status="OK", mitigation=message, residual_risk=residual, residual_reason=reason, raw=message)
    if text.startswith("vulnerable"):
        return SysfsInterpretation(status="VULNERABLE", raw=message)
    if text.startswith("unknown"):
        return SysfsInterpretation(status="UNKNOWN", raw=message)
    return SysfsInterpretation(status="UNKNOWN", raw=message)


def normalize_sysfs_status(message: str | None) -> str:
    return interpret_sysfs(message).status


PRIORITY_ORDER = {"P1": 0, "P2": 1, "P3": 2, "OK": 3}
EXIT_BY_PRIORITY = {"P1": 11, "P2": 12, "P3": 13, "OK": 0}


def evaluate(facts: HostFacts, policy: Policy | None = None, rules: tuple[VulnerabilityRule, ...] | None = None) -> list[Finding]:
    policy = policy or Policy()
    rules = rules or RULES
    return [evaluate_rule(facts, rule, policy) for rule in rules]


def summarize(findings: list[Finding], policy: Policy | None = None) -> Summary:
    policy = policy or Policy()
    summary = Summary(total=len(findings))
    for finding in findings:
        if finding.priority == "P1":
            summary.p1 += 1
        elif finding.priority == "P2":
            summary.p2 += 1
        elif finding.priority == "P3":
            summary.p3 += 1
        elif finding.priority == "OK":
            summary.ok += 1
        if finding.verdict == "vulnerable":
            summary.vulnerable += 1
        elif finding.verdict == "unknown":
            summary.unknown += 1

    summary.highest_priority = min((finding.priority for finding in findings), key=lambda p: PRIORITY_ORDER.get(p, 9), default="OK")
    summary.exit_code = _exit_code(summary.highest_priority, policy)
    return summary


def evaluate_rule(facts: HostFacts, rule: VulnerabilityRule, policy: Policy) -> Finding:
    applicability = _applicability(facts, rule)
    sysfs_key, message = _rule_sysfs_message(facts, rule)
    sysfs = interpret_sysfs(message)
    sysfs_status = sysfs.status
    evidence = [
        Evidence(
            source="sysfs",
            key=f"/sys/devices/system/cpu/vulnerabilities/{sysfs_key or rule.key}",
            value=message,
            status=sysfs_status,
            message=sysfs.residual_reason or "kernel vulnerability interface",
        )
    ]
    evidence.extend(_context_evidence(facts, rule))
    evidence.extend(applicability)

    not_applicable = any(item.status == "NOT_APPLICABLE" for item in applicability)
    cpu_not_affected = any(cve in facts.cpu_not_affected for cve in rule.cves)
    effective_cpu_not_affected = cpu_not_affected and sysfs_status != "VULNERABLE"
    cpu_affected = _cpu_affected(facts, rule)
    static_mitigation = _static_mitigation(facts, rule)
    verdict = "not_vulnerable" if not_applicable or effective_cpu_not_affected else _verdict_from_status(sysfs_status)
    exposure = _exposure(facts, rule, policy)
    confidence = _confidence(facts, message, policy)
    if verdict == "unknown" and static_mitigation:
        verdict = "not_vulnerable"
        confidence = "medium"
    priority = "OK" if not_applicable or effective_cpu_not_affected else _priority(verdict, exposure, confidence, policy)
    if not_applicable or effective_cpu_not_affected:
        confidence = "high"
        exposure = "normal"
    if not not_applicable and sysfs.residual_risk and exposure == "high":
        priority = _max_priority(priority, "P2")
    elif not not_applicable and sysfs.residual_risk and (policy.profile == "paranoid" or exposure == "elevated"):
        priority = _max_priority(priority, "P3")
    if not not_applicable and _has_rule_cmdline_disable(facts, rule):
        priority = _max_priority(priority, "P2")
    if not not_applicable and facts.microcode_status == "outdated" and rule.high_impact:
        priority = _max_priority(priority, "P2")
    if not not_applicable and cpu_affected and verdict == "unknown":
        priority = _max_priority(priority, "P2")
    if not not_applicable and _missing_required_capability(facts, rule) and rule.high_impact:
        priority = _max_priority(priority, "P2")
    summary = _summary(verdict, message, exposure, confidence)
    if not_applicable:
        summary = "Rule is not applicable to this CPU vendor or architecture"
    if effective_cpu_not_affected:
        summary = "CPU reports architectural not-affected capability"
    elif cpu_not_affected and sysfs_status == "VULNERABLE":
        summary = f"{summary}; cpu_not_affected_conflicts_with_sysfs=true"
    if static_mitigation and message is None:
        summary = f"Static kernel evidence indicates mitigation support; exposure={exposure}; confidence={confidence}; verdict={verdict}"
    if sysfs.residual_risk:
        summary = f"{summary}; residual_risk=true"
    if _has_rule_cmdline_disable(facts, rule):
        summary = f"{summary}; kernel_cmdline_mitigation_override=true"
    if facts.microcode_status == "outdated" and rule.high_impact:
        summary = f"{summary}; microcode_outdated=true"
    if cpu_affected:
        summary = f"{summary}; cpu_affected_by_database=true"
    elif _cpu_possibly_affected(facts, rule):
        summary = f"{summary}; cpu_possibly_affected=true"
    if _missing_required_capability(facts, rule):
        summary = f"{summary}; required_cpu_capability_missing=true"
    remediation = recommendations(verdict, exposure, confidence, facts, rule)

    return Finding(
        key=rule.key,
        title=rule.title,
        cves=list(rule.cves),
        verdict=verdict,
        priority=priority,
        confidence=confidence,
        exposure=exposure,
        summary=summary,
        remediation=remediation,
        evidence=evidence,
    )


def _applicability(facts: HostFacts, rule: VulnerabilityRule) -> list[Evidence]:
    evidence: list[Evidence] = []
    vendor = _normalized_vendor(facts.cpu_vendor or facts.cpu_model_name)
    machine = (facts.machine or "").lower()
    if rule.applicable_vendors and vendor:
        matched = vendor in rule.applicable_vendors
        evidence.append(
            Evidence(
                source="applicability",
                key="cpu_vendor",
                value=vendor,
                status="APPLICABLE" if matched else "NOT_APPLICABLE",
                message="vendor-scoped rule",
            )
        )
    if rule.applicable_architectures and machine:
        matched = any(arch in machine for arch in rule.applicable_architectures)
        evidence.append(
            Evidence(
                source="applicability",
                key="machine",
                value=machine,
                status="APPLICABLE" if matched else "NOT_APPLICABLE",
                message="architecture-scoped rule",
            )
        )
    return evidence


def _context_evidence(facts: HostFacts, rule: VulnerabilityRule) -> list[Evidence]:
    evidence: list[Evidence] = [
        Evidence(source="host", key="smt_enabled", value=facts.smt_enabled),
        Evidence(source="host", key="hypervisor_host", value=facts.hypervisor_host, message=facts.hypervisor_reason),
        Evidence(source="host", key="run_as_root", value=facts.run_as_root),
        Evidence(source="host", key="container_runtime", value=facts.container_runtime, message=facts.container_reason),
        Evidence(source="host", key="kernel_lockdown", value=facts.lockdown),
        Evidence(source="host", key="cpu_signature", value=facts.cpu_signature),
        Evidence(source="host", key="cpu_platform_id_mask", value=facts.cpu_platform_id_mask),
        Evidence(source="host", key="microcode", value=facts.microcode),
        Evidence(source="host", key="microcode_latest", value=facts.microcode_latest, status=facts.microcode_status),
    ]
    for key in rule.risky_cmdline:
        if key in facts.kernel_cmdline_findings:
            evidence.append(Evidence(source="kernel_cmdline", key=key, value=facts.kernel_cmdline_findings[key], status="RISK"))
    for key in rule.positive_cmdline:
        if key in facts.kernel_cmdline_findings:
            evidence.append(Evidence(source="kernel_cmdline", key=key, value=facts.kernel_cmdline_findings[key], status="OK"))
    for key in rule.kernel_configs:
        if key in facts.kernel_config:
            status = "OK" if facts.kernel_config[key] not in {"n", "0"} else "RISK"
            evidence.append(Evidence(source="kernel_config", key=key, value=facts.kernel_config[key], status=status))
    for key, value in sorted(facts.kernel_image_findings.items()):
        if key in rule.key or key in rule.aliases or key in " ".join(rule.sysfs_keys):
            evidence.append(Evidence(source="kernel_image", key=key, value=value, status="OK" if value == "present" else "UNKNOWN"))
    for key, value in sorted(facts.system_map_findings.items()):
        if key in rule.key or key in rule.aliases or key in " ".join(rule.sysfs_keys):
            evidence.append(Evidence(source="system_map", key=key, value=value, status="OK" if value == "present" else "UNKNOWN"))
    for key, value in sorted(facts.cpuid.items()):
        evidence.append(Evidence(source="cpuid", key=key, value=value))
    for key, value in sorted(facts.cpu_capabilities.items()):
        evidence.append(Evidence(source="cpu_capability", key=key, value=value))
    for key in rule.required_capabilities:
        if key not in facts.cpu_capabilities:
            evidence.append(Evidence(source="cpu_capability_required", key=key, value=None, status="UNKNOWN"))
        elif facts.cpu_capabilities[key]:
            evidence.append(Evidence(source="cpu_capability_required", key=key, value=True, status="OK"))
        else:
            evidence.append(Evidence(source="cpu_capability_required", key=key, value=False, status="RISK"))
    for key, value in sorted(facts.msr.items()):
        evidence.append(Evidence(source="msr", key=key, value=value))
    for cve in rule.cves:
        if cve in facts.cpu_affectedness:
            evidence.append(Evidence(source="cpu_affectedness", key=cve, value=facts.cpu_affectedness[cve], status="AFFECTED"))
        if cve in facts.cpu_not_affected:
            evidence.append(Evidence(source="cpu_affectedness", key=cve, value=facts.cpu_not_affected[cve], status="NOT_AFFECTED"))
        if cve in facts.vendor_advisories:
            evidence.append(Evidence(source="vendor_advisory", key=cve, value=facts.vendor_advisories[cve], status="AFFECTED"))
    if rule.smt_sensitive:
        evidence.append(Evidence(source="rule", key="smt_sensitive", value=True))
    if rule.hypervisor_sensitive:
        evidence.append(Evidence(source="rule", key="hypervisor_sensitive", value=True))
    return evidence


def _verdict_from_status(sysfs_status: str) -> str:
    if sysfs_status == "OK":
        return "not_vulnerable"
    if sysfs_status == "VULNERABLE":
        return "vulnerable"
    return "unknown"


def _exposure(facts: HostFacts, rule: VulnerabilityRule, policy: Policy) -> str:
    if policy.hypervisor_elevates and rule.hypervisor_sensitive and facts.hypervisor_host is True:
        return "high"
    if policy.smt_elevates and rule.smt_sensitive and facts.smt_enabled is True:
        return "elevated"
    return "normal"


def _confidence(facts: HostFacts, sysfs_message: str | None, policy: Policy) -> str:
    if not sysfs_message:
        return "low"
    if policy.require_root_for_high_confidence and facts.run_as_root is False:
        return "medium"
    return "high"


def _priority(verdict: str, exposure: str, confidence: str, policy: Policy) -> str:
    if policy.profile == "paranoid" and verdict == "not_vulnerable" and exposure == "high" and confidence != "high":
        return "P3"
    if verdict == "vulnerable" and exposure == "high" and confidence != "low":
        return "P1"
    if verdict == "vulnerable":
        return "P2"
    if not policy.treat_unknown_as_risk and verdict == "unknown":
        return "P3"
    if verdict == "unknown" and exposure in {"high", "elevated"}:
        return "P2"
    if verdict == "unknown":
        return "P3"
    return "OK"


def _summary(verdict: str, sysfs_message: str | None, exposure: str, confidence: str) -> str:
    if sysfs_message:
        base = sysfs_message
    else:
        base = "No kernel sysfs vulnerability signal was available"
    return f"{base}; exposure={exposure}; confidence={confidence}; verdict={verdict}"


def _exit_code(highest_priority: str, policy: Policy) -> int:
    if PRIORITY_ORDER.get(highest_priority, 9) <= PRIORITY_ORDER.get(policy.fail_on_priority, 1):
        return EXIT_BY_PRIORITY.get(highest_priority, 1)
    return 0


def _max_priority(current: str, minimum: str) -> str:
    return current if PRIORITY_ORDER.get(current, 9) <= PRIORITY_ORDER.get(minimum, 9) else minimum


def _has_rule_cmdline_disable(facts: HostFacts, rule: VulnerabilityRule) -> bool:
    return any(key in facts.kernel_cmdline_findings for key in rule.risky_cmdline)


def _rule_sysfs_message(facts: HostFacts, rule: VulnerabilityRule) -> tuple[str | None, str | None]:
    for key in rule.sysfs_keys or (rule.key,):
        if key in facts.vulnerabilities:
            return key, facts.vulnerabilities[key]
    return None, None


def _missing_required_capability(facts: HostFacts, rule: VulnerabilityRule) -> bool:
    for key in rule.required_capabilities:
        if facts.cpu_capabilities.get(key) is False:
            return True
    return False


def _cpu_affected(facts: HostFacts, rule: VulnerabilityRule) -> bool:
    for cve in rule.cves:
        entry = facts.cpu_affectedness.get(cve)
        if isinstance(entry, dict) and entry.get("affected") is True:
            return True
    return False


def _cpu_possibly_affected(facts: HostFacts, rule: VulnerabilityRule) -> bool:
    for cve in rule.cves:
        entry = facts.cpu_affectedness.get(cve)
        if isinstance(entry, dict) and entry.get("affected") == "possible":
            return True
    return False


def _static_mitigation(facts: HostFacts, rule: VulnerabilityRule) -> bool:
    if rule.key == "spectre_v2":
        return facts.kernel_image_findings.get("retpoline") == "present" or facts.system_map_findings.get("retpoline") == "present"
    if rule.key == "spectre_v1":
        return (
            facts.kernel_image_findings.get("array_index_mask_nospec") == "present"
            or facts.system_map_findings.get("array_index_mask_nospec") == "present"
        )
    if rule.key in {"msbds", "mfbds", "mlpds", "mdsum", "reg_file_data_sampling"}:
        return facts.kernel_image_findings.get("verw") == "present" or facts.system_map_findings.get("md_clear") == "present"
    if rule.key == "gather_data_sampling":
        return facts.system_map_findings.get("gds") == "present" or facts.kernel_image_findings.get("gds") == "present"
    if rule.key == "bhi":
        return facts.system_map_findings.get("bhi") == "present"
    return False


def _normalized_vendor(raw: str | None) -> str | None:
    if not raw:
        return None
    text = raw.lower()
    if "intel" in text or "genuineintel" in text:
        return "intel"
    if "amd" in text or "authenticamd" in text:
        return "amd"
    if "arm" in text or "aarch" in text:
        return "arm"
    if "risc" in text:
        return "riscv"
    return None
