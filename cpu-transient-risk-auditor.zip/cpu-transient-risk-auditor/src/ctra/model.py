from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class Policy:
    profile: str = "standard"
    fail_on_priority: str = "P2"
    treat_unknown_as_risk: bool = True
    require_root_for_high_confidence: bool = True
    smt_elevates: bool = True
    hypervisor_elevates: bool = True
    vendor_data_path: str | None = None


@dataclass(frozen=True)
class Evidence:
    source: str
    key: str
    value: Any
    status: str | None = None
    message: str | None = None


@dataclass(frozen=True)
class SysfsInterpretation:
    status: str
    mitigation: str | None = None
    residual_risk: bool = False
    residual_reason: str | None = None
    raw: str | None = None


@dataclass(frozen=True)
class VulnerabilityRule:
    key: str
    title: str
    aliases: tuple[str, ...] = ()
    cves: tuple[str, ...] = ()
    sysfs_keys: tuple[str, ...] = ()
    risky_cmdline: tuple[str, ...] = ()
    positive_cmdline: tuple[str, ...] = ()
    kernel_configs: tuple[str, ...] = ()
    required_capabilities: tuple[str, ...] = ()
    smt_sensitive: bool = False
    hypervisor_sensitive: bool = False
    high_impact: bool = False
    applicable_vendors: tuple[str, ...] = ()
    applicable_architectures: tuple[str, ...] = ()


@dataclass
class Finding:
    key: str
    title: str
    cves: list[str]
    verdict: str
    priority: str
    confidence: str
    exposure: str
    summary: str
    remediation: list[str] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Summary:
    total: int = 0
    p1: int = 0
    p2: int = 0
    p3: int = 0
    ok: int = 0
    vulnerable: int = 0
    unknown: int = 0
    highest_priority: str = "OK"
    exit_code: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ScanMetadata:
    mode: str = "live"
    use_runtime: bool = True
    use_sysfs: bool = True
    use_hardware: bool = True
    use_kernel_config: bool = True
    selected_cves: list[str] = field(default_factory=list)
    selected_variants: list[str] = field(default_factory=list)
    selected_errata: list[str] = field(default_factory=list)
    selected_rule_count: int | None = None
    reduced_accuracy: bool = False
    reduced_accuracy_reasons: list[str] = field(default_factory=list)
    cpu_selector: str = "0"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class HostFacts:
    os_name: str | None = None
    kernel_release: str | None = None
    kernel_version: str | None = None
    machine: str | None = None
    root_path: str = "/"
    run_as_root: bool | None = None
    cpu_vendor: str | None = None
    cpu_model_name: str | None = None
    cpu_family: int | None = None
    cpu_model: int | None = None
    cpu_stepping: int | None = None
    cpu_signature: str | None = None
    cpu_platform_id_mask: int | None = None
    microcode: str | None = None
    microcode_latest: str | None = None
    microcode_status: str | None = None
    microcode_source: str | None = None
    cpu_flags: set[str] = field(default_factory=set)
    logical_cpu_count: int | None = None
    smt_enabled: bool | None = None
    hypervisor_present: bool | None = None
    hypervisor_host: bool | None = None
    hypervisor_reason: str | None = None
    container_runtime: bool | None = None
    container_reason: str | None = None
    lockdown: str | None = None
    kernel_cmdline: str | None = None
    kernel_cmdline_findings: dict[str, str] = field(default_factory=dict)
    kernel_config_path: str | None = None
    kernel_config: dict[str, str] = field(default_factory=dict)
    kernel_image_path: str | None = None
    kernel_image_findings: dict[str, str] = field(default_factory=dict)
    system_map_path: str | None = None
    system_map_findings: dict[str, str] = field(default_factory=dict)
    os_release: dict[str, str] = field(default_factory=dict)
    vulnerabilities: dict[str, str] = field(default_factory=dict)
    cpuid: dict[str, Any] = field(default_factory=dict)
    cpu_capabilities: dict[str, Any] = field(default_factory=dict)
    msr: dict[str, Any] = field(default_factory=dict)
    cpu_affectedness: dict[str, Any] = field(default_factory=dict)
    cpu_not_affected: dict[str, Any] = field(default_factory=dict)
    affectedness_source: str | None = None
    vendor_advisories: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["cpu_flags"] = sorted(self.cpu_flags)
        return data


@dataclass
class Report:
    tool: dict[str, Any]
    policy: Policy
    scan: ScanMetadata
    asset: dict[str, Any]
    host: HostFacts
    summary: Summary
    findings: list[Finding]

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool": self.tool,
            "policy": asdict(self.policy),
            "scan": self.scan.to_dict(),
            "asset": self.asset,
            "host": self.host.to_dict(),
            "summary": self.summary.to_dict(),
            "findings": [finding.to_dict() for finding in self.findings],
        }
