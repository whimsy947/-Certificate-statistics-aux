from __future__ import annotations

from .model import Finding, VulnerabilityRule
from .rules import RULES


ERRATA_TO_RULE = {
    "1165522": "arm_spec_at",
    "1319367": "arm_spec_at",
    "1319537": "arm_spec_at",
    "1530923": "arm_spec_at",
    "2966298": "arm_spec_unpriv_load",
    "3117295": "arm_spec_unpriv_load",
    "3194386": "arm_ssbs_nosync",
}


FAMILY_TO_RULES = {
    "l1tf": {"l1tf_sgx", "l1tf_os", "l1tf_vmm"},
    "foreshadow": {"l1tf_sgx", "l1tf_os", "l1tf_vmm"},
    "mds": {"msbds", "mfbds", "mlpds", "mdsum"},
    "mmio": {"sbdr", "sbds", "drpw"},
    "mmiostaledata": {"sbdr", "sbds", "drpw"},
    "retbleed": {"retbleed"},
    "tsa": {"tsa_sq", "tsa_l1"},
    "arm": {"arm_spec_at", "arm_spec_unpriv_load", "arm_ssbs_nosync"},
}


def selected_rule_keys(cves: list[str] | None, variants: list[str] | None, errata: list[str] | None) -> set[str] | None:
    selectors = [bool(cves), bool(variants), bool(errata)]
    if not any(selectors):
        return None

    selected: set[str] = set()
    wanted_cves = {item.upper() for item in cves or []}
    wanted_variants = {_normalize(item) for item in variants or []}
    wanted_errata = {item.strip() for item in errata or []}

    for item in wanted_variants:
        selected.update(FAMILY_TO_RULES.get(item, set()))

    for rule in RULES:
        if wanted_cves.intersection(cve.upper() for cve in rule.cves):
            selected.add(rule.key)
            continue
        names = {_normalize(rule.key), _normalize(rule.title), *(_normalize(alias) for alias in rule.aliases)}
        names.update(_normalize(cve) for cve in rule.cves)
        if wanted_variants.intersection(names):
            selected.add(rule.key)

    for item in wanted_errata:
        key = ERRATA_TO_RULE.get(item)
        if key:
            selected.add(key)
    return selected


def filter_rules(rules: tuple[VulnerabilityRule, ...], selected: set[str] | None) -> tuple[VulnerabilityRule, ...]:
    if selected is None:
        return rules
    return tuple(rule for rule in rules if rule.key in selected)


def filter_findings(findings: list[Finding], selected: set[str] | None) -> list[Finding]:
    if selected is None:
        return findings
    return [finding for finding in findings if finding.key in selected]


def _normalize(value: str) -> str:
    return "".join(ch.lower() for ch in value if ch.isalnum())
