from __future__ import annotations

import csv
import html as html_lib
import json
import sys
from typing import TextIO

from .model import Finding, Report


def emit_json(report: Report, stream: TextIO = sys.stdout) -> None:
    json.dump(report.to_dict(), stream, indent=2, sort_keys=True)
    stream.write("\n")


def emit_markdown(report: Report, stream: TextIO = sys.stdout) -> None:
    host = report.host
    stream.write("# CPU Transient-Execution Risk Report\n\n")
    stream.write(f"- Kernel: `{host.kernel_release or 'unknown'}`\n")
    stream.write(f"- Machine: `{host.machine or 'unknown'}`\n")
    stream.write(f"- CPU: `{host.cpu_model_name or host.cpu_vendor or 'unknown'}`\n")
    stream.write(f"- Mode: `{report.scan.mode}`\n")
    stream.write(f"- Reduced accuracy: `{report.scan.reduced_accuracy}`\n")
    stream.write(f"- SMT enabled: `{host.smt_enabled}`\n")
    stream.write(f"- Hypervisor host: `{host.hypervisor_host}`\n\n")
    stream.write("| Priority | Finding | Verdict | Exposure | Confidence | CVEs | Summary | Next Action |\n")
    stream.write("|---|---|---|---|---|---|---|---|\n")
    for finding in _sorted_findings(report.findings):
        cves = ", ".join(finding.cves) or "-"
        stream.write(
            f"| {finding.priority} | {finding.title} | {finding.verdict} | "
            f"{finding.exposure} | {finding.confidence} | {cves} | {finding.summary} | {_first_action(finding)} |\n"
        )


def emit_csv(report: Report, stream: TextIO = sys.stdout) -> None:
    writer = csv.DictWriter(
        stream,
        fieldnames=["priority", "key", "title", "verdict", "exposure", "confidence", "cves", "summary", "remediation"],
    )
    writer.writeheader()
    for finding in _sorted_findings(report.findings):
        writer.writerow(
            {
                "priority": finding.priority,
                "key": finding.key,
                "title": finding.title,
                "verdict": finding.verdict,
                "exposure": finding.exposure,
                "confidence": finding.confidence,
                "cves": " ".join(finding.cves),
                "summary": finding.summary,
                "remediation": " | ".join(finding.remediation),
            }
        )


def emit_html(report: Report, stream: TextIO = sys.stdout) -> None:
    host = report.host
    rows = []
    for finding in _sorted_findings(report.findings):
        css = finding.priority.lower()
        cves = html_lib.escape(", ".join(finding.cves) or "-")
        rows.append(
            "<tr class='{css}'><td>{priority}</td><td>{title}</td><td>{verdict}</td>"
            "<td>{exposure}</td><td>{confidence}</td><td>{cves}</td><td>{summary}</td><td>{action}</td></tr>".format(
                css=css,
                priority=html_lib.escape(finding.priority),
                title=html_lib.escape(finding.title),
                verdict=html_lib.escape(finding.verdict),
                exposure=html_lib.escape(finding.exposure),
                confidence=html_lib.escape(finding.confidence),
                cves=cves,
                summary=html_lib.escape(finding.summary),
                action=html_lib.escape(_first_action(finding)),
            )
        )
    stream.write(
        """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>CPU Transient-Execution Risk Report</title>
<style>
body {{ font-family: system-ui, sans-serif; margin: 2rem; color: #1f2937; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #d1d5db; padding: .45rem .55rem; text-align: left; vertical-align: top; }}
th {{ background: #f3f4f6; }}
.p1 {{ background: #fee2e2; }}
.p2 {{ background: #ffedd5; }}
.p3 {{ background: #fef9c3; }}
.ok {{ background: #ecfdf5; }}
code {{ background: #f3f4f6; padding: .1rem .25rem; }}
</style>
</head>
<body>
<h1>CPU Transient-Execution Risk Report</h1>
<p><strong>Kernel:</strong> <code>{kernel}</code><br>
<strong>CPU:</strong> <code>{cpu}</code><br>
<strong>Mode:</strong> <code>{mode}</code><br>
<strong>Reduced accuracy:</strong> <code>{reduced_accuracy}</code><br>
<strong>SMT enabled:</strong> <code>{smt}</code><br>
<strong>Hypervisor host:</strong> <code>{hypervisor}</code></p>
<p><strong>Summary:</strong> P1={p1}, P2={p2}, P3={p3}, OK={ok}, highest={highest}</p>
<table>
<thead><tr><th>Priority</th><th>Finding</th><th>Verdict</th><th>Exposure</th><th>Confidence</th><th>CVEs</th><th>Summary</th><th>Next Action</th></tr></thead>
<tbody>
{rows}
</tbody>
</table>
</body>
</html>
""".format(
            kernel=html_lib.escape(host.kernel_release or "unknown"),
            cpu=html_lib.escape(host.cpu_model_name or host.cpu_vendor or "unknown"),
            mode=html_lib.escape(report.scan.mode),
            reduced_accuracy=html_lib.escape(str(report.scan.reduced_accuracy)),
            smt=html_lib.escape(str(host.smt_enabled)),
            hypervisor=html_lib.escape(str(host.hypervisor_host)),
            p1=report.summary.p1,
            p2=report.summary.p2,
            p3=report.summary.p3,
            ok=report.summary.ok,
            highest=html_lib.escape(report.summary.highest_priority),
            rows="\n".join(rows),
        )
    )


def _sorted_findings(findings: list[Finding]) -> list[Finding]:
    order = {"P1": 0, "P2": 1, "P3": 2, "OK": 3}
    return sorted(findings, key=lambda item: (order.get(item.priority, 9), item.key))


def _first_action(finding: Finding) -> str:
    return finding.remediation[0] if finding.remediation else ""
