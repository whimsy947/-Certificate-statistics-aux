from __future__ import annotations

from .constants import load_cpu_constants
from .inteldb import lookup_intel_affected
from ..model import HostFacts


SOURCE = "gpl-refactored-affectedness"

SPECTRE_CLASS_CVES = (
    "CVE-2017-5753",
    "CVE-2017-5715",
    "CVE-2017-5754",
    "CVE-2018-3640",
    "CVE-2018-3639",
    "CVE-2018-3615",
    "CVE-2018-3620",
    "CVE-2018-3646",
    "CVE-2018-12126",
    "CVE-2018-12130",
    "CVE-2018-12127",
    "CVE-2019-11091",
    "CVE-2019-11135",
    "CVE-2020-0543",
    "CVE-2022-21123",
    "CVE-2022-21125",
    "CVE-2022-21166",
)
MDS_CVES = ("CVE-2018-12126", "CVE-2018-12130", "CVE-2018-12127", "CVE-2019-11091")
MDS_NON_MSBDS_CVES = ("CVE-2018-12130", "CVE-2018-12127", "CVE-2019-11091")
MMIO_CVES = ("CVE-2022-21123", "CVE-2022-21125", "CVE-2022-21166")
L1TF_CVES = ("CVE-2018-3615", "CVE-2018-3620", "CVE-2018-3646")


def apply_gpl_refactored_affectedness(facts: HostFacts) -> None:
    constants = load_cpu_constants()
    if not constants:
        return
    _apply_intel_affected_db(facts)

    if is_cpu_mds_free(facts, constants):
        _mark_many(facts, MDS_CVES, "GPL is_cpu_mds_free")
    elif is_cpu_msbds_only(facts, constants):
        _mark_many(facts, MDS_NON_MSBDS_CVES, "GPL is_cpu_msbds_only")

    if is_cpu_taa_free(facts):
        _mark(facts, "CVE-2019-11135", "GPL is_cpu_taa_free")
    if is_cpu_srbds_free(facts, constants):
        _mark(facts, "CVE-2020-0543", "GPL is_cpu_srbds_free")
    if is_cpu_mmio_free(facts, constants):
        _mark_many(facts, MMIO_CVES, "GPL is_cpu_mmio_free")

    if _is_centaur_or_zhaoxin(facts) and facts.cpu_family == 7:
        _mark(facts, "CVE-2017-5715", "GPL Centaur/Zhaoxin family 7 Spectre V2 immunity")

    if is_cpu_specex_free(facts, constants):
        _mark_many(facts, SPECTRE_CLASS_CVES, "GPL is_cpu_specex_free")
    elif _is_intel(facts):
        _apply_intel_specific_immunity(facts, constants)
    elif _is_amd(facts):
        _mark_many(facts, ("CVE-2017-5754", *L1TF_CVES), "GPL AMD NO_MELTDOWN/NO_L1TF")
        if is_cpu_ssb_free(facts, constants):
            _mark(facts, "CVE-2018-3639", "GPL is_cpu_ssb_free")
    elif _is_hygon(facts):
        _mark_many(facts, ("CVE-2017-5754", *L1TF_CVES), "GPL Hygon NO_MELTDOWN/NO_L1TF")


def _apply_intel_affected_db(facts: HostFacts) -> None:
    if not _is_intel(facts):
        return
    entry = lookup_intel_affected(facts.cpu_signature, hybrid=_cap(facts, "hybrid"))
    if not entry:
        return
    for cve, status in entry.cves.items():
        if cve == "CVE-2018-3615" and not (_cap(facts, "sgx") or "sgx" in facts.cpu_flags):
            _mark(facts, cve, "GPL Intel affected DB says SGX-specific CVE is not applicable without SGX")
            continue
        if status == "N":
            _mark(facts, cve, f"GPL Intel affected DB status {status}")
        elif status:
            facts.cpu_affectedness.setdefault(
                cve,
                {
                    "affected": True,
                    "source": "gpl-refactored-intel-affected-db",
                    "notes": f"Intel affected processor list status {status}",
                },
            )


def is_cpu_specex_free(facts: HostFacts, constants: dict[str, int]) -> bool:
    family = facts.cpu_family
    model = facts.cpu_model
    if _is_intel(facts):
        if family == 6 and model in _values(
            constants,
            "INTEL_FAM6_ATOM_SALTWELL",
            "INTEL_FAM6_ATOM_SALTWELL_TABLET",
            "INTEL_FAM6_ATOM_BONNELL_MID",
            "INTEL_FAM6_ATOM_SALTWELL_MID",
            "INTEL_FAM6_ATOM_BONNELL",
        ):
            return True
        if family == 5:
            return True
    if (_vendor_text(facts) == "centaurhauls" or _vendor_text(facts) == "geode by nsc") and family == 5:
        return True
    return family == 4


def is_cpu_mds_free(facts: HostFacts, constants: dict[str, int]) -> bool:
    if _is_intel(facts):
        if facts.cpu_family == 6 and facts.cpu_model in _values(
            constants,
            "INTEL_FAM6_ATOM_GOLDMONT",
            "INTEL_FAM6_ATOM_GOLDMONT_D",
            "INTEL_FAM6_ATOM_GOLDMONT_PLUS",
        ):
            return True
        return _cap(facts, "mds_no")
    return _is_amd(facts) or _is_hygon(facts) or _vendor_text(facts) in {"arm", "cavium", "phytium"}


def is_cpu_msbds_only(facts: HostFacts, constants: dict[str, int]) -> bool:
    return _is_intel(facts) and facts.cpu_family == 6 and facts.cpu_model in _values(
        constants,
        "INTEL_FAM6_ATOM_SILVERMONT",
        "INTEL_FAM6_ATOM_SILVERMONT_D",
        "INTEL_FAM6_ATOM_SILVERMONT_MID",
        "INTEL_FAM6_ATOM_SILVERMONT_MID2",
        "INTEL_FAM6_ATOM_AIRMONT",
        "INTEL_FAM6_XEON_PHI_KNL",
        "INTEL_FAM6_XEON_PHI_KNM",
    )


def is_cpu_taa_free(facts: HostFacts) -> bool:
    if not _is_intel(facts):
        return True
    if _cap(facts, "taa_no"):
        return True
    return not (_cap(facts, "rtm") or "rtm" in facts.cpu_flags)


def is_cpu_srbds_free(facts: HostFacts, constants: dict[str, int]) -> bool:
    if not _is_intel(facts) or facts.cpu_family != 6:
        return True
    if facts.cpu_model in _values(
        constants,
        "INTEL_FAM6_IVYBRIDGE",
        "INTEL_FAM6_HASWELL",
        "INTEL_FAM6_HASWELL_L",
        "INTEL_FAM6_HASWELL_G",
        "INTEL_FAM6_BROADWELL_G",
        "INTEL_FAM6_BROADWELL",
        "INTEL_FAM6_SKYLAKE_L",
        "INTEL_FAM6_SKYLAKE",
    ):
        return False
    if facts.cpu_model == constants.get("INTEL_FAM6_KABYLAKE_L") and _stepping_lte(facts, 12):
        return _cap(facts, "mds_no") and (not _cap(facts, "rtm") or _cap(facts, "rtm_disabled") or _cap(facts, "tsx_force_abort_rtm_disabled"))
    if facts.cpu_model == constants.get("INTEL_FAM6_KABYLAKE") and _stepping_lte(facts, 13):
        return _cap(facts, "mds_no") and (not _cap(facts, "rtm") or _cap(facts, "rtm_disabled") or _cap(facts, "tsx_force_abort_rtm_disabled"))
    return True


def is_cpu_mmio_free(facts: HostFacts, constants: dict[str, int]) -> bool:
    if _arch_cap_mmio_immune(facts):
        return True
    if _is_amd(facts) or _is_hygon(facts):
        return True
    if _is_centaur_or_zhaoxin(facts) and facts.cpu_family == 7:
        return True
    return _is_intel(facts) and facts.cpu_family == 6 and facts.cpu_model in _values(
        constants,
        "INTEL_FAM6_TIGERLAKE",
        "INTEL_FAM6_TIGERLAKE_L",
        "INTEL_FAM6_ALDERLAKE",
        "INTEL_FAM6_ALDERLAKE_L",
        "INTEL_FAM6_ATOM_GOLDMONT",
        "INTEL_FAM6_ATOM_GOLDMONT_D",
        "INTEL_FAM6_ATOM_GOLDMONT_PLUS",
    )


def is_cpu_ssb_free(facts: HostFacts, constants: dict[str, int]) -> bool:
    if _is_intel(facts) and facts.cpu_family == 6:
        return facts.cpu_model in _values(
            constants,
            "INTEL_FAM6_ATOM_AIRMONT",
            "INTEL_FAM6_ATOM_SILVERMONT",
            "INTEL_FAM6_ATOM_SILVERMONT_D",
            "INTEL_FAM6_ATOM_SILVERMONT_MID",
            "INTEL_FAM6_CORE_YONAH",
            "INTEL_FAM6_XEON_PHI_KNL",
            "INTEL_FAM6_XEON_PHI_KNM",
        )
    if _is_amd(facts):
        return facts.cpu_family in {0x12, 0x11, 0x10, 0x0F}
    if _is_hygon(facts):
        return False
    return facts.cpu_family == 4


def _apply_intel_specific_immunity(facts: HostFacts, constants: dict[str, int]) -> None:
    if _cap(facts, "rdcl_no"):
        _mark_many(facts, ("CVE-2017-5754", *L1TF_CVES), "GPL RDCL_NO")
    if _cap(facts, "ssb_no") or is_cpu_ssb_free(facts, constants):
        _mark(facts, "CVE-2018-3639", "GPL SSB_NO/is_cpu_ssb_free")
    if facts.cpu_family == 6:
        if facts.cpu_model in _values(
            constants,
            "INTEL_FAM6_XEON_PHI_KNL",
            "INTEL_FAM6_XEON_PHI_KNM",
            "INTEL_FAM6_ATOM_SILVERMONT",
            "INTEL_FAM6_ATOM_SILVERMONT_MID",
            "INTEL_FAM6_ATOM_SILVERMONT_D",
        ):
            _mark(facts, "CVE-2018-3640", "GPL Intel variant3a model immunity")
        if facts.cpu_model in _values(
            constants,
            "INTEL_FAM6_ATOM_SALTWELL",
            "INTEL_FAM6_ATOM_SALTWELL_TABLET",
            "INTEL_FAM6_ATOM_SALTWELL_MID",
            "INTEL_FAM6_ATOM_BONNELL",
            "INTEL_FAM6_ATOM_BONNELL_MID",
            "INTEL_FAM6_ATOM_SILVERMONT",
            "INTEL_FAM6_ATOM_SILVERMONT_MID",
            "INTEL_FAM6_ATOM_SILVERMONT_D",
            "INTEL_FAM6_ATOM_AIRMONT",
            "INTEL_FAM6_ATOM_SILVERMONT_MID2",
            "INTEL_FAM6_ATOM_AIRMONT_NP",
            "INTEL_FAM6_ATOM_GOLDMONT",
            "INTEL_FAM6_ATOM_GOLDMONT_D",
            "INTEL_FAM6_ATOM_GOLDMONT_PLUS",
            "INTEL_FAM6_ATOM_TREMONT_D",
            "INTEL_FAM6_XEON_PHI_KNL",
            "INTEL_FAM6_XEON_PHI_KNM",
        ):
            _mark_many(facts, L1TF_CVES, "GPL Intel L1TF model immunity")
    elif facts.cpu_family is not None and facts.cpu_family < 6:
        _mark_many(facts, L1TF_CVES, "GPL Intel family < 6 L1TF immunity")


def _arch_cap_mmio_immune(facts: HostFacts) -> bool:
    return _cap(facts, "sbdr_ssdp_no") and _cap(facts, "fbsdp_no") and _cap(facts, "psdp_no")


def _mark_many(facts: HostFacts, cves: tuple[str, ...], reason: str) -> None:
    for cve in cves:
        _mark(facts, cve, reason)


def _mark(facts: HostFacts, cve: str, reason: str) -> None:
    facts.cpu_not_affected.setdefault(cve, {"affected": False, "source": SOURCE, "reason": reason})


def _values(constants: dict[str, int], *names: str) -> set[int]:
    return {constants[name] for name in names if name in constants}


def _cap(facts: HostFacts, name: str) -> bool:
    return facts.cpu_capabilities.get(name) is True


def _stepping_lte(facts: HostFacts, value: int) -> bool:
    return facts.cpu_stepping is not None and facts.cpu_stepping <= value


def _vendor_text(facts: HostFacts) -> str:
    return (facts.cpu_vendor or facts.cpu_model_name or "").strip().lower()


def _is_intel(facts: HostFacts) -> bool:
    text = _vendor_text(facts)
    return "intel" in text or "genuineintel" in text


def _is_amd(facts: HostFacts) -> bool:
    text = _vendor_text(facts)
    return "amd" in text or "authenticamd" in text


def _is_hygon(facts: HostFacts) -> bool:
    return "hygon" in _vendor_text(facts)


def _is_centaur_or_zhaoxin(facts: HostFacts) -> bool:
    return _vendor_text(facts) in {"centaurhauls", "shanghai"}
