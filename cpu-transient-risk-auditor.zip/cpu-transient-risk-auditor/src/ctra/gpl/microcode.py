from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from .backend import REFERENCE_SCRIPT
from .constants import load_cpu_constants
from ..model import HostFacts


@dataclass(frozen=True)
class MicrocodeFixEntry:
    signature: str
    platform_mask: int
    fixed_microcode: str


@dataclass(frozen=True)
class BlacklistedMicrocodeEntry:
    model: int | None
    stepping: int | None
    microcode: str
    signature: str | None = None


_TUPLE_RE = re.compile(r"([0-9A-Fa-f]{2}-[0-9A-Fa-f]{2}-[0-9A-Fa-f]{2})/([0-9A-Fa-f]+),([0-9A-Fa-f]{8}|[0-9A-Fa-f]+)")


@lru_cache(maxsize=4)
def load_reptar_fix_table(script_path: str | Path = REFERENCE_SCRIPT) -> tuple[MicrocodeFixEntry, ...]:
    return _load_named_ucode_table("reptar_ucode_list", script_path)


@lru_cache(maxsize=4)
def load_bpi_fix_table(script_path: str | Path = REFERENCE_SCRIPT) -> tuple[MicrocodeFixEntry, ...]:
    return _load_named_ucode_table("bpi_ucode_list", script_path)


@lru_cache(maxsize=4)
def load_blacklisted_microcodes(script_path: str | Path = REFERENCE_SCRIPT) -> tuple[BlacklistedMicrocodeEntry, ...]:
    path = Path(script_path)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ()
    constants = load_cpu_constants(path)
    entries: list[BlacklistedMicrocodeEntry] = []
    for model_expr, stepping, microcode in re.findall(r"\$(INTEL_FAM6_[A-Z0-9_]+),0x([0-9A-Fa-f]+),0x([0-9A-Fa-f]+)", text):
        model = constants.get(model_expr)
        if model is not None:
            entries.append(BlacklistedMicrocodeEntry(model=model, stepping=int(stepping, 16), microcode=_hex(microcode)))
    for signature, microcode in re.findall(r"(0x[0-9A-Fa-f]+),0x([0-9A-Fa-f]+)", _blacklist_cpuid_block(text)):
        entries.append(BlacklistedMicrocodeEntry(model=None, stepping=None, microcode=_hex(microcode), signature=_signature(int(signature, 16))))
    return tuple(entries)


def apply_gpl_microcode_knowledge(facts: HostFacts) -> None:
    if _is_blacklisted(facts):
        facts.microcode_status = "blacklisted"
        facts.microcode_source = "gpl-refactored-microcode-blacklist"

    for cve, table_name, table in (
        ("CVE-2023-23583", "reptar", load_reptar_fix_table()),
        ("CVE-2024-45332", "bpi", load_bpi_fix_table()),
    ):
        entry = _matching_fix_entry(facts, table)
        if not entry:
            continue
        latest = entry.fixed_microcode
        status = _compare_versions(facts.microcode, latest)
        facts.cpu_affectedness[cve] = {
            "affected": status != "current",
            "source": f"gpl-refactored-{table_name}-microcode-table",
            "notes": f"requires microcode >= {latest}",
            "microcode_status": status,
        }
        if status == "current":
            facts.cpu_not_affected[cve] = {
                "affected": False,
                "source": f"gpl-refactored-{table_name}-microcode-table",
                "reason": f"microcode {facts.microcode} >= required {latest}",
            }


def _load_named_ucode_table(name: str, script_path: str | Path) -> tuple[MicrocodeFixEntry, ...]:
    path = Path(script_path)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ()
    match = re.search(rf"{re.escape(name)}='\n(.*?)\n'", text, re.DOTALL)
    if not match:
        return ()
    entries = []
    for fms, platform_mask, fixed in _TUPLE_RE.findall(match.group(1)):
        family, model, stepping = (int(part, 16) for part in fms.split("-"))
        entries.append(
            MicrocodeFixEntry(
                signature=_signature_from_fms(family, model, stepping),
                platform_mask=int(platform_mask, 16),
                fixed_microcode=_hex(fixed),
            )
        )
    return tuple(entries)


def _matching_fix_entry(facts: HostFacts, table: tuple[MicrocodeFixEntry, ...]) -> MicrocodeFixEntry | None:
    signature = _facts_signature(facts)
    if not signature:
        return None
    platform_mask = facts.cpu_platform_id_mask
    for entry in table:
        if entry.signature != signature:
            continue
        if platform_mask is None or entry.platform_mask == 0xFF or (platform_mask & entry.platform_mask):
            return entry
    return None


def _is_blacklisted(facts: HostFacts) -> bool:
    microcode = _normalize_hex(facts.microcode)
    if not microcode:
        return False
    signature = _facts_signature(facts)
    for entry in load_blacklisted_microcodes():
        if entry.microcode != microcode:
            continue
        if entry.signature and entry.signature == signature:
            return True
        if entry.model == facts.cpu_model and entry.stepping == facts.cpu_stepping:
            return True
    return False


def _blacklist_cpuid_block(text: str) -> str:
    marker = "2024-01-09 update"
    start = text.find(marker)
    if start < 0:
        return ""
    end = text.find("done", start)
    return text[start:end if end >= 0 else len(text)]


def _facts_signature(facts: HostFacts) -> str | None:
    if facts.cpu_signature:
        return _signature(int(facts.cpu_signature, 16))
    if facts.cpu_family is None or facts.cpu_model is None or facts.cpu_stepping is None:
        return None
    return _signature_from_fms(facts.cpu_family, facts.cpu_model, facts.cpu_stepping)


def _signature_from_fms(family: int, model: int, stepping: int) -> str:
    base_family = family & 0xF
    ext_family = family - 0xF if family >= 0xF else 0
    base_model = model & 0xF
    ext_model = (model >> 4) & 0xF if family in {6, 0xF} else 0
    return _signature(stepping | (base_model << 4) | (base_family << 8) | (ext_model << 16) | (ext_family << 20))


def _compare_versions(installed: str | None, latest: str) -> str:
    installed_norm = _normalize_hex(installed)
    if installed_norm is None:
        return "unknown"
    return "current" if int(installed_norm, 16) >= int(latest, 16) else "outdated"


def _normalize_hex(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return _hex(str(value))
    except ValueError:
        return None


def _hex(value: str) -> str:
    return f"0x{int(value, 16):x}"


def _signature(value: int) -> str:
    return f"0x{value:08X}"
