from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

from .backend import REFERENCE_SCRIPT


@dataclass(frozen=True)
class IntelAffectedEntry:
    signature: str
    hybrid: str | None = None
    cves: dict[str, str] = field(default_factory=dict)


@lru_cache(maxsize=4)
def load_intel_affected_db(script_path: str | Path = REFERENCE_SCRIPT) -> list[IntelAffectedEntry]:
    path = Path(script_path)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    block = _extract_block(text, "# %%% INTELDB", "# %%% ENDOFINTELDB")
    entries: list[IntelAffectedEntry] = []
    for raw_line in block.splitlines():
        line = raw_line.strip()
        if not line.startswith("# 0x"):
            continue
        line = line[1:].strip().rstrip(",")
        parts = [part for part in line.split(",") if part]
        if not parts:
            continue
        signature = f"0x{int(parts[0], 16):08X}"
        hybrid: str | None = None
        cves: dict[str, str] = {}
        for part in parts[1:]:
            if part.startswith("H="):
                hybrid = part.split("=", 1)[1]
            elif "=" in part:
                raw_cve, status = part.split("=", 1)
                cves[f"CVE-{raw_cve}"] = status
        entries.append(IntelAffectedEntry(signature=signature, hybrid=hybrid, cves=cves))
    return entries


def lookup_intel_affected(
    signature: str | None,
    *,
    hybrid: bool | None = None,
    script_path: str | Path = REFERENCE_SCRIPT,
) -> IntelAffectedEntry | None:
    if not signature:
        return None
    normalized = f"0x{int(signature, 16):08X}"
    entries = [entry for entry in load_intel_affected_db(script_path) if entry.signature == normalized]
    if hybrid is not None:
        requested = "1" if hybrid else "0"
        for entry in entries:
            if entry.hybrid == requested:
                return entry
    for entry in entries:
        if entry.hybrid is None:
            return entry
    return entries[0] if entries else None


def _extract_block(text: str, start_marker: str, end_marker: str) -> str:
    capture = False
    lines: list[str] = []
    for line in text.splitlines():
        if line.strip() == start_marker:
            capture = True
            continue
        if capture and line.strip() == end_marker:
            break
        if capture:
            lines.append(line)
    return "\n".join(lines)
