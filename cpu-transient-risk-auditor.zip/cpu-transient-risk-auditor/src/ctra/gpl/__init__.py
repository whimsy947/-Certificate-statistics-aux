"""GPL-derived reference backend helpers."""

