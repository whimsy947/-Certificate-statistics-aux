from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GplCveEntry:
    cve: str
    json_key: str
    affected_var: str
    aliases: tuple[str, ...]
    arch: str | None


def load_catalog(script_path: Path) -> tuple[GplCveEntry, ...]:
    try:
        text = script_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ()
    block = _extract_registry_block(text)
    return tuple(_parse_entry(line) for line in block.splitlines() if line.startswith("CVE-"))


def catalog_summary(script_path: Path) -> dict[str, object]:
    entries = load_catalog(script_path)
    return {
        "entries": len(entries),
        "cves": [entry.cve for entry in entries],
        "architectures": sorted({entry.arch for entry in entries if entry.arch}),
    }


def _extract_registry_block(text: str) -> str:
    marker = "readonly CVE_REGISTRY='"
    start = text.find(marker)
    if start < 0:
        return ""
    start += len(marker)
    end = text.find("'\n", start)
    if end < 0:
        return ""
    return text[start:end]


def _parse_entry(line: str) -> GplCveEntry:
    cve, json_key, affected_var, aliases, arch = (line.split("|", 4) + [""])[:5]
    return GplCveEntry(
        cve=cve,
        json_key=json_key,
        affected_var=affected_var,
        aliases=tuple(item.strip() for item in aliases.split(",") if item.strip()),
        arch=arch or None,
    )
