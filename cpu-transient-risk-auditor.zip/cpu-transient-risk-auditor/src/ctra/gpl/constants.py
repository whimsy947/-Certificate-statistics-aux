from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path

from .backend import REFERENCE_SCRIPT


_READONLY_INT_RE = re.compile(r"^\s*readonly\s+([A-Z0-9_]+)=\$\(\((0x[0-9A-Fa-f]+|\d+)\)\)", re.MULTILINE)


@lru_cache(maxsize=4)
def load_cpu_constants(script_path: str | Path = REFERENCE_SCRIPT) -> dict[str, int]:
    path = Path(script_path)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}
    constants: dict[str, int] = {}
    for name, value in _READONLY_INT_RE.findall(text):
        constants[name] = int(value, 0)
    return constants
