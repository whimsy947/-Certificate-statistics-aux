from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ReferenceVulnerability:
    cve: str
    status: str
    raw: dict[str, Any]


def normalize_vulnerabilities(report: dict[str, Any] | None) -> list[ReferenceVulnerability]:
    if not report:
        return []
    vulnerabilities = report.get("vulnerabilities") or []
    if not isinstance(vulnerabilities, list):
        return []
    normalized: list[ReferenceVulnerability] = []
    for item in vulnerabilities:
        if not isinstance(item, dict):
            continue
        cve = item.get("cve") or item.get("id")
        if not isinstance(cve, str):
            continue
        normalized.append(ReferenceVulnerability(cve=cve.upper(), status=normalize_status(item), raw=item))
    return normalized


def by_cve(items: list[ReferenceVulnerability]) -> dict[str, ReferenceVulnerability]:
    return {item.cve: item for item in items}


def normalize_status(item: dict[str, Any]) -> str:
    for key in ("status", "vulnerable", "is_vulnerable"):
        value = item.get(key)
        if value is True:
            return "VULNERABLE"
        if value is False:
            return "OK"
        text = str(value or "").strip().lower()
        if text in {"vulnerable", "yes", "true"}:
            return "VULNERABLE"
        if text in {"not vulnerable", "not_vulnerable", "ok", "false", "no"}:
            return "OK"
        if text == "unknown":
            return "UNKNOWN"
    return "UNKNOWN"


def is_vulnerable(item: ReferenceVulnerability) -> bool:
    return item.status == "VULNERABLE"


def aggregate_status(items: list[ReferenceVulnerability]) -> str:
    if any(item.status == "VULNERABLE" for item in items):
        return "VULNERABLE"
    if any(item.status == "UNKNOWN" for item in items):
        return "UNKNOWN"
    return "OK"
