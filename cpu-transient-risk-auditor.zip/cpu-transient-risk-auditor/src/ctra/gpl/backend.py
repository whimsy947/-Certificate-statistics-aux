from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any


REFERENCE_SCRIPT = Path(__file__).resolve().parents[3] / "third_party" / "gpl" / "spectre-meltdown-checker.sh"


def run_reference_backend(args: list[str] | None = None, timeout: int = 120) -> dict[str, Any]:
    if not REFERENCE_SCRIPT.exists():
        return {"available": False, "error": "reference script not found"}
    command = command_for(args or [])
    try:
        completed = subprocess.run(command, check=False, capture_output=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError) as exc:
        return {"available": True, "error": str(exc), "command": command}
    payload = parse_json(_decode(completed.stdout))
    return {
        "available": True,
        "command": command,
        "returncode": completed.returncode,
        "error": _decode(completed.stderr).strip() or None,
        "report": payload,
    }


def command_for(extra_args: list[str]) -> list[str]:
    script = str(REFERENCE_SCRIPT)
    base_args = [script, "--batch", "json", *extra_args]
    if os.name == "nt":
        shell = shutil.which("bash") or shutil.which("sh")
        if shell:
            return [shell, *base_args]
        return ["sh", *base_args]
    return [script, "--batch", "json", *extra_args]


def parse_json(output: str) -> dict[str, Any] | None:
    output = output.strip()
    if not output:
        return None
    try:
        return json.loads(output)
    except json.JSONDecodeError:
        start = output.find("{")
        end = output.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(output[start : end + 1])
            except json.JSONDecodeError:
                return None
    return None


def _decode(data: bytes | None) -> str:
    if not data:
        return ""
    return data.decode("utf-8", errors="backslashreplace")
