from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .model import HostFacts


def load_vendor_data(path: str | None) -> dict[str, Any]:
    if not path:
        return {}
    try:
        with Path(path).open(encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def match_vendor_advisories(facts: HostFacts, vendor_data: dict[str, Any]) -> dict[str, Any]:
    matches: dict[str, Any] = {}
    cpu = {
        "vendor": facts.cpu_vendor,
        "family": facts.cpu_family,
        "model": facts.cpu_model,
        "stepping": facts.cpu_stepping,
    }
    for cve, entry in vendor_data.get("cves", {}).items():
        affected = entry.get("affected", [])
        for rule in affected:
            if _matches_cpu(cpu, rule):
                matches[cve] = entry
                break
    return matches


def _matches_cpu(cpu: dict[str, Any], rule: dict[str, Any]) -> bool:
    vendor = rule.get("vendor")
    if vendor and cpu["vendor"] and vendor.lower() not in str(cpu["vendor"]).lower():
        return False
    for field in ("family", "model", "stepping"):
        expected = rule.get(field)
        if expected is None:
            continue
        values = expected if isinstance(expected, list) else [expected]
        if cpu[field] not in values:
            return False
    return True
