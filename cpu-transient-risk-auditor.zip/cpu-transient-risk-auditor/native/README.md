# Optional Native Probes

The auditor works without native helpers. These helpers add deeper x86 evidence
when a host policy allows it.

Build CPUID helper on x86 Linux:

```sh
cc -O2 -Wall -Wextra -o native/ctra-cpuid native/ctra_cpuid.c
```

Run scan:

```sh
PYTHONPATH=src python -m ctra scan --format json
```

MSR reads require `/dev/cpu/0/msr`, the `msr` kernel module, and sufficient
privileges. Failure is non-fatal and only lowers available evidence.
