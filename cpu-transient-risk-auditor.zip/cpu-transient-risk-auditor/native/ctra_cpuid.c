// Optional CPUID probe helper for cpu-transient-risk-auditor.
// Build on x86 Linux with: cc -O2 -Wall -Wextra -o ctra-cpuid ctra_cpuid.c

#include <stdint.h>
#include <stdio.h>

#if defined(__i386__) || defined(__x86_64__)
static void cpuid(uint32_t leaf, uint32_t subleaf, uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d) {
#if defined(__GNUC__) || defined(__clang__)
    __asm__ volatile("cpuid"
                     : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d)
                     : "a"(leaf), "c"(subleaf));
#else
    *a = *b = *c = *d = 0;
#endif
}
#endif

int main(void) {
#if defined(__i386__) || defined(__x86_64__)
    uint32_t a, b, c, d;

    cpuid(0x1, 0, &a, &b, &c, &d);
    printf("cpuid.leaf_1_eax=0x%08x\n", a);
    printf("cpuid.leaf_1_ecx=0x%08x\n", c);
    printf("cpuid.leaf_1_edx=0x%08x\n", d);

    cpuid(0x7, 0, &a, &b, &c, &d);
    printf("cpuid.leaf_7_0_ebx=0x%08x\n", b);
    printf("cpuid.leaf_7_0_edx=0x%08x\n", d);

    cpuid(0x80000008u, 0, &a, &b, &c, &d);
    printf("cpuid.leaf_80000008_ebx=0x%08x\n", b);
    return 0;
#else
    return 1;
#endif
}
