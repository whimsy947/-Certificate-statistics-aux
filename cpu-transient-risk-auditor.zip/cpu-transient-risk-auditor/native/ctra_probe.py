#!/usr/bin/env python3
"""Optional low-level probe helper.

This helper is intentionally best-effort. The main auditor must work without it.
When running on Linux with enough privileges, it reads a few MSRs that are useful
for transient-execution mitigation posture. CPUID is delegated to the optional C
helper when compiled as `ctra-cpuid` beside this file.
"""

from __future__ import annotations

import os
import struct
import subprocess
import argparse
from pathlib import Path


MSRS = {
    "ia32_platform_id": 0x17,
    "ia32_spec_ctrl": 0x48,
    "ia32_pred_cmd": 0x49,
    "ia32_arch_capabilities": 0x10A,
    "ia32_flush_cmd": 0x10B,
    "ia32_tsx_ctrl": 0x122,
    "ia32_mcu_opt_ctrl": 0x123,
}


def main() -> int:
    parser = argparse.ArgumentParser(description="Best-effort CTRA native probe")
    parser.add_argument("--cpu", default="0", help="CPU selector: 0, N, or all")
    args = parser.parse_args()
    cpus = selected_cpus(args.cpu)
    emit_cpuid()
    for cpu in cpus:
        emit_msrs(cpu)
    return 0


def emit_cpuid() -> None:
    helper = Path(__file__).with_name("ctra-cpuid")
    if os.name == "nt" or not helper.exists():
        return
    try:
        completed = subprocess.run([str(helper)], check=False, capture_output=True, text=True, timeout=2)
    except (OSError, subprocess.SubprocessError):
        return
    if completed.returncode == 0:
        print(completed.stdout, end="")


def selected_cpus(selector: str) -> list[int]:
    if selector == "all":
        base = Path("/dev/cpu")
        cpus = []
        try:
            for entry in base.iterdir():
                if entry.name.isdigit() and (entry / "msr").exists():
                    cpus.append(int(entry.name))
        except OSError:
            return [0]
        return sorted(cpus) or [0]
    try:
        return [max(0, int(selector))]
    except ValueError:
        return [0]


def emit_msrs(cpu: int) -> None:
    msr_path = Path(f"/dev/cpu/{cpu}/msr")
    if not msr_path.exists():
        return
    try:
        with msr_path.open("rb", buffering=0) as handle:
            for name, offset in MSRS.items():
                try:
                    handle.seek(offset)
                    value = struct.unpack("<Q", handle.read(8))[0]
                except OSError:
                    continue
                suffix = "" if cpu == 0 else f".cpu{cpu}"
                print(f"msr.{name}{suffix}=0x{value:016x}")
    except OSError:
        return


if __name__ == "__main__":
    raise SystemExit(main())
