# GPL Integration Notice

This project can operate in two modes:

- Independent mode: the Python auditor runs without the GPL reference backend.
- GPL reference mode: `--reference-backend attach|augment` invokes the vendored
  `third_party/gpl/spectre-meltdown-checker.sh`.

Because the reference backend is GPL-3.0-only, any company distribution that
ships the vendored script with this repository should be handled as a GPL
distribution. Provide source code, preserve copyright/license notices, and track
local modifications.

The Python modules were originally written independently, but this repository
now intentionally contains GPL code at the user's request.

