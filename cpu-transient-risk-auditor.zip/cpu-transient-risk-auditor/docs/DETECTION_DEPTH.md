# Detection Depth

This project is designed to grow beyond a sysfs-only posture checker while
remaining independent and auditable.

## Current Evidence Sources

- Linux vulnerability sysfs:
  `/sys/devices/system/cpu/vulnerabilities/*`
- CPU inventory:
  `/proc/cpuinfo`
- Microcode revision:
  `/proc/cpuinfo` `microcode` field on x86
- SMT state:
  `/sys/devices/system/cpu/smt/active`
- Hypervisor-host hints:
  `/proc/modules`
- Container hints:
  `/proc/1/cgroup` and `/proc/1/mountinfo`
- Kernel command line:
  `/proc/cmdline`
- Optional native probes:
  `native/ctra-cpuid` and `/dev/cpu/0/msr`
- Decoded CPUID/MSR capability flags:
  `MD_CLEAR`, `IBRS/IBPB`, `STIBP`, `SSBD`, `ARCH_CAPABILITIES`,
  `RDCL_NO`, `MDS_NO`, `TAA_NO`, `GDS_NO`, `RFDS_NO`, `BHI_NO`,
  `IA32_SPEC_CTRL`, `IA32_TSX_CTRL`, and related AMD extended bits
- Optional company-maintained vendor data:
  `--vendor-data vendor-data.json`
- Optional company-maintained microcode database:
  `--microcode-db microcode-db.json`
- Optional company-maintained CPU affectedness database:
  `--affected-db affected-db.json`
- Built-in CPUID-derived affectedness hints:
  architectural not-affected bits such as `RDCL_NO`, `SSB_NO`, `MDS_NO`,
  `TAA_NO`, `GDS_NO`, `RFDS_NO`, and `BHI_NO`
- Kernel config:
  `/boot/config-*`, `/lib/modules/*/build/.config`, `/proc/config.gz`, or
  `--kernel-config`
- Kernel image/static artifact scan:
  `--kernel-image`
- System.map/static symbol scan:
  `--system-map` or automatic discovery under `/boot`

## Coverage

The rule registry currently emits 37 findings, covering or exceeding the common
Spectre/Meltdown-family checks in the reference shell scanner:

- Spectre V1/V2, Meltdown, Variant 3A, Speculative Store Bypass
- L1TF SGX/OS/VMM
- MDS MSBDS/MFBDS/MLPDS/MDSUM
- TAA, iTLB Multihit, SRBDS
- MMIO stale data SBDR/SBDS/DRPW
- DIV0, Zenbleed, Downfall/GDS, Retbleed, Inception, Reptar
- ITS, VMScape, RFDS, BPI, SLS, FPDSS
- ARM errata checks for speculative AT, speculative unprivileged load, and SSBS

Use `python -m ctra coverage` for a machine-readable coverage report. The
current registry covers 27 reference families with no missing family entries and
tracks 35 explicit CVE identifiers. Some architecture errata, such as SLS and
ARM64 errata families, intentionally do not carry synthetic CVE identifiers.

## Applicability Filtering

Rules can be scoped by CPU vendor or architecture. Vendor/architecture-specific
checks that do not apply to the scanned host are returned as `not_vulnerable`
with `OK` priority and `applicability` evidence. This prevents Intel hosts from
being filled with AMD/ARM/RISC-V-only UNKNOWN findings, and vice versa.

## Modes And Selection

The scanner supports reference-style selection and scope controls:

- `--cve CVE-...`
- `--variant name`
- `--errata number`
- `--no-runtime`
- `--no-hw`
- `--hw-only`
- `--no-sysfs`
- `--sysfs-only`
- `--cpu N|all`

Reports include a `scan` object with mode, selected checks, CPU selector, and
reduced-accuracy reasons.

## Sysfs Semantics

The scanner does not treat every `Mitigation:` line as equally safe. Messages
with residual-risk qualifiers such as `SMT vulnerable`, `IBPB: disabled`, or
`BHI: vulnerable` are preserved as `residual_risk=true` in summaries and can be
raised under elevated exposure or paranoid policy.

## Kernel Command Line

Mitigation-disabling parameters are reported and can raise priority:

- `mitigations=off`
- `spectre_v2=off`
- `spectre_v2_user=off`
- `spec_store_bypass_disable=off`
- `l1tf=off`
- `mds=off`
- `tsx_async_abort=off`
- `retbleed=off`

`nosmt`, `nosmt=force`, and `mitigations=...,nosmt` are recorded as positive
SMT control evidence.

## Optional Native Probes

The auditor works without native helpers. When deployed on x86 Linux, compile:

```sh
cc -O2 -Wall -Wextra -o native/ctra-cpuid native/ctra_cpuid.c
```

If the helper exists and the scan runs on the live root, CPUID leaves are added
to finding evidence. MSR values are added when `/dev/cpu/0/msr` is available and
readable. Probe failures are non-fatal. The collector decodes common x86
capabilities and control bits into `host.cpu_capabilities`, so findings can cite
both raw registers and interpreted mitigation state.

## Static Kernel Analysis

The scanner supports two lightweight static analysis paths:

- `--kernel-image`: scans raw or gzip/xz/bzip2-compressed kernel-like files for
  mitigation strings such as `retpoline`, `md_clear`, `verw`,
  `array_index_mask_nospec`, and vulnerability-specific names.
- `--system-map`: scans System.map symbols such as `__x86_indirect_thunk_*`,
  `array_index_mask_nospec`, `clear_bhb_*`, and MDS/GDS-related symbols.

These checks are evidence inputs. They do not replace runtime sysfs or vendor
affectedness data.

For selected checks such as Spectre V1/V2, MDS, GDS, RFDS, and BHI, static
kernel evidence can raise confidence or produce a medium-confidence mitigation
verdict when runtime sysfs is unavailable.

## Remaining Depth Needed

To approach specialized low-level scanners, add:

- larger vendor affectedness databases with license tracking
- automated Intel/AMD/ARM advisory ingestion
- production microcode latest-version database
- richer kernel image decompression and static analysis
- per-CVE CPU-family decision tables with regression fixtures
