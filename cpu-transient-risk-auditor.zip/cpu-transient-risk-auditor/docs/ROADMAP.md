# Roadmap

## Phase 1: Current

- Linux sysfs/procfs collection
- Evidence-preserving JSON model
- Markdown, JSON, CSV, and HTML output
- SARIF and JUnit output for security platforms and CI
- Structured remediation recommendations
- Asset metadata tags
- Policy profiles and CI-oriented exit status
- Baseline diff support
- Fixture-based tests

## Phase 2: Host Depth

- CPUID feature probing without external dependencies
- Optional MSR reads when running as root
- Microcode package inventory per distro family
- Kernel command-line mitigation parser
- Optional CPUID/MSR native probes
- Richer hypervisor and container detection
- System.map symbol scan
- Kernel image decompression

## Phase 3: Fleet

- Signed baseline reports
- Centrally managed affectedness and microcode databases
- Signed report bundles
- Prometheus textfile collector mode
- Central aggregation script

## Phase 4: Vendor Intelligence

- Import Intel/AMD/ARM advisory metadata with license tracking
- CPU model affectedness database
- Vendor-specific remediation hints
- Latest microcode database
