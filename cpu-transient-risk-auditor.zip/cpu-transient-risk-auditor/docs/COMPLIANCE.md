# Compliance Notes

This repository is intended as an independent implementation.

- It does not vendor third-party source code.
- It does not copy `spectre-meltdown-checker` functions, comments, generated
  tables, or shell implementation.
- It uses public Linux kernel interfaces and publicly documented vulnerability
  names/CVE identifiers.
- The initial license is MIT; replace it with the company's standard internal
  license if needed.

Recommended company upload checklist:

1. Keep this repository separate from any GPL-derived scanner.
2. Run the test suite before import.
3. Record that the implementation depends on Linux sysfs/procfs semantics.
4. Review future additions that import vendor data tables or microcode
   databases for their own licenses.
5. Keep company-maintained affectedness and microcode JSON files under explicit
   ownership and review; they are data products, not copied scanner code.
