#!/usr/bin/env sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export PYTHONPATH="$ROOT_DIR/src${PYTHONPATH:+:$PYTHONPATH}"

python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("python >= 3.10 required")
PY

sh "$ROOT_DIR/scripts/build-native.sh" || true

python3 -m ctra doctor
python3 -m ctra scan --format json >/tmp/ctra-smoke.json
python3 -m ctra scan --format prometheus >/tmp/ctra-smoke.prom
python3 -m ctra schema >/tmp/ctra-schema.json

echo "smoke ok: /tmp/ctra-smoke.json /tmp/ctra-smoke.prom /tmp/ctra-schema.json"
