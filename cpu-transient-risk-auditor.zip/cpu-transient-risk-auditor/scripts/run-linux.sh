#!/usr/bin/env sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export PYTHONPATH="$ROOT_DIR/src${PYTHONPATH:+:$PYTHONPATH}"

FORMAT=${FORMAT:-markdown}
PROFILE=${PROFILE:-standard}

set -- --profile "$PROFILE" --format "$FORMAT" "$@"
[ -n "${KERNEL_IMAGE:-}" ] && set -- "$@" --kernel-image "$KERNEL_IMAGE"
[ -n "${SYSTEM_MAP:-}" ] && set -- "$@" --system-map "$SYSTEM_MAP"
[ -n "${VENDOR_DATA:-}" ] && set -- "$@" --vendor-data "$VENDOR_DATA"
[ -n "${MICROCODE_DB:-}" ] && set -- "$@" --microcode-db "$MICROCODE_DB"
[ -n "${AFFECTED_DB:-}" ] && set -- "$@" --affected-db "$AFFECTED_DB"

exec python3 -m ctra scan "$@"
