#!/usr/bin/env sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
CC=${CC:-cc}

if command -v "$CC" >/dev/null 2>&1; then
  "$CC" -O2 -Wall -Wextra -o "$ROOT_DIR/native/ctra-cpuid" "$ROOT_DIR/native/ctra_cpuid.c"
  echo "built native/ctra-cpuid"
else
  echo "warning: C compiler '$CC' not found; skipping CPUID helper" >&2
fi
