# Changelog

## 0.1.0

- Initial independent implementation.
- Linux sysfs/procfs evidence collection.
- Policy-driven evaluation with `standard` and `paranoid` profiles.
- JSON, Markdown, CSV, and HTML output.
- SARIF and JUnit output.
- Prometheus and NRPE output.
- Structured remediation recommendations.
- Asset metadata embedding.
- Rule registry expanded to 37 findings.
- Optional vendor affectedness and microcode database inputs.
- Kernel config and os-release collection.
- CPU affectedness database engine.
- CPUID/MSR capability decoding scaffold.
- Expanded CPUID/MSR decoding for SPEC_CTRL, ARCH_CAPABILITIES, TSX_CTRL, MCU_OPT_CTRL, and AMD extended bits.
- Kernel image static string scan.
- System.map static symbol scan.
- Vendor/architecture applicability filtering to reduce noisy UNKNOWN findings.
- Coverage command for built-in rule/reference-family reporting.
- CVE, variant, and ARM errata selection filters.
- live/no-runtime/no-hw/hw-only/sysfs-only scan modes.
- Scan metadata with reduced-accuracy reasons and CPU selector.
- Built-in CPUID-derived not-affected decisions.
- Static kernel evidence can influence selected no-runtime verdicts.
- gzip/xz/bzip2 kernel image decompression.
- Rule-level required CPU capability evidence.
- JSON schema command.
- Baseline diff command.
- Doctor diagnostics command.
- CI-oriented exit status.
- Fixture-based standard-library tests.
