# CPU Transient Risk Auditor

An independent, clean-room-style CPU transient-execution risk auditor for Linux
systems. It focuses on evidence collection, operator-friendly prioritization,
and machine-readable reporting.

This project does **not** vendor or derive from `spectre-meltdown-checker`.
It implements a smaller company-oriented audit model from public Linux kernel
interfaces such as:

- `/sys/devices/system/cpu/vulnerabilities/*`
- `/sys/devices/system/cpu/smt/*`
- `/proc/cpuinfo`
- `/proc/modules`

## Goals

- produce JSON/Markdown/CSV reports
- preserve raw evidence for every finding
- separate verdict, confidence, exposure, and priority
- generate remediation guidance
- integrate with security and CI systems through SARIF and JUnit
- embed asset metadata for fleet reporting
- support offline fixture testing
- keep deployment simple with Python standard library only

## Quick Start

```sh
export PYTHONPATH=src
python -m ctra scan --format markdown
python -m ctra scan --format json > report.json
python -m ctra scan --format csv > report.csv
python -m ctra scan --format html > report.html
python -m ctra scan --format sarif > ctra.sarif
python -m ctra scan --format junit > junit.xml
python -m ctra scan --format prometheus > ctra.prom
python -m ctra scan --format nrpe
```

GPL reference backend:

```sh
python -m ctra scan --reference-backend attach --format json
python -m ctra scan --reference-backend augment --format json
```

`attach` stores the GPL reference backend summary under `tool.reference_backend`.
`augment` additionally attaches matching reference evidence to findings.

On a Linux host, a convenience wrapper is available:

```sh
sh scripts/build-native.sh      # optional CPUID helper
sh scripts/run-linux.sh         # markdown scan
FORMAT=json sh scripts/run-linux.sh > report.json
sh scripts/linux-smoke.sh       # smoke test doctor/json/prometheus/schema
```

For local development from the repository root:

```sh
set PYTHONPATH=src
python -m ctra scan --root tests/fixtures/linux-host --format json
python -m unittest discover -s tests
```

On Linux/macOS shells:

```sh
PYTHONPATH=src python -m ctra scan --root tests/fixtures/linux-host --format json
PYTHONPATH=src python -m unittest discover -s tests
```

## Commands

```sh
python -m ctra scan                 # audit the live system
python -m ctra doctor               # show collection diagnostics
python -m ctra coverage             # show built-in rule coverage
python -m ctra schema               # print the JSON schema
python -m ctra diff old.json new.json
```

Useful scan flags:

```sh
python -m ctra scan --profile paranoid --exit-status
python -m ctra scan --fail-on-priority P1 --format json
python -m ctra scan --no-unknown-risk
python -m ctra scan --cve CVE-2017-5715
python -m ctra scan --variant retbleed --variant bhi
python -m ctra scan --errata 3194386
python -m ctra scan --no-runtime --kernel-image /boot/vmlinux
python -m ctra scan --no-hw
python -m ctra scan --hw-only --cpu all
python -m ctra scan --sysfs-only
python -m ctra scan --asset-id host-123 --asset-owner platform --asset-env prod --tag region=cn-north
python -m ctra scan --vendor-data vendor-data.example.json
python -m ctra scan --microcode-db microcode-db.example.json
python -m ctra scan --affected-db affected-db.example.json
python -m ctra scan --kernel-image /boot/vmlinux
python -m ctra scan --system-map /boot/System.map-$(uname -r)
```

## Output Model

Each finding contains:

- `verdict`: `not_vulnerable`, `vulnerable`, or `unknown`
- `priority`: `P1`, `P2`, `P3`, or `OK`
- `confidence`: `high`, `medium`, or `low`
- `exposure`: `normal`, `elevated`, or `high`
- `evidence`: raw facts used for the decision
- `remediation`: ordered next actions for operators

## Differentiators

Compared with traditional single-host shell scanners, this implementation is
designed for company workflows:

- SARIF output for security platforms
- JUnit output for CI gates
- Prometheus and NRPE output for monitoring
- HTML reports for ticket attachments
- asset tags for fleet inventory joins
- explicit priority/confidence/exposure separation
- baseline diff command for regression tracking
- mitigation-disabling kernel command-line detection
- optional CPUID/MSR native probe hooks
- CPUID/MSR bit interpretation for common mitigation capabilities
- optional vendor affectedness and microcode databases
- static kernel image and System.map evidence
- CPU vendor/architecture applicability filtering to reduce noisy UNKNOWNs
- CVE/variant/errata selection filters
- live/no-runtime/no-hw/hw-only/sysfs-only scan modes
- scan metadata with mode, selected checks, reduced-accuracy reasons, and CPU selector
- built-in CPUID-derived not-affected decisions plus external affectedness DB support
- optional GPL reference backend using vendored `spectre-meltdown-checker.sh`
- standard-library tests and offline fixtures

## Current Scope

The scanner uses Linux sysfs as the primary runtime verdict source and enriches
it with CPU inventory, microcode data, kernel command line, kernel config,
System.map, kernel image strings, CPUID/MSR probe output, vendor affectedness
data, and fleet metadata.

`python -m ctra coverage` reports the built-in rule registry. This version has
37 rules, 35 explicit CVE identifiers, and covers 27 reference vulnerability
families.

Future work:

- larger production CPU affectedness and microcode databases
- automated advisory ingestion with license tracking
- deeper kernel image control-flow and symbol analysis
- BSD support if required by company fleet
